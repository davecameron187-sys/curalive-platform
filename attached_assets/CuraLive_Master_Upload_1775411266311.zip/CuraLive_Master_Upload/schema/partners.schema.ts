// ─────────────────────────────────────────────────────────────
// CuraLive — Partner & Client Delivery Schema
// ADD to: drizzle/schema.ts
// Run:    drizzle-kit push --force
// ─────────────────────────────────────────────────────────────

import {
  pgTable, serial, varchar, text, boolean,
  timestamp, integer, jsonb, uniqueIndex
} from "drizzle-orm/pg-core";

// ── PARTNERS ──────────────────────────────────────────────────
// One row per channel partner (Lumi, Bastion, etc.)
export const partners = pgTable("partners", {
  id:                   serial("id").primaryKey(),
  slug:                 varchar("slug", { length: 80 }).notNull().unique(),   // "lumi", "bastion"
  name:                 varchar("name", { length: 200 }).notNull(),            // "Lumi Global"
  displayName:          varchar("display_name", { length: 200 }).notNull(),   // "Lumi Intelligence"

  // Branding
  logoUrl:              text("logo_url"),
  faviconUrl:           text("favicon_url"),
  primaryColor:         varchar("primary_color", { length: 7 }).notNull().default("#1D9E75"),
  accentColor:          varchar("accent_color", { length: 7 }).notNull().default("#0A2540"),
  fontFamily:           varchar("font_family", { length: 100 }).default("Sora, sans-serif"),

  // Domain
  customDomain:         varchar("custom_domain", { length: 255 }),             // "intelligence.lumigroup.com"
  customDomainVerified: boolean("custom_domain_verified").default(false),

  // Email
  sendingDomain:        varchar("sending_domain", { length: 255 }),            // "lumigroup.com"
  sendingName:          varchar("sending_name", { length: 200 }),              // "Lumi Intelligence"
  sendingEmail:         varchar("sending_email", { length: 255 }),             // "noreply@lumigroup.com"
  replyToEmail:         varchar("reply_to_email", { length: 255 }),

  // Commercial
  model:                varchar("model", { length: 20 }).default("revenue_share"), // revenue_share | white_label | referral
  revenueSharePct:      integer("revenue_share_pct").default(20),
  active:               boolean("active").default(true),
  contractStart:        timestamp("contract_start"),
  contractEnd:          timestamp("contract_end"),

  // Config overrides (JSON — any extra per-partner settings)
  config:               jsonb("config").default({}),

  createdAt:            timestamp("created_at").defaultNow(),
  updatedAt:            timestamp("updated_at").defaultNow(),
});

// ── CLIENT ACCESS TOKENS ──────────────────────────────────────
// One row per client who should receive live/report access
export const clientTokens = pgTable("client_tokens", {
  id:           serial("id").primaryKey(),
  token:        varchar("token", { length: 128 }).notNull().unique(),
  sessionId:    integer("session_id").notNull(),           // → shadow_sessions.id
  eventId:      integer("event_id"),                       // → events.id
  partnerId:    integer("partner_id"),                     // → partners.id (null = CuraLive direct)

  // Recipient
  recipientName:  varchar("recipient_name", { length: 200 }),
  recipientEmail: varchar("recipient_email", { length: 255 }).notNull(),
  recipientRole:  varchar("recipient_role", { length: 100 }),  // "IR Manager", "CFO", "Board"

  // Access type
  accessType:   varchar("access_type", { length: 20 }).notNull(), // "live" | "report" | "both"

  // Validity
  expiresAt:    timestamp("expires_at").notNull(),
  usedAt:       timestamp("used_at"),
  useCount:     integer("use_count").default(0),
  maxUses:      integer("max_uses").default(50),

  // Delivery
  emailSentAt:  timestamp("email_sent_at"),
  emailStatus:  varchar("email_status", { length: 20 }).default("pending"), // pending|sent|failed

  createdAt:    timestamp("created_at").defaultNow(),
});

// ── CLIENT REPORT ACCESS LOG ──────────────────────────────────
// Audit trail of every report access
export const clientReportAccess = pgTable("client_report_access", {
  id:        serial("id").primaryKey(),
  tokenId:   integer("token_id").notNull(),
  sessionId: integer("session_id").notNull(),
  ipAddress: varchar("ip_address", { length: 45 }),
  userAgent: text("user_agent"),
  accessedAt: timestamp("accessed_at").defaultNow(),
});

// ── PARTNER EVENTS ────────────────────────────────────────────
// Links events/sessions to partners (for billing + white label)
export const partnerEvents = pgTable("partner_events", {
  id:          serial("id").primaryKey(),
  partnerId:   integer("partner_id").notNull(),
  sessionId:   integer("session_id"),
  eventId:     integer("event_id"),
  status:      varchar("status", { length: 20 }).default("active"),
  billingRef:  varchar("billing_ref", { length: 100 }),
  createdAt:   timestamp("created_at").defaultNow(),
});
