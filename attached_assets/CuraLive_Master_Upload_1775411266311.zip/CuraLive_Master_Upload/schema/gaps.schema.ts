// ─────────────────────────────────────────────────────────────
// CuraLive — Gap Resolution Schema
// APPEND to: drizzle/schema.ts
// Run: drizzle-kit push --force
// ─────────────────────────────────────────────────────────────

import {
  pgTable, serial, varchar, text, boolean,
  timestamp, integer, jsonb, pgEnum
} from "drizzle-orm/pg-core";

// ── ENUMS ─────────────────────────────────────────────────────
export const tierEnum = pgEnum("tier", [
  "essential", "intelligence", "enterprise", "agm"
]);

export const sessionStatusEnum = pgEnum("session_status_ext", [
  "scheduled", "pending", "bot_joining", "live",
  "processing", "completed", "failed"
]);

// ── GAP 1.1 / 1.2 / 1.3 — SESSION CONFIG ─────────────────────
// Extends shadow_sessions with tier, partner, recipients
// Add these columns to existing shadow_sessions table via migration:
//   ALTER TABLE shadow_sessions ADD COLUMN tier tier DEFAULT 'essential';
//   ALTER TABLE shadow_sessions ADD COLUMN partner_id integer;
//   ALTER TABLE shadow_sessions ADD COLUMN recipients jsonb DEFAULT '[]';
//   ALTER TABLE shadow_sessions ADD COLUMN scheduled_at timestamp;
//   ALTER TABLE shadow_sessions ADD COLUMN pre_brief_sent_at timestamp;
//   ALTER TABLE shadow_sessions ADD COLUMN live_links_sent_at timestamp;
//   ALTER TABLE shadow_sessions ADD COLUMN report_links_sent_at timestamp;

// ── GAP 1.4 — PRE-EVENT READINESS CHECKS ─────────────────────
export const sessionReadinessChecks = pgTable("session_readiness_checks", {
  id:              serial("id").primaryKey(),
  sessionId:       integer("session_id").notNull(),
  checkedAt:       timestamp("checked_at").defaultNow(),
  botDeployed:     boolean("bot_deployed").default(false),
  recipientsSet:   boolean("recipients_set").default(false),
  tierConfirmed:   boolean("tier_confirmed").default(false),
  jurisdictionSet: boolean("jurisdiction_set").default(false),
  recordingEnabled:boolean("recording_enabled").default(false),
  clientLinksSent: boolean("client_links_sent").default(false),
  overallReady:    boolean("overall_ready").default(false),
  notes:           text("notes"),
});

// ── GAP X.1 — OPERATOR ↔ CLIENT MESSAGING ────────────────────
export const sessionMessages = pgTable("session_messages", {
  id:          serial("id").primaryKey(),
  sessionId:   integer("session_id").notNull(),
  fromRole:    varchar("from_role", { length: 20 }).notNull(), // "operator" | "client"
  fromName:    varchar("from_name", { length: 200 }),
  message:     text("message").notNull(),
  messageType: varchar("message_type", { length: 30 }).default("chat"), // "chat" | "request" | "alert"
  resolved:    boolean("resolved").default(false),
  resolvedBy:  varchar("resolved_by", { length: 200 }),
  resolvedAt:  timestamp("resolved_at"),
  createdAt:   timestamp("created_at").defaultNow(),
});

// ── GAP 7.3 — SPEAKER DELIVERY (approved Q sent to presenter) ─
export const approvedQuestionsQueue = pgTable("approved_questions_queue", {
  id:           serial("id").primaryKey(),
  sessionId:    integer("session_id").notNull(),
  questionId:   integer("question_id").notNull(), // → live_qa_questions.id
  questionText: text("question_text").notNull(),
  askerName:    varchar("asker_name", { length: 200 }),
  askerFirm:    varchar("asker_firm", { length: 200 }),
  aiSuggestedAnswer: text("ai_suggested_answer"),
  status:       varchar("status", { length: 20 }).default("queued"), // queued | sent_to_speaker | answered | skipped
  queuePosition:integer("queue_position").default(0),
  sentToSpeakerAt: timestamp("sent_to_speaker_at"),
  answeredAt:   timestamp("answered_at"),
  createdAt:    timestamp("created_at").defaultNow(),
});

// ── GAP 3.1 / 3.4 — CLIENT REPORT ACCESS LOG ─────────────────
export const clientReportViewLog = pgTable("client_report_view_log", {
  id:           serial("id").primaryKey(),
  tokenId:      integer("token_id").notNull(),
  sessionId:    integer("session_id").notNull(),
  recipientEmail: varchar("recipient_email", { length: 255 }),
  tabViewed:    varchar("tab_viewed", { length: 50 }),
  timeSpentSecs:integer("time_spent_secs").default(0),
  ipAddress:    varchar("ip_address", { length: 45 }),
  viewedAt:     timestamp("viewed_at").defaultNow(),
});

// ── GAP X.5 — SESSION SCHEDULING ─────────────────────────────
export const scheduledSessions = pgTable("scheduled_sessions", {
  id:              serial("id").primaryKey(),
  title:           varchar("title", { length: 300 }).notNull(),
  company:         varchar("company", { length: 200 }),
  eventType:       varchar("event_type", { length: 50 }),
  tier:            varchar("tier", { length: 20 }).default("essential"),
  partnerId:       integer("partner_id"),
  scheduledAt:     timestamp("scheduled_at").notNull(),
  timezone:        varchar("timezone", { length: 50 }).default("Africa/Johannesburg"),
  meetingUrl:      text("meeting_url"),
  jurisdiction:    varchar("jurisdiction", { length: 10 }).default("JSE"),
  recipients:      jsonb("recipients").default([]),
  preBriefMinutes: integer("pre_brief_minutes").default(60),
  status:          varchar("status", { length: 20 }).default("scheduled"),
  sessionId:       integer("session_id"), // linked once session created
  reminderSentAt:  timestamp("reminder_sent_at"),
  preBriefSentAt:  timestamp("pre_brief_sent_at"),
  createdBy:       integer("created_by"),
  createdAt:       timestamp("created_at").defaultNow(),
  updatedAt:       timestamp("updated_at").defaultNow(),
});

// ── GAP X.2 — OPERATOR HANDOFF ───────────────────────────────
export const sessionHandoffs = pgTable("session_handoffs", {
  id:              serial("id").primaryKey(),
  sessionId:       integer("session_id").notNull(),
  fromOperatorId:  integer("from_operator_id"),
  fromOperatorName:varchar("from_operator_name", { length: 200 }),
  toOperatorId:    integer("to_operator_id"),
  toOperatorName:  varchar("to_operator_name", { length: 200 }),
  handoffNotes:    text("handoff_notes"),
  openFlags:       integer("open_flags").default(0),
  openQaItems:     integer("open_qa_items").default(0),
  status:          varchar("status", { length: 20 }).default("pending"), // pending | accepted | declined
  initiatedAt:     timestamp("initiated_at").defaultNow(),
  acceptedAt:      timestamp("accepted_at"),
});

// ── GAP X.3 — MULTI-OPERATOR SESSIONS ────────────────────────
export const sessionOperators = pgTable("session_operators", {
  id:          serial("id").primaryKey(),
  sessionId:   integer("session_id").notNull(),
  operatorId:  integer("operator_id").notNull(),
  role:        varchar("role", { length: 30 }).default("operator"), // "lead" | "operator" | "observer"
  focusArea:   varchar("focus_area", { length: 50 }), // "transcript" | "qa" | "compliance"
  joinedAt:    timestamp("joined_at").defaultNow(),
  leftAt:      timestamp("left_at"),
  active:      boolean("active").default(true),
});

// ── GAP X.4 — CLIENT FEEDBACK ────────────────────────────────
export const clientReportFeedback = pgTable("client_report_feedback", {
  id:           serial("id").primaryKey(),
  sessionId:    integer("session_id").notNull(),
  tokenId:      integer("token_id"),
  recipientEmail: varchar("recipient_email", { length: 255 }),
  overallRating:  integer("overall_rating"), // 1-5
  accuracyRating: integer("accuracy_rating"), // 1-5
  usefulnessRating: integer("usefulness_rating"), // 1-5
  feedback:     text("feedback"),
  flaggedItems: jsonb("flagged_items").default([]), // modules with inaccuracies
  submittedAt:  timestamp("submitted_at").defaultNow(),
});

// ── GAP X.6 — AGM INTELLIGENCE SESSIONS (extended) ───────────
export const agmResolutions = pgTable("agm_resolutions", {
  id:               serial("id").primaryKey(),
  sessionId:        integer("session_id").notNull(),
  resolutionNumber: integer("resolution_number").notNull(),
  title:            varchar("title", { length: 500 }).notNull(),
  type:             varchar("type", { length: 50 }), // ordinary | special | advisory
  proposedBy:       varchar("proposed_by", { length: 200 }),
  sentimentScore:   integer("sentiment_score"), // -100 to 100
  dissentLevel:     varchar("dissent_level", { length: 20 }), // low | moderate | high | critical
  activistMentions: integer("activist_mentions").default(0),
  proxyAdvisorRef:  boolean("proxy_advisor_ref").default(false),
  outcome:          varchar("outcome", { length: 20 }), // passed | failed | withdrawn | pending
  notes:            text("notes"),
  createdAt:        timestamp("created_at").defaultNow(),
});

export const agmShareholderSignals = pgTable("agm_shareholder_signals", {
  id:              serial("id").primaryKey(),
  sessionId:       integer("session_id").notNull(),
  speakerName:     varchar("speaker_name", { length: 300 }),
  signalType:      varchar("signal_type", { length: 50 }), // dissent | support | activist | proxy | retail
  resolutionRef:   integer("resolution_ref"),
  transcriptSegment: text("transcript_segment"),
  sentimentScore:  integer("sentiment_score"),
  detectedAt:      timestamp("detected_at").defaultNow(),
});

// ── GAP 9.2 — HISTORICAL COMMITMENT IMPORT ───────────────────
export const historicalCommitments = pgTable("historical_commitments", {
  id:              serial("id").primaryKey(),
  company:         varchar("company", { length: 200 }).notNull(),
  eventType:       varchar("event_type", { length: 50 }),
  eventDate:       timestamp("event_date"),
  commitment:      text("commitment").notNull(),
  committedBy:     varchar("committed_by", { length: 200 }),
  deadline:        timestamp("deadline"),
  status:          varchar("status", { length: 20 }).default("open"), // open | met | missed | partial
  verifiedInSessionId: integer("verified_in_session_id"),
  importedAt:      timestamp("imported_at").defaultNow(),
  importedBy:      integer("imported_by"),
});

// ── GAP 9.3 — BOARD MEMBER PROFILES ──────────────────────────
export const boardMembers = pgTable("board_members", {
  id:              serial("id").primaryKey(),
  company:         varchar("company", { length: 200 }).notNull(),
  name:            varchar("name", { length: 200 }).notNull(),
  role:            varchar("role", { length: 100 }), // CEO | CFO | Chair | NED | etc
  tenureStart:     timestamp("tenure_start"),
  shareholding:    varchar("shareholding", { length: 50 }),
  independentNed:  boolean("independent_ned").default(false),
  active:          boolean("active").default(true),
  notes:           text("notes"),
  createdAt:       timestamp("created_at").defaultNow(),
});

// ── GAP 11.2 — COMPLIANCE ACTION DEADLINES ───────────────────
export const complianceDeadlines = pgTable("compliance_deadlines", {
  id:              serial("id").primaryKey(),
  sessionId:       integer("session_id").notNull(),
  flagId:          integer("flag_id"), // → regulatory_flags.id
  action:          text("action").notNull(),
  deadline:        timestamp("deadline").notNull(),
  jurisdiction:    varchar("jurisdiction", { length: 10 }),
  priority:        varchar("priority", { length: 10 }).default("high"),
  status:          varchar("status", { length: 20 }).default("open"), // open | completed | escalated | waived
  assignedTo:      varchar("assigned_to", { length: 255 }),
  reminderSentAt:  timestamp("reminder_sent_at"),
  escalatedAt:     timestamp("escalated_at"),
  completedAt:     timestamp("completed_at"),
  createdAt:       timestamp("created_at").defaultNow(),
});

// ── GAP 10.3 — BRIEFING ACCURACY SCORING ─────────────────────
export const briefingAccuracyScores = pgTable("briefing_accuracy_scores", {
  id:              serial("id").primaryKey(),
  briefingId:      integer("briefing_id").notNull(), // → pre_event_intelligence_briefings.id
  sessionId:       integer("session_id").notNull(),
  predictedQaCount:     integer("predicted_qa_count"),
  actualQaCount:        integer("actual_qa_count"),
  topicsCorrect:        integer("topics_correct"),
  topicsTotal:          integer("topics_total"),
  complianceHotspotsHit:integer("compliance_hotspots_hit"),
  complianceHotspotsTotal: integer("compliance_hotspots_total"),
  overallAccuracyPct:   integer("overall_accuracy_pct"),
  calculatedAt:    timestamp("calculated_at").defaultNow(),
});
