// ─────────────────────────────────────────────────────────────
// CuraLive — Speaker Queue Router
// File: server/routers/speakerQueueRouter.ts
// Covers: Gap 7.3 — approved questions delivered to presenter
//         Gap 7.4 — AI suggested answer visible to client
// Register in BOTH routers files:
//   speakerQueue: speakerQueueRouter,
//
// HOW IT WORKS:
// - Operator approves a Q&A question in Live Q&A console
// - Question pushed to approvedQuestionsQueue table
// - Ably publishes to speaker channel: speaker-{sessionId}
// - Presenter screen (new /presenter/:token page) shows next question
// - Operator marks question as answered → next question surfaces
// - Client dashboard (Gap 7.4) receives the AI suggested answer
//   via session-{sessionId}-client Ably channel
// ─────────────────────────────────────────────────────────────

import { z } from "zod";
import { eq, and, asc, desc } from "drizzle-orm";
import { router, publicProcedure, operatorProcedure } from "../_core/trpc";
import { getDb } from "../db";
import { approvedQuestionsQueue, clientTokens } from "../../drizzle/schema";
import Ably from "ably";

const ably = process.env.ABLY_API_KEY
  ? new Ably.Rest(process.env.ABLY_API_KEY)
  : null;

export const speakerQueueRouter = router({

  // ── APPROVE & QUEUE QUESTION FOR SPEAKER ─────────────────────
  queueForSpeaker: operatorProcedure
    .input(z.object({
      sessionId:         z.number().int(),
      questionId:        z.number().int(),
      questionText:      z.string(),
      askerName:         z.string().optional(),
      askerFirm:         z.string().optional(),
      aiSuggestedAnswer: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      // Get current queue length for position
      const existing = await db
        .select()
        .from(approvedQuestionsQueue)
        .where(and(
          eq(approvedQuestionsQueue.sessionId, input.sessionId),
          eq(approvedQuestionsQueue.status, "queued")
        ));

      const position = existing.length + 1;

      const [queued] = await db
        .insert(approvedQuestionsQueue)
        .values({
          sessionId:         input.sessionId,
          questionId:        input.questionId,
          questionText:      input.questionText,
          askerName:         input.askerName,
          askerFirm:         input.askerFirm,
          aiSuggestedAnswer: input.aiSuggestedAnswer,
          status:            "queued",
          queuePosition:     position,
        })
        .returning();

      // Notify presenter screen
      if (ably) {
        const presenterChannel = ably.channels.get(`speaker-${input.sessionId}`);
        await presenterChannel.publish("question.queued", {
          id:            queued.id,
          position,
          questionText:  input.questionText,
          askerName:     input.askerName,
          askerFirm:     input.askerFirm,
          totalInQueue:  position,
        });

        // Gap 7.4: Push AI suggested answer to client dashboard
        if (input.aiSuggestedAnswer) {
          const clientChannel = ably.channels.get(`session-${input.sessionId}-client`);
          await clientChannel.publish("qa.suggestion", {
            questionText:      input.questionText,
            askerFirm:         input.askerFirm,
            aiSuggestedAnswer: input.aiSuggestedAnswer,
            position,
          });
        }
      }

      return queued;
    }),

  // ── GET CURRENT SPEAKER QUEUE ────────────────────────────────
  getSpeakerQueue: operatorProcedure
    .input(z.object({ sessionId: z.number().int() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];

      return db
        .select()
        .from(approvedQuestionsQueue)
        .where(eq(approvedQuestionsQueue.sessionId, input.sessionId))
        .orderBy(asc(approvedQuestionsQueue.queuePosition));
    }),

  // ── MARK AS SENT TO SPEAKER (operator sends it to presenter) ─
  sendToSpeaker: operatorProcedure
    .input(z.object({
      queueItemId: z.number().int(),
      sessionId:   z.number().int(),
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const [updated] = await db
        .update(approvedQuestionsQueue)
        .set({ status: "sent_to_speaker", sentToSpeakerAt: new Date() })
        .where(eq(approvedQuestionsQueue.id, input.queueItemId))
        .returning();

      // Notify presenter: this is the ACTIVE question
      if (ably) {
        const presenterChannel = ably.channels.get(`speaker-${input.sessionId}`);
        await presenterChannel.publish("question.active", {
          id:           updated.id,
          questionText: updated.questionText,
          askerName:    updated.askerName,
          askerFirm:    updated.askerFirm,
          suggestion:   updated.aiSuggestedAnswer,
        });
      }

      return updated;
    }),

  // ── MARK AS ANSWERED ─────────────────────────────────────────
  markAnswered: operatorProcedure
    .input(z.object({
      queueItemId: z.number().int(),
      sessionId:   z.number().int(),
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      await db
        .update(approvedQuestionsQueue)
        .set({ status: "answered", answeredAt: new Date() })
        .where(eq(approvedQuestionsQueue.id, input.queueItemId));

      // Notify presenter: move to next
      if (ably) {
        const presenterChannel = ably.channels.get(`speaker-${input.sessionId}`);
        await presenterChannel.publish("question.answered", { queueItemId: input.queueItemId });
      }

      return { success: true };
    }),

  // ── PRESENTER VIEW — get queue (public, presenter token) ──────
  getPresenterQueue: publicProcedure
    .input(z.object({ presenterToken: z.string() }))
    .query(async ({ input }) => {
      // Validate presenter token (same client_tokens table, role = "presenter")
      const db = await getDb();
      if (!db) return [];

      const [token] = await db
        .select()
        .from(clientTokens)
        .where(and(
          eq(clientTokens.token, input.presenterToken),
          eq(clientTokens.accessType, "presenter" as any)
        ))
        .limit(1);

      if (!token || token.expiresAt < new Date()) return [];

      return db
        .select()
        .from(approvedQuestionsQueue)
        .where(and(
          eq(approvedQuestionsQueue.sessionId, token.sessionId),
          eq(approvedQuestionsQueue.status, "sent_to_speaker")
        ))
        .orderBy(asc(approvedQuestionsQueue.queuePosition))
        .limit(5);
    }),

  // ── SKIP QUESTION ────────────────────────────────────────────
  skipQuestion: operatorProcedure
    .input(z.object({ queueItemId: z.number().int() }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      await db
        .update(approvedQuestionsQueue)
        .set({ status: "skipped" })
        .where(eq(approvedQuestionsQueue.id, input.queueItemId));

      return { success: true };
    }),
});
