// ─────────────────────────────────────────────────────────────
// CuraLive — Partner Router
// File: server/routers/partnerRouter.ts
// Register in: server/routers.eager.ts AND server/routers.ts
//   partners: partnerRouter
// ─────────────────────────────────────────────────────────────

import { z } from "zod";
import { eq, and } from "drizzle-orm";
import {
  router,
  publicProcedure,
  protectedProcedure,
  adminProcedure,
} from "../_core/trpc";
import { getDb, rawSql } from "../db";
import { partners, clientTokens, partnerEvents } from "../../drizzle/schema";
import { nanoid } from "nanoid";

// ── BRAND CONFIG (public — called by frontend on load) ────────
const brandConfigSchema = z.object({
  slug:         z.string(),
  name:         z.string(),
  displayName:  z.string(),
  logoUrl:      z.string().nullable(),
  faviconUrl:   z.string().nullable(),
  primaryColor: z.string(),
  accentColor:  z.string(),
  fontFamily:   z.string().nullable(),
  sendingName:  z.string().nullable(),
  customDomain: z.string().nullable(),
});

export const partnerRouter = router({

  // ── GET BRAND CONFIG BY DOMAIN ──────────────────────────────
  // Called by: useBrandConfig hook on every page load
  // Identifies partner by request domain — falls back to CuraLive defaults
  getBrandByDomain: publicProcedure
    .input(z.object({ domain: z.string() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return curaliveDefaults();

      const [partner] = await db
        .select()
        .from(partners)
        .where(
          and(
            eq(partners.customDomain, input.domain),
            eq(partners.active, true)
          )
        )
        .limit(1);

      if (!partner) return curaliveDefaults();

      return {
        isWhiteLabel: true,
        slug:         partner.slug,
        name:         partner.name,
        displayName:  partner.displayName,
        logoUrl:      partner.logoUrl,
        faviconUrl:   partner.faviconUrl,
        primaryColor: partner.primaryColor,
        accentColor:  partner.accentColor,
        fontFamily:   partner.fontFamily ?? "Sora, sans-serif",
        sendingName:  partner.sendingName,
        customDomain: partner.customDomain,
      };
    }),

  // ── GET BRAND CONFIG BY SLUG ────────────────────────────────
  getBrandBySlug: publicProcedure
    .input(z.object({ slug: z.string() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return curaliveDefaults();

      const [partner] = await db
        .select()
        .from(partners)
        .where(and(eq(partners.slug, input.slug), eq(partners.active, true)))
        .limit(1);

      if (!partner) return curaliveDefaults();

      return {
        isWhiteLabel:  true,
        slug:          partner.slug,
        name:          partner.name,
        displayName:   partner.displayName,
        logoUrl:       partner.logoUrl,
        faviconUrl:    partner.faviconUrl,
        primaryColor:  partner.primaryColor,
        accentColor:   partner.accentColor,
        fontFamily:    partner.fontFamily ?? "Sora, sans-serif",
        sendingName:   partner.sendingName,
        customDomain:  partner.customDomain,
      };
    }),

  // ── ADMIN: LIST ALL PARTNERS ────────────────────────────────
  listPartners: adminProcedure.query(async () => {
    const db = await getDb();
    if (!db) return [];
    return db.select().from(partners).orderBy(partners.name);
  }),

  // ── ADMIN: CREATE PARTNER ───────────────────────────────────
  createPartner: adminProcedure
    .input(z.object({
      slug:          z.string().min(2).max(80),
      name:          z.string().min(2).max(200),
      displayName:   z.string().min(2).max(200),
      logoUrl:       z.string().url().optional(),
      primaryColor:  z.string().regex(/^#[0-9A-Fa-f]{6}$/).default("#1D9E75"),
      accentColor:   z.string().regex(/^#[0-9A-Fa-f]{6}$/).default("#0A2540"),
      customDomain:  z.string().optional(),
      sendingDomain: z.string().optional(),
      sendingName:   z.string().optional(),
      sendingEmail:  z.string().email().optional(),
      model:         z.enum(["revenue_share", "white_label", "referral"]).default("revenue_share"),
      revenueSharePct: z.number().int().min(0).max(100).default(20),
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const [partner] = await db
        .insert(partners)
        .values({
          ...input,
          active: true,
        })
        .returning();

      return partner;
    }),

  // ── ADMIN: UPDATE PARTNER ───────────────────────────────────
  updatePartner: adminProcedure
    .input(z.object({
      id:            z.number().int(),
      displayName:   z.string().optional(),
      logoUrl:       z.string().url().nullable().optional(),
      primaryColor:  z.string().regex(/^#[0-9A-Fa-f]{6}$/).optional(),
      accentColor:   z.string().regex(/^#[0-9A-Fa-f]{6}$/).optional(),
      customDomain:  z.string().nullable().optional(),
      sendingDomain: z.string().nullable().optional(),
      sendingName:   z.string().nullable().optional(),
      sendingEmail:  z.string().email().nullable().optional(),
      active:        z.boolean().optional(),
      revenueSharePct: z.number().int().min(0).max(100).optional(),
    }))
    .mutation(async ({ input: { id, ...data } }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const [updated] = await db
        .update(partners)
        .set({ ...data, updatedAt: new Date() })
        .where(eq(partners.id, id))
        .returning();

      return updated;
    }),

  // ── GENERATE CLIENT TOKEN ───────────────────────────────────
  // Called when: operator completes session setup, or session closes
  generateClientToken: protectedProcedure
    .input(z.object({
      sessionId:      z.number().int(),
      eventId:        z.number().int().optional(),
      partnerId:      z.number().int().optional(),
      recipientName:  z.string(),
      recipientEmail: z.string().email(),
      recipientRole:  z.string().optional(),
      accessType:     z.enum(["live", "report", "both"]),
      expiresInDays:  z.number().int().min(1).max(365).default(30),
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const token = nanoid(48);
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + input.expiresInDays);

      const [clientToken] = await db
        .insert(clientTokens)
        .values({
          token,
          sessionId:      input.sessionId,
          eventId:        input.eventId,
          partnerId:      input.partnerId,
          recipientName:  input.recipientName,
          recipientEmail: input.recipientEmail,
          recipientRole:  input.recipientRole,
          accessType:     input.accessType,
          expiresAt,
          emailStatus:    "pending",
        })
        .returning();

      return {
        tokenId:    clientToken.id,
        token:      clientToken.token,
        liveUrl:    buildClientUrl("live", clientToken.token, input.partnerId),
        reportUrl:  buildClientUrl("report", clientToken.token, input.partnerId),
        expiresAt,
      };
    }),

  // ── VALIDATE TOKEN (public — called when client opens link) ─
  validateToken: publicProcedure
    .input(z.object({
      token:      z.string(),
      accessType: z.enum(["live", "report"]),
    }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const [clientToken] = await db
        .select()
        .from(clientTokens)
        .where(eq(clientTokens.token, input.token))
        .limit(1);

      if (!clientToken) return { valid: false, reason: "Token not found" };
      if (clientToken.expiresAt < new Date()) return { valid: false, reason: "Token expired" };
      if (clientToken.useCount >= (clientToken.maxUses ?? 50)) return { valid: false, reason: "Token usage limit reached" };

      // Check access type
      const allowed =
        clientToken.accessType === "both" ||
        clientToken.accessType === input.accessType;
      if (!allowed) return { valid: false, reason: "Access type not permitted" };

      // Increment use count
      await db
        .update(clientTokens)
        .set({
          useCount: (clientToken.useCount ?? 0) + 1,
          usedAt:   clientToken.usedAt ?? new Date(),
        })
        .where(eq(clientTokens.token, input.token));

      return {
        valid:          true,
        sessionId:      clientToken.sessionId,
        eventId:        clientToken.eventId,
        partnerId:      clientToken.partnerId,
        recipientName:  clientToken.recipientName,
        recipientEmail: clientToken.recipientEmail,
        recipientRole:  clientToken.recipientRole,
        accessType:     clientToken.accessType,
      };
    }),

  // ── LIST TOKENS FOR SESSION ─────────────────────────────────
  listSessionTokens: protectedProcedure
    .input(z.object({ sessionId: z.number().int() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];
      return db
        .select()
        .from(clientTokens)
        .where(eq(clientTokens.sessionId, input.sessionId))
        .orderBy(clientTokens.createdAt);
    }),
});

// ── HELPERS ──────────────────────────────────────────────────

function curaliveDefaults() {
  return {
    isWhiteLabel:  false,
    slug:          "curalive",
    name:          "CuraLive",
    displayName:   "CuraLive Intelligence",
    logoUrl:       null,
    faviconUrl:    null,
    primaryColor:  "#1D9E75",
    accentColor:   "#0A2540",
    fontFamily:    "Sora, sans-serif",
    sendingName:   "CuraLive",
    customDomain:  null,
  };
}

function buildClientUrl(type: "live" | "report", token: string, partnerId?: number | null): string {
  // In production this reads from partner.customDomain if set
  const base = process.env.APP_URL ?? "https://app.curalive.com";
  return `${base}/${type === "live" ? "live" : "report"}/${token}`;
}
