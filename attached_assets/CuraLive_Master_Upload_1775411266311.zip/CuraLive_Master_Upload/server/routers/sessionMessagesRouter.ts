// ─────────────────────────────────────────────────────────────
// CuraLive — Operator ↔ Client Messaging Router
// File: server/routers/sessionMessagesRouter.ts
// Covers: Gap X.1 — IR team can message operator in real time
// Register in BOTH routers.eager.ts and routers.ts:
//   sessionMessages: sessionMessagesRouter,
//
// HOW IT WORKS:
// - Client dashboard sends a message via public endpoint (token-authenticated)
// - Message saved to session_messages table
// - Ably publishes to operator channel: operator-{sessionId}
// - Operator console shows message with notification badge
// - Operator replies via protected endpoint
// - Ably publishes to client channel: session-{sessionId}-client
// - Client dashboard shows operator reply in real time
// ─────────────────────────────────────────────────────────────

import { z } from "zod";
import { eq, and, desc } from "drizzle-orm";
import { router, publicProcedure, operatorProcedure } from "../_core/trpc";
import { getDb } from "../db";
import { sessionMessages, clientTokens } from "../../drizzle/schema";
import Ably from "ably";

const ably = process.env.ABLY_API_KEY
  ? new Ably.Rest(process.env.ABLY_API_KEY)
  : null;

export const sessionMessagesRouter = router({

  // ── CLIENT → OPERATOR (public, token-authenticated) ─────────
  sendFromClient: publicProcedure
    .input(z.object({
      token:       z.string(),
      message:     z.string().min(1).max(500),
      messageType: z.enum(["chat", "request", "alert"]).default("chat"),
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      // Validate token
      const [clientToken] = await db
        .select()
        .from(clientTokens)
        .where(eq(clientTokens.token, input.token))
        .limit(1);

      if (!clientToken) throw new Error("Invalid token");
      if (clientToken.expiresAt < new Date()) throw new Error("Token expired");

      // Save message
      const [msg] = await db
        .insert(sessionMessages)
        .values({
          sessionId:   clientToken.sessionId,
          fromRole:    "client",
          fromName:    clientToken.recipientName ?? clientToken.recipientEmail ?? "Client",
          message:     input.message,
          messageType: input.messageType,
        })
        .returning();

      // Push to operator via Ably
      if (ably) {
        const channel = ably.channels.get(`operator-${clientToken.sessionId}`);
        await channel.publish("client.message", {
          id:          msg.id,
          sessionId:   clientToken.sessionId,
          fromName:    msg.fromName,
          fromRole:    "client",
          message:     input.message,
          messageType: input.messageType,
          createdAt:   msg.createdAt,
        });
      }

      return { success: true, messageId: msg.id };
    }),

  // ── OPERATOR → CLIENT (protected) ────────────────────────────
  sendFromOperator: operatorProcedure
    .input(z.object({
      sessionId:   z.number().int(),
      message:     z.string().min(1).max(500),
      messageType: z.enum(["chat", "request", "alert"]).default("chat"),
      replyToId:   z.number().int().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const fromName = ctx.user?.name ?? "Operator";

      const [msg] = await db
        .insert(sessionMessages)
        .values({
          sessionId:   input.sessionId,
          fromRole:    "operator",
          fromName,
          message:     input.message,
          messageType: input.messageType,
        })
        .returning();

      // Mark reply-to as resolved
      if (input.replyToId) {
        await db
          .update(sessionMessages)
          .set({ resolved: true, resolvedBy: fromName, resolvedAt: new Date() })
          .where(eq(sessionMessages.id, input.replyToId));
      }

      // Push to client channel via Ably
      if (ably) {
        const channel = ably.channels.get(`session-${input.sessionId}-client`);
        await channel.publish("operator.message", {
          id:          msg.id,
          sessionId:   input.sessionId,
          fromName,
          fromRole:    "operator",
          message:     input.message,
          messageType: input.messageType,
          createdAt:   msg.createdAt,
        });
      }

      return { success: true, messageId: msg.id };
    }),

  // ── GET MESSAGES FOR SESSION (operator view) ─────────────────
  getSessionMessages: operatorProcedure
    .input(z.object({
      sessionId: z.number().int(),
      limit:     z.number().int().default(50),
    }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];

      return db
        .select()
        .from(sessionMessages)
        .where(eq(sessionMessages.sessionId, input.sessionId))
        .orderBy(desc(sessionMessages.createdAt))
        .limit(input.limit);
    }),

  // ── GET MESSAGES FOR CLIENT (public, token-authenticated) ────
  getClientMessages: publicProcedure
    .input(z.object({
      token: z.string(),
      since: z.number().int().optional(), // last message id
    }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];

      const [clientToken] = await db
        .select()
        .from(clientTokens)
        .where(eq(clientTokens.token, input.token))
        .limit(1);

      if (!clientToken) return [];

      return db
        .select()
        .from(sessionMessages)
        .where(eq(sessionMessages.sessionId, clientToken.sessionId))
        .orderBy(sessionMessages.createdAt)
        .limit(100);
    }),

  // ── RESOLVE A CLIENT MESSAGE ─────────────────────────────────
  resolveMessage: operatorProcedure
    .input(z.object({ messageId: z.number().int() }))
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      await db
        .update(sessionMessages)
        .set({
          resolved:   true,
          resolvedBy: ctx.user?.name ?? "Operator",
          resolvedAt: new Date(),
        })
        .where(eq(sessionMessages.id, input.messageId));

      return { success: true };
    }),
});
