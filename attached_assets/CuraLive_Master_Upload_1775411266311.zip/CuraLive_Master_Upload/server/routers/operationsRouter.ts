// ─────────────────────────────────────────────────────────────
// CuraLive — Operations Router
// File: server/routers/operationsRouter.ts
// Covers:
//   Gap X.2 — Operator handoff
//   Gap X.3 — Multi-operator sessions
//   Gap X.4 — Client feedback
//   Gap 9.2 — Historical commitment import
//   Gap 9.3 — Board member profiles
//   Gap 3.2 — Resend report link
//   Gap 3.4 — Client access log
// Register in BOTH routers files:
//   operations: operationsRouter,
// ─────────────────────────────────────────────────────────────

import { z } from "zod";
import { eq, and, desc, asc } from "drizzle-orm";
import { router, publicProcedure, operatorProcedure, adminProcedure } from "../_core/trpc";
import { getDb } from "../db";
import {
  sessionHandoffs, sessionOperators, clientReportFeedback,
  historicalCommitments, boardMembers, clientReportViewLog,
  clientTokens,
} from "../../drizzle/schema";
import { sendReportLinks } from "../services/ClientDeliveryService";
import { nanoid } from "nanoid";
import Ably from "ably";

const ably = process.env.ABLY_API_KEY
  ? new Ably.Rest(process.env.ABLY_API_KEY)
  : null;

export const operationsRouter = router({

  // ════════════════════════════════════════════════════════════
  // GAP X.2 — OPERATOR HANDOFF
  // ════════════════════════════════════════════════════════════

  initiateHandoff: operatorProcedure
    .input(z.object({
      sessionId:        z.number().int(),
      toOperatorEmail:  z.string().email(),
      handoffNotes:     z.string().optional(),
      openFlags:        z.number().int().default(0),
      openQaItems:      z.number().int().default(0),
    }))
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const [handoff] = await db
        .insert(sessionHandoffs)
        .values({
          sessionId:        input.sessionId,
          fromOperatorId:   ctx.user?.id,
          fromOperatorName: ctx.user?.name ?? "Operator",
          toOperatorName:   input.toOperatorEmail,
          handoffNotes:     input.handoffNotes,
          openFlags:        input.openFlags,
          openQaItems:      input.openQaItems,
          status:           "pending",
        })
        .returning();

      // Notify incoming operator via Ably
      if (ably) {
        const channel = ably.channels.get(`operator-notifications`);
        await channel.publish("handoff.requested", {
          handoffId:    handoff.id,
          sessionId:    input.sessionId,
          from:         ctx.user?.name,
          notes:        input.handoffNotes,
          openFlags:    input.openFlags,
          openQaItems:  input.openQaItems,
        });
      }

      return handoff;
    }),

  acceptHandoff: operatorProcedure
    .input(z.object({ handoffId: z.number().int() }))
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const [updated] = await db
        .update(sessionHandoffs)
        .set({
          toOperatorId:   ctx.user?.id,
          toOperatorName: ctx.user?.name ?? "Operator",
          status:         "accepted",
          acceptedAt:     new Date(),
        })
        .where(eq(sessionHandoffs.id, input.handoffId))
        .returning();

      return updated;
    }),

  // ════════════════════════════════════════════════════════════
  // GAP X.3 — MULTI-OPERATOR SESSIONS
  // ════════════════════════════════════════════════════════════

  joinSessionAsOperator: operatorProcedure
    .input(z.object({
      sessionId: z.number().int(),
      role:      z.enum(["lead","operator","observer"]).default("operator"),
      focusArea: z.enum(["transcript","qa","compliance"]).optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const [joined] = await db
        .insert(sessionOperators)
        .values({
          sessionId:  input.sessionId,
          operatorId: ctx.user?.id ?? 0,
          role:       input.role,
          focusArea:  input.focusArea,
          active:     true,
        })
        .returning();

      // Notify other operators
      if (ably) {
        const channel = ably.channels.get(`operator-${input.sessionId}`);
        await channel.publish("operator.joined", {
          operatorId:   ctx.user?.id,
          operatorName: ctx.user?.name,
          role:         input.role,
          focusArea:    input.focusArea,
        });
      }

      return joined;
    }),

  leaveSession: operatorProcedure
    .input(z.object({ sessionId: z.number().int() }))
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      await db
        .update(sessionOperators)
        .set({ active: false, leftAt: new Date() })
        .where(and(
          eq(sessionOperators.sessionId, input.sessionId),
          eq(sessionOperators.operatorId, ctx.user?.id ?? 0)
        ));

      return { success: true };
    }),

  getActiveOperators: operatorProcedure
    .input(z.object({ sessionId: z.number().int() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];

      return db
        .select()
        .from(sessionOperators)
        .where(and(
          eq(sessionOperators.sessionId, input.sessionId),
          eq(sessionOperators.active, true)
        ));
    }),

  // ════════════════════════════════════════════════════════════
  // GAP X.4 — CLIENT FEEDBACK
  // ════════════════════════════════════════════════════════════

  submitFeedback: publicProcedure
    .input(z.object({
      token:            z.string(),
      overallRating:    z.number().int().min(1).max(5),
      accuracyRating:   z.number().int().min(1).max(5),
      usefulnessRating: z.number().int().min(1).max(5),
      feedback:         z.string().optional(),
      flaggedItems:     z.array(z.string()).optional(),
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const [clientToken] = await db
        .select()
        .from(clientTokens)
        .where(eq(clientTokens.token, input.token))
        .limit(1);

      if (!clientToken) throw new Error("Invalid token");

      const [feedback] = await db
        .insert(clientReportFeedback)
        .values({
          sessionId:        clientToken.sessionId,
          tokenId:          clientToken.id,
          recipientEmail:   clientToken.recipientEmail,
          overallRating:    input.overallRating,
          accuracyRating:   input.accuracyRating,
          usefulnessRating: input.usefulnessRating,
          feedback:         input.feedback,
          flaggedItems:     input.flaggedItems ?? [],
        })
        .returning();

      // Feed to AI evolution engine
      if (ably) {
        const channel = ably.channels.get("ai-evolution");
        await channel.publish("client.feedback", {
          sessionId:     clientToken.sessionId,
          overallRating: input.overallRating,
          accuracyRating: input.accuracyRating,
          flaggedItems:  input.flaggedItems,
          feedback:      input.feedback,
        });
      }

      return { success: true };
    }),

  // ════════════════════════════════════════════════════════════
  // GAP 9.2 — HISTORICAL COMMITMENT IMPORT
  // ════════════════════════════════════════════════════════════

  importHistoricalCommitments: operatorProcedure
    .input(z.object({
      company:     z.string(),
      commitments: z.array(z.object({
        eventType:   z.string().optional(),
        eventDate:   z.string().datetime().optional(),
        commitment:  z.string(),
        committedBy: z.string().optional(),
        deadline:    z.string().datetime().optional(),
        status:      z.enum(["open","met","missed","partial"]).default("open"),
      })),
    }))
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const rows = input.commitments.map(c => ({
        company:     input.company,
        eventType:   c.eventType,
        eventDate:   c.eventDate ? new Date(c.eventDate) : undefined,
        commitment:  c.commitment,
        committedBy: c.committedBy,
        deadline:    c.deadline ? new Date(c.deadline) : undefined,
        status:      c.status,
        importedBy:  ctx.user?.id,
      }));

      await db.insert(historicalCommitments).values(rows);
      return { imported: rows.length };
    }),

  getHistoricalCommitments: operatorProcedure
    .input(z.object({ company: z.string() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];

      return db
        .select()
        .from(historicalCommitments)
        .where(eq(historicalCommitments.company, input.company))
        .orderBy(desc(historicalCommitments.eventDate));
    }),

  // ════════════════════════════════════════════════════════════
  // GAP 9.3 — BOARD MEMBER PROFILES
  // ════════════════════════════════════════════════════════════

  upsertBoardMember: operatorProcedure
    .input(z.object({
      id:              z.number().int().optional(),
      company:         z.string(),
      name:            z.string(),
      role:            z.string().optional(),
      tenureStart:     z.string().datetime().optional(),
      shareholding:    z.string().optional(),
      independentNed:  z.boolean().default(false),
      active:          z.boolean().default(true),
      notes:           z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      if (input.id) {
        const [updated] = await db
          .update(boardMembers)
          .set({
            role:           input.role,
            shareholding:   input.shareholding,
            independentNed: input.independentNed,
            active:         input.active,
            notes:          input.notes,
          })
          .where(eq(boardMembers.id, input.id))
          .returning();
        return updated;
      }

      const [created] = await db
        .insert(boardMembers)
        .values({
          company:        input.company,
          name:           input.name,
          role:           input.role,
          tenureStart:    input.tenureStart ? new Date(input.tenureStart) : undefined,
          shareholding:   input.shareholding,
          independentNed: input.independentNed,
          active:         input.active,
          notes:          input.notes,
        })
        .returning();

      return created;
    }),

  getBoardMembers: operatorProcedure
    .input(z.object({ company: z.string() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];

      return db
        .select()
        .from(boardMembers)
        .where(and(eq(boardMembers.company, input.company), eq(boardMembers.active, true)))
        .orderBy(asc(boardMembers.role));
    }),

  // ════════════════════════════════════════════════════════════
  // GAP 3.2 — RESEND REPORT LINK
  // ════════════════════════════════════════════════════════════

  resendReportLink: operatorProcedure
    .input(z.object({
      sessionId:  z.number().int(),
      recipientEmail: z.string().email(),
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      // Get session details
      const rows = await db
        .select()
        .from(clientTokens)
        .where(and(
          eq(clientTokens.sessionId, input.sessionId),
          eq(clientTokens.recipientEmail, input.recipientEmail)
        ))
        .limit(1);

      // Generate fresh token
      const token = nanoid(48);
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + 30);

      // Get existing token details for name/role
      const existing = rows[0];

      await db.insert(clientTokens).values({
        token,
        sessionId:      input.sessionId,
        recipientName:  existing?.recipientName,
        recipientEmail: input.recipientEmail,
        recipientRole:  existing?.recipientRole,
        accessType:     "report",
        expiresAt,
        emailStatus:    "pending",
      });

      // Get session info for email
      const sessionRows = await db.execute(
        `SELECT event_name, company FROM shadow_sessions WHERE id = $1`,
        [input.sessionId]
      ) as any;

      const session = sessionRows.rows?.[0] ?? {};

      // Send
      const result = await sendReportLinks({
        sessionId:       input.sessionId,
        eventName:       session.event_name ?? "Event",
        companyName:     session.company ?? "Company",
        eventDate:       new Date().toLocaleDateString(),
        reportModules:   20,
        complianceFlags: 0,
        sessionDuration: "—",
        recipients: [{
          name:  existing?.recipientName ?? input.recipientEmail,
          email: input.recipientEmail,
        }],
      });

      return result;
    }),

  // ════════════════════════════════════════════════════════════
  // GAP 3.4 — CLIENT ACCESS LOG (operator view)
  // ════════════════════════════════════════════════════════════

  logClientView: publicProcedure
    .input(z.object({
      token:         z.string(),
      tabViewed:     z.string().optional(),
      timeSpentSecs: z.number().int().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) return;

      const [clientToken] = await db
        .select()
        .from(clientTokens)
        .where(eq(clientTokens.token, input.token))
        .limit(1);

      if (!clientToken) return;

      await db.insert(clientReportViewLog).values({
        tokenId:        clientToken.id,
        sessionId:      clientToken.sessionId,
        recipientEmail: clientToken.recipientEmail ?? undefined,
        tabViewed:      input.tabViewed,
        timeSpentSecs:  input.timeSpentSecs,
      });
    }),

  getClientAccessLog: operatorProcedure
    .input(z.object({ sessionId: z.number().int() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];

      return db
        .select()
        .from(clientReportViewLog)
        .where(eq(clientReportViewLog.sessionId, input.sessionId))
        .orderBy(desc(clientReportViewLog.viewedAt));
    }),

  // ════════════════════════════════════════════════════════════
  // GAP 11.1 — AUTO-JURISDICTION DETECTION
  // ════════════════════════════════════════════════════════════

  detectJurisdiction: operatorProcedure
    .input(z.object({
      company:  z.string(),
      exchange: z.string().optional(), // JSE, NYSE, LSE, etc.
    }))
    .query(async ({ input }) => {
      const exchangeMap: Record<string, string[]> = {
        JSE:   ["JSE"],
        NYSE:  ["SEC"],
        NASDAQ:["SEC"],
        LSE:   ["FCA"],
        ASX:   ["ASIC"],
        SGX:   ["SGX"],
        HKEX:  ["HKEX"],
      };

      const exchange = input.exchange?.toUpperCase() ?? "";
      const jurisdictions = exchangeMap[exchange] ?? ["JSE"];

      return { jurisdictions, primary: jurisdictions[0] };
    }),
});
