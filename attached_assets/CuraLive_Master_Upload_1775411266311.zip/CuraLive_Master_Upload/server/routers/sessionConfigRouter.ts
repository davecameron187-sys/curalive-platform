// ─────────────────────────────────────────────────────────────
// CuraLive — Session Config Router
// File: server/routers/sessionConfigRouter.ts
// Covers: Gap 1.1 (recipients), 1.2 (tier), 1.3 (partner),
//         1.4 (readiness check), X.5 (scheduling)
// Register in BOTH routers.eager.ts and routers.ts:
//   sessionConfig: sessionConfigRouter,
// ─────────────────────────────────────────────────────────────

import { z } from "zod";
import { eq, and, gte } from "drizzle-orm";
import { router, protectedProcedure, operatorProcedure } from "../_core/trpc";
import { getDb, rawSql } from "../db";
import {
  scheduledSessions,
  sessionReadinessChecks,
  shadow_sessions,
} from "../../drizzle/schema";
import { sendLiveDashboardLinks } from "../services/ClientDeliveryService";

const recipientSchema = z.object({
  name:     z.string().min(1),
  email:    z.string().email(),
  role:     z.string().optional(),
  sendLive: z.boolean().default(true),
  sendReport: z.boolean().default(true),
});

export const sessionConfigRouter = router({

  // ── GAP 1.1 / 1.2 / 1.3 — Update session with tier/partner/recipients ──
  updateSessionConfig: operatorProcedure
    .input(z.object({
      sessionId:    z.number().int(),
      tier:         z.enum(["essential","intelligence","enterprise","agm"]).optional(),
      partnerId:    z.number().int().nullable().optional(),
      recipients:   z.array(recipientSchema).optional(),
      jurisdiction: z.string().optional(),
      scheduledAt:  z.string().datetime().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const updates: Record<string, any> = { updatedAt: new Date() };
      if (input.tier)       updates.tier       = input.tier;
      if (input.partnerId !== undefined) updates.partnerId = input.partnerId;
      if (input.recipients) updates.recipients = JSON.stringify(input.recipients);
      if (input.jurisdiction) updates.jurisdiction = input.jurisdiction;
      if (input.scheduledAt) updates.scheduledAt = new Date(input.scheduledAt);

      await rawSql(
        `UPDATE shadow_sessions SET
          tier = COALESCE($1, tier),
          partner_id = COALESCE($2, partner_id),
          recipients = COALESCE($3::jsonb, recipients),
          scheduled_at = COALESCE($4, scheduled_at),
          updated_at = NOW()
        WHERE id = $5`,
        [
          input.tier ?? null,
          input.partnerId ?? null,
          input.recipients ? JSON.stringify(input.recipients) : null,
          input.scheduledAt ? new Date(input.scheduledAt) : null,
          input.sessionId,
        ]
      );

      return { success: true };
    }),

  // ── GET SESSION CONFIG ──────────────────────────────────────
  getSessionConfig: operatorProcedure
    .input(z.object({ sessionId: z.number().int() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const rows = await rawSql(
        `SELECT id, tier, partner_id, recipients, jurisdiction, scheduled_at
         FROM shadow_sessions WHERE id = $1`,
        [input.sessionId]
      );

      if (!rows.length) throw new Error("Session not found");
      const row = rows[0];
      return {
        ...row,
        recipients: row.recipients
          ? (typeof row.recipients === "string" ? JSON.parse(row.recipients) : row.recipients)
          : [],
      };
    }),

  // ── GAP 1.4 — PRE-EVENT READINESS CHECK ────────────────────
  runReadinessCheck: operatorProcedure
    .input(z.object({ sessionId: z.number().int() }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      // Get session state
      const rows = await rawSql(
        `SELECT s.*, 
          (SELECT COUNT(*) FROM recall_bots WHERE session_id = s.id AND status = 'in_call') as bot_active,
          (SELECT COUNT(*) FROM client_tokens WHERE session_id = s.id AND access_type IN ('live','both')) as live_links_count
         FROM shadow_sessions s WHERE s.id = $1`,
        [input.sessionId]
      );
      if (!rows.length) throw new Error("Session not found");
      const session = rows[0];

      const recipients = session.recipients
        ? (typeof session.recipients === "string" ? JSON.parse(session.recipients) : session.recipients)
        : [];

      const checks = {
        botDeployed:      Number(session.bot_active) > 0,
        recipientsSet:    recipients.length > 0,
        tierConfirmed:    !!session.tier && session.tier !== null,
        jurisdictionSet:  !!session.jurisdiction,
        recordingEnabled: session.is_recording === true,
        clientLinksSent:  Number(session.live_links_count) > 0,
      };

      const overallReady = Object.values(checks).every(Boolean);

      // Save check result
      await db.insert(sessionReadinessChecks).values({
        sessionId:        input.sessionId,
        botDeployed:      checks.botDeployed,
        recipientsSet:    checks.recipientsSet,
        tierConfirmed:    checks.tierConfirmed,
        jurisdictionSet:  checks.jurisdictionSet,
        recordingEnabled: checks.recordingEnabled,
        clientLinksSent:  checks.clientLinksSent,
        overallReady,
      });

      return { checks, overallReady };
    }),

  // ── GAP X.5 — SCHEDULE A SESSION ────────────────────────────
  scheduleSession: operatorProcedure
    .input(z.object({
      title:           z.string().min(1),
      company:         z.string().optional(),
      eventType:       z.string().default("earnings_call"),
      tier:            z.enum(["essential","intelligence","enterprise","agm"]).default("essential"),
      partnerId:       z.number().int().nullable().optional(),
      scheduledAt:     z.string().datetime(),
      timezone:        z.string().default("Africa/Johannesburg"),
      meetingUrl:      z.string().url().optional(),
      jurisdiction:    z.string().default("JSE"),
      recipients:      z.array(recipientSchema).default([]),
      preBriefMinutes: z.number().int().default(60),
    }))
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const [scheduled] = await db
        .insert(scheduledSessions)
        .values({
          title:           input.title,
          company:         input.company,
          eventType:       input.eventType,
          tier:            input.tier,
          partnerId:       input.partnerId,
          scheduledAt:     new Date(input.scheduledAt),
          timezone:        input.timezone,
          meetingUrl:      input.meetingUrl,
          jurisdiction:    input.jurisdiction,
          recipients:      input.recipients,
          preBriefMinutes: input.preBriefMinutes,
          createdBy:       ctx.user?.id,
        })
        .returning();

      return scheduled;
    }),

  // ── GET SCHEDULED SESSIONS ──────────────────────────────────
  getScheduledSessions: operatorProcedure
    .input(z.object({
      from: z.string().datetime().optional(),
      to:   z.string().datetime().optional(),
    }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];

      const now = new Date();
      const from = input.from ? new Date(input.from) : now;

      return db
        .select()
        .from(scheduledSessions)
        .where(gte(scheduledSessions.scheduledAt, from))
        .orderBy(scheduledSessions.scheduledAt);
    }),

  // ── SEND LIVE LINKS NOW ──────────────────────────────────────
  // Gap 1.1 — operator manually triggers live link send
  sendLiveLinks: operatorProcedure
    .input(z.object({ sessionId: z.number().int() }))
    .mutation(async ({ input }) => {
      const config = await getSessionConfigInternal(input.sessionId);
      if (!config) throw new Error("Session not found");
      if (!config.recipients?.length) throw new Error("No recipients configured");

      const results = await sendLiveDashboardLinks({
        sessionId:   input.sessionId,
        partnerId:   config.partnerId,
        eventName:   config.event_name ?? "Event",
        companyName: config.company ?? "Company",
        eventDate:   new Date().toLocaleDateString(),
        recipients:  config.recipients.filter((r: any) => r.sendLive !== false),
      });

      // Mark live links sent
      await rawSql(
        `UPDATE shadow_sessions SET live_links_sent_at = NOW() WHERE id = $1`,
        [input.sessionId]
      );

      return results;
    }),
});

// Internal helper
async function getSessionConfigInternal(sessionId: number) {
  const rows = await rawSql(
    `SELECT id, tier, partner_id, recipients, jurisdiction, event_name, company
     FROM shadow_sessions WHERE id = $1`,
    [sessionId]
  );
  if (!rows.length) return null;
  const row = rows[0];
  return {
    ...row,
    recipients: row.recipients
      ? (typeof row.recipients === "string" ? JSON.parse(row.recipients) : row.recipients)
      : [],
  };
}
