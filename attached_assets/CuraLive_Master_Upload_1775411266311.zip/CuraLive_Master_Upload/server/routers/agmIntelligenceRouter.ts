// ─────────────────────────────────────────────────────────────
// CuraLive — AGM Intelligence Router
// File: server/routers/agmIntelligenceRouter.ts
// Covers: Gap X.6 (AGM intelligence layer), Gap 1.5 (AGM routing)
// Register in BOTH routers files:
//   agmIntelligence: agmIntelligenceRouter,
//
// AGM INTELLIGENCE SURFACES:
// 1. Resolution tracking — which resolutions are being debated
// 2. Shareholder dissent analysis — activist language, proxy advisor refs
// 3. Governance communication scoring
// 4. Real-time dissent sentiment per resolution
// 5. Post-AGM dissent report
// ─────────────────────────────────────────────────────────────

import { z } from "zod";
import { eq, and, desc } from "drizzle-orm";
import { router, operatorProcedure } from "../_core/trpc";
import { getDb } from "../db";
import { agmResolutions, agmShareholderSignals } from "../../drizzle/schema";
import { llm } from "../_core/llm";

const PROXY_ADVISORS = ["ISS", "Glass Lewis", "Institutional Shareholder Services", "Hermes", "PIRC", "Sustainalytics"];
const ACTIVIST_SIGNALS = ["vote against", "withhold", "abstain", "concerned", "oppose", "reject", "inadequate", "excessive", "unacceptable", "accountability"];

export const agmIntelligenceRouter = router({

  // ── CREATE RESOLUTION (operator sets up before AGM) ──────────
  createResolution: operatorProcedure
    .input(z.object({
      sessionId:        z.number().int(),
      resolutionNumber: z.number().int(),
      title:            z.string().min(1),
      type:             z.enum(["ordinary", "special", "advisory"]).default("ordinary"),
      proposedBy:       z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const [res] = await db
        .insert(agmResolutions)
        .values({
          sessionId:        input.sessionId,
          resolutionNumber: input.resolutionNumber,
          title:            input.title,
          type:             input.type,
          proposedBy:       input.proposedBy,
          outcome:          "pending",
        })
        .returning();

      return res;
    }),

  // ── ANALYSE TRANSCRIPT SEGMENT FOR AGM SIGNALS ───────────────
  // Called by transcript processing pipeline when event_type = 'agm'
  analyseAgmSegment: operatorProcedure
    .input(z.object({
      sessionId:   z.number().int(),
      segmentText: z.string(),
      speaker:     z.string().optional(),
      timestamp:   z.number().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const text = input.segmentText.toLowerCase();

      // Detect proxy advisor references
      const proxyAdvisorRef = PROXY_ADVISORS.some(pa => text.includes(pa.toLowerCase()));

      // Detect activist signals
      const activistCount = ACTIVIST_SIGNALS.filter(s => text.includes(s)).length;
      const isActivist = activistCount >= 2;

      // Detect dissent type
      let signalType: string = "retail";
      if (proxyAdvisorRef) signalType = "proxy";
      else if (isActivist) signalType = "activist";
      else if (text.includes("institutional") || text.includes("fund")) signalType = "institutional";

      // Simple sentiment: count negative vs positive indicators
      const negatives = ["against", "oppose", "reject", "no", "concerned", "inadequate", "excessive"].filter(w => text.includes(w)).length;
      const positives = ["support", "approve", "in favour", "yes", "satisfied", "adequate"].filter(w => text.includes(w)).length;
      const sentimentScore = Math.min(100, Math.max(-100, (positives - negatives) * 20));

      // Save signal if significant
      if (activistCount > 0 || proxyAdvisorRef) {
        await db.insert(agmShareholderSignals).values({
          sessionId:         input.sessionId,
          speakerName:       input.speaker,
          signalType,
          transcriptSegment: input.segmentText,
          sentimentScore,
        });
      }

      return { signalType, sentimentScore, proxyAdvisorRef, activistCount };
    }),

  // ── GET FULL AGM INTELLIGENCE DASHBOARD ──────────────────────
  getAgmDashboard: operatorProcedure
    .input(z.object({ sessionId: z.number().int() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return null;

      const [resolutions, signals] = await Promise.all([
        db.select().from(agmResolutions).where(eq(agmResolutions.sessionId, input.sessionId)).orderBy(agmResolutions.resolutionNumber),
        db.select().from(agmShareholderSignals).where(eq(agmShareholderSignals.sessionId, input.sessionId)).orderBy(desc(agmShareholderSignals.detectedAt)),
      ]);

      // Aggregate stats
      const activistSignals    = signals.filter(s => s.signalType === "activist").length;
      const proxySignals       = signals.filter(s => s.signalType === "proxy").length;
      const institutionalSignals = signals.filter(s => s.signalType === "institutional").length;
      const avgSentiment       = signals.length ? Math.round(signals.reduce((a, s) => a + (s.sentimentScore ?? 0), 0) / signals.length) : 0;

      const overallDissentLevel =
        activistSignals > 5 || proxySignals > 2 ? "critical" :
        activistSignals > 2 || proxySignals > 0 ? "high" :
        activistSignals > 0 ? "moderate" : "low";

      return {
        resolutions,
        signals: signals.slice(0, 20),
        summary: {
          totalResolutions:       resolutions.length,
          activistSignals,
          proxySignals,
          institutionalSignals,
          avgSentiment,
          overallDissentLevel,
          pendingResolutions:     resolutions.filter(r => r.outcome === "pending").length,
          passedResolutions:      resolutions.filter(r => r.outcome === "passed").length,
          failedResolutions:      resolutions.filter(r => r.outcome === "failed").length,
        },
      };
    }),

  // ── UPDATE RESOLUTION OUTCOME ─────────────────────────────────
  updateResolutionOutcome: operatorProcedure
    .input(z.object({
      resolutionId: z.number().int(),
      outcome:      z.enum(["passed", "failed", "withdrawn", "pending"]),
      notes:        z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const [updated] = await db
        .update(agmResolutions)
        .set({ outcome: input.outcome, notes: input.notes })
        .where(eq(agmResolutions.id, input.resolutionId))
        .returning();

      return updated;
    }),

  // ── GENERATE POST-AGM DISSENT REPORT ──────────────────────────
  generateDissentReport: operatorProcedure
    .input(z.object({ sessionId: z.number().int() }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const [resolutions, signals] = await Promise.all([
        db.select().from(agmResolutions).where(eq(agmResolutions.sessionId, input.sessionId)),
        db.select().from(agmShareholderSignals).where(eq(agmShareholderSignals.sessionId, input.sessionId)),
      ]);

      // Build prompt for LLM
      const prompt = `You are an AGM intelligence analyst. Generate a concise post-AGM dissent analysis report.

RESOLUTIONS:
${resolutions.map(r => `${r.resolutionNumber}. ${r.title} (${r.type}) — Outcome: ${r.outcome}`).join("\n")}

SHAREHOLDER SIGNALS DETECTED:
${signals.map(s => `[${s.signalType?.toUpperCase()}] Sentiment: ${s.sentimentScore} — "${s.transcriptSegment?.slice(0, 150)}"`).join("\n")}

Generate a structured dissent analysis covering:
1. Overall dissent level and key concerns
2. Resolution-by-resolution analysis (flag any failed or contested resolutions)
3. Activist shareholder activity detected
4. Proxy advisor references and their likely impact
5. Recommended board actions post-AGM
6. Comparison indicators (high/moderate/low dissent vs typical AGM)

Format as structured JSON with keys: overallAssessment, resolutionAnalysis, activistActivity, proxyAdvisorImpact, boardActions, dissentLevel.`;

      const response = await llm.complete(prompt, { format: "json" });

      return {
        report:      response,
        resolutions,
        signals,
        generatedAt: new Date().toISOString(),
      };
    }),
});
