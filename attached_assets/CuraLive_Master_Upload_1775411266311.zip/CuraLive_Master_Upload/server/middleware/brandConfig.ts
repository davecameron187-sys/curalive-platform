// ─────────────────────────────────────────────────────────────
// CuraLive — Brand Config Middleware
// File: server/middleware/brandConfig.ts
// Usage: app.use(brandConfigMiddleware) in server/_core/index.ts
//        BEFORE tRPC middleware
// ─────────────────────────────────────────────────────────────

import { Request, Response, NextFunction } from "express";
import { getDb } from "../db";
import { partners } from "../../drizzle/schema";
import { eq, and } from "drizzle-orm";

export interface BrandConfig {
  isWhiteLabel:  boolean;
  slug:          string;
  name:          string;
  displayName:   string;
  logoUrl:       string | null;
  primaryColor:  string;
  accentColor:   string;
  fontFamily:    string;
  sendingName:   string;
  sendingEmail:  string | null;
  customDomain:  string | null;
}

// Extend Express Request
declare global {
  namespace Express {
    interface Request {
      brandConfig: BrandConfig;
    }
  }
}

const CURALIVE_DEFAULTS: BrandConfig = {
  isWhiteLabel:  false,
  slug:          "curalive",
  name:          "CuraLive",
  displayName:   "CuraLive Intelligence",
  logoUrl:       null,
  primaryColor:  "#1D9E75",
  accentColor:   "#0A2540",
  fontFamily:    "Sora, sans-serif",
  sendingName:   "CuraLive",
  sendingEmail:  "noreply@curalive.com",
  customDomain:  null,
};

// Simple in-memory cache — 5 minute TTL per domain
const brandCache = new Map<string, { config: BrandConfig; expires: number }>();
const CACHE_TTL_MS = 5 * 60 * 1000;

export async function brandConfigMiddleware(
  req: Request,
  res: Response,
  next: NextFunction
) {
  try {
    const host = req.hostname?.toLowerCase() ?? "";

    // Skip for internal/API routes
    if (
      host === "localhost" ||
      host.includes("replit.dev") ||
      host.includes("replit.app") ||
      host === "app.curalive.com"
    ) {
      req.brandConfig = CURALIVE_DEFAULTS;
      return next();
    }

    // Check cache
    const cached = brandCache.get(host);
    if (cached && cached.expires > Date.now()) {
      req.brandConfig = cached.config;
      return next();
    }

    // Look up by custom domain
    const db = await getDb();
    if (!db) {
      req.brandConfig = CURALIVE_DEFAULTS;
      return next();
    }

    const [partner] = await db
      .select()
      .from(partners)
      .where(and(eq(partners.customDomain, host), eq(partners.active, true)))
      .limit(1);

    const config: BrandConfig = partner
      ? {
          isWhiteLabel:  true,
          slug:          partner.slug,
          name:          partner.name,
          displayName:   partner.displayName,
          logoUrl:       partner.logoUrl,
          primaryColor:  partner.primaryColor,
          accentColor:   partner.accentColor,
          fontFamily:    partner.fontFamily ?? "Sora, sans-serif",
          sendingName:   partner.sendingName ?? partner.name,
          sendingEmail:  partner.sendingEmail,
          customDomain:  partner.customDomain,
        }
      : CURALIVE_DEFAULTS;

    // Cache it
    brandCache.set(host, { config, expires: Date.now() + CACHE_TTL_MS });
    req.brandConfig = config;
    next();
  } catch (err) {
    console.error("[brandConfig] middleware error:", err);
    req.brandConfig = CURALIVE_DEFAULTS;
    next();
  }
}

// Clear cache entry (call after partner update)
export function clearBrandCache(domain: string) {
  brandCache.delete(domain.toLowerCase());
}
