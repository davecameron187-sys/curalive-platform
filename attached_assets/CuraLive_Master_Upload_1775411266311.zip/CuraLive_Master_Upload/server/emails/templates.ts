// ─────────────────────────────────────────────────────────────
// CuraLive — Email Templates
// File: server/emails/templates.ts
// Fully white-label aware — all brand tokens injected
// ─────────────────────────────────────────────────────────────

interface BrandConfig {
  displayName:  string;
  logoUrl:      string | null;
  primaryColor: string;
  accentColor:  string;
  sendingName:  string;
  customDomain: string | null;
}

interface LiveEmailParams {
  brand:         BrandConfig;
  recipientName: string;
  eventName:     string;
  companyName:   string;
  eventDate:     string;
  liveUrl:       string;
  expiresAt:     Date;
}

interface ReportEmailParams {
  brand:            BrandConfig;
  recipientName:    string;
  eventName:        string;
  companyName:      string;
  eventDate:        string;
  reportUrl:        string;
  reportModules:    number;
  complianceFlags:  number;
  sessionDuration:  string;
  expiresAt:        Date;
}

// ── SHARED WRAPPER ────────────────────────────────────────────
function emailWrapper(brand: BrandConfig, content: string): string {
  const primary = brand.primaryColor;
  const accent  = brand.accentColor;
  const name    = brand.displayName;
  const logo    = brand.logoUrl;

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${name}</title>
</head>
<body style="margin:0;padding:0;background:#f4f5f8;font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f5f8;padding:32px 16px;">
  <tr><td align="center">
    <table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;">

      <!-- HEADER -->
      <tr>
        <td style="background:${accent};border-radius:12px 12px 0 0;padding:24px 32px;text-align:left;">
          ${logo
            ? `<img src="${logo}" alt="${name}" style="height:36px;max-width:200px;display:block;">`
            : `<div style="font-size:22px;font-weight:700;color:#ffffff;letter-spacing:-0.02em;">${name}</div>`
          }
        </td>
      </tr>

      <!-- BODY -->
      <tr>
        <td style="background:#ffffff;padding:32px;border-left:1px solid #e8eaf0;border-right:1px solid #e8eaf0;">
          ${content}
        </td>
      </tr>

      <!-- FOOTER -->
      <tr>
        <td style="background:#f8f9fb;border:1px solid #e8eaf0;border-top:none;border-radius:0 0 12px 12px;padding:20px 32px;text-align:center;">
          <p style="margin:0;font-size:11px;color:#9aa3b2;line-height:1.6;">
            This message was sent by ${name} · Confidential · Token-authenticated access<br>
            Your access link is unique to you. Do not share it.<br>
            ${brand.customDomain ? `<a href="https://${brand.customDomain}" style="color:${primary};">${brand.customDomain}</a>` : ""}
          </p>
        </td>
      </tr>

    </table>
  </td></tr>
</table>
</body>
</html>`;
}

// ── LIVE DASHBOARD EMAIL ──────────────────────────────────────
export function buildLiveEmail(params: LiveEmailParams): string {
  const { brand, recipientName, eventName, companyName, eventDate, liveUrl, expiresAt } = params;
  const primary = brand.primaryColor;
  const expiry  = expiresAt.toLocaleDateString("en-ZA", { day: "numeric", month: "long", year: "numeric" });

  const content = `
    <!-- LIVE BADGE -->
    <div style="display:inline-flex;align-items:center;gap:6px;background:#fef0ee;border:1px solid rgba(192,41,26,0.2);border-radius:100px;padding:5px 14px;margin-bottom:20px;">
      <div style="width:7px;height:7px;border-radius:50%;background:#C0291A;display:inline-block;"></div>
      <span style="font-size:11px;font-weight:700;color:#C0291A;letter-spacing:0.08em;">LIVE NOW</span>
    </div>

    <h1 style="margin:0 0 8px;font-size:22px;font-weight:300;color:#0A2540;letter-spacing:-0.02em;">
      Your live intelligence<br>dashboard is ready
    </h1>

    <p style="margin:0 0 20px;font-size:14px;color:#6b7280;line-height:1.6;">
      Hi ${recipientName},<br><br>
      Your ${brand.displayName} live dashboard for <strong style="color:#0A2540;">${companyName} — ${eventName}</strong> is active now. 
      Click below to open your real-time intelligence view.
    </p>

    <!-- EVENT CARD -->
    <div style="background:#f4f5f8;border-radius:10px;padding:16px 20px;margin-bottom:24px;border-left:4px solid ${primary};">
      <div style="font-size:11px;color:#9aa3b2;text-transform:uppercase;letter-spacing:0.08em;margin-bottom:4px;">Session details</div>
      <div style="font-size:14px;font-weight:600;color:#0A2540;margin-bottom:2px;">${companyName} — ${eventName}</div>
      <div style="font-size:12px;color:#6b7280;">${eventDate} · Live via Shadow Mode · AI intelligence active</div>
    </div>

    <!-- WHAT YOU'LL SEE -->
    <div style="margin-bottom:24px;">
      <div style="font-size:12px;font-weight:600;color:#0A2540;margin-bottom:10px;">Your live dashboard shows:</div>
      <table cellpadding="0" cellspacing="0" width="100%">
        <tr>
          <td width="50%" style="padding:0 6px 8px 0;vertical-align:top;">
            <div style="background:#e6f7f3;border-radius:7px;padding:10px 12px;">
              <div style="font-size:11px;font-weight:600;color:#137a3c;margin-bottom:2px;">📡 Live transcript</div>
              <div style="font-size:10px;color:#6b7280;">Every word, speaker-labelled, streaming in real time</div>
            </div>
          </td>
          <td width="50%" style="padding:0 0 8px 6px;vertical-align:top;">
            <div style="background:#eff6ff;border-radius:7px;padding:10px 12px;">
              <div style="font-size:11px;font-weight:600;color:#1246E8;margin-bottom:2px;">📊 Live sentiment</div>
              <div style="font-size:10px;color:#6b7280;">Confidence, hedging, investor positivity — live</div>
            </div>
          </td>
        </tr>
        <tr>
          <td width="50%" style="padding:0 6px 0 0;vertical-align:top;">
            <div style="background:#fef0ee;border-radius:7px;padding:10px 12px;">
              <div style="font-size:11px;font-weight:600;color:#C0291A;margin-bottom:2px;">⚠ Compliance alerts</div>
              <div style="font-size:10px;color:#6b7280;">Flags the moment they are detected — plain English</div>
            </div>
          </td>
          <td width="50%" style="padding:0 0 0 6px;vertical-align:top;">
            <div style="background:#fef8e8;border-radius:7px;padding:10px 12px;">
              <div style="font-size:11px;font-weight:600;color:#BA7517;margin-bottom:2px;">❓ Live Q&A queue</div>
              <div style="font-size:10px;color:#6b7280;">Questions coming in, AI classified, in real time</div>
            </div>
          </td>
        </tr>
      </table>
    </div>

    <!-- CTA -->
    <div style="text-align:center;margin-bottom:24px;">
      <a href="${liveUrl}" style="display:inline-block;background:${primary};color:#ffffff;text-decoration:none;font-size:14px;font-weight:600;padding:14px 36px;border-radius:9px;letter-spacing:0.01em;">
        📡 &nbsp;Open my live dashboard
      </a>
    </div>

    <!-- SECURITY NOTE -->
    <div style="background:#f4f5f8;border-radius:8px;padding:12px 16px;font-size:11px;color:#9aa3b2;line-height:1.6;">
      🔒 &nbsp;Your access is <strong>read-only</strong>. This link is personal to you and expires on ${expiry}. 
      Updates automatically as the session progresses — no refresh needed.
    </div>
  `;

  return emailWrapper(brand, content);
}

// ── REPORT READY EMAIL ────────────────────────────────────────
export function buildReportEmail(params: ReportEmailParams): string {
  const {
    brand, recipientName, eventName, companyName, eventDate,
    reportUrl, reportModules, complianceFlags, sessionDuration, expiresAt,
  } = params;
  const primary = brand.primaryColor;
  const expiry  = expiresAt.toLocaleDateString("en-ZA", { day: "numeric", month: "long", year: "numeric" });
  const flagColour = complianceFlags > 0 ? "#C0291A" : "#137a3c";
  const flagBg     = complianceFlags > 0 ? "#fef0ee" : "#e8f7ef";

  const content = `
    <!-- COMPLETE BADGE -->
    <div style="display:inline-flex;align-items:center;gap:6px;background:#e8f7ef;border:1px solid rgba(19,122,60,0.2);border-radius:100px;padding:5px 14px;margin-bottom:20px;">
      <span style="font-size:14px;">✓</span>
      <span style="font-size:11px;font-weight:700;color:#137a3c;letter-spacing:0.08em;">REPORT READY</span>
    </div>

    <h1 style="margin:0 0 8px;font-size:22px;font-weight:300;color:#0A2540;letter-spacing:-0.02em;">
      Your post-event intelligence<br>report is ready
    </h1>

    <p style="margin:0 0 20px;font-size:14px;color:#6b7280;line-height:1.6;">
      Hi ${recipientName},<br><br>
      Your complete ${brand.displayName} intelligence report for <strong style="color:#0A2540;">${companyName} — ${eventName}</strong> has been generated. 
      All ${reportModules} AI modules are complete.
    </p>

    <!-- STATS ROW -->
    <table cellpadding="0" cellspacing="0" width="100%" style="margin-bottom:24px;">
      <tr>
        <td width="25%" align="center" style="padding:0 4px;">
          <div style="background:#f4f5f8;border-radius:8px;padding:12px 8px;text-align:center;">
            <div style="font-size:1.4rem;font-weight:300;color:#0A2540;">${reportModules}</div>
            <div style="font-size:9px;color:#9aa3b2;text-transform:uppercase;letter-spacing:0.06em;margin-top:2px;">AI modules</div>
          </div>
        </td>
        <td width="25%" align="center" style="padding:0 4px;">
          <div style="background:${flagBg};border-radius:8px;padding:12px 8px;text-align:center;">
            <div style="font-size:1.4rem;font-weight:300;color:${flagColour};">${complianceFlags}</div>
            <div style="font-size:9px;color:#9aa3b2;text-transform:uppercase;letter-spacing:0.06em;margin-top:2px;">Compliance flags</div>
          </div>
        </td>
        <td width="25%" align="center" style="padding:0 4px;">
          <div style="background:#f4f5f8;border-radius:8px;padding:12px 8px;text-align:center;">
            <div style="font-size:1.4rem;font-weight:300;color:#0A2540;">${sessionDuration}</div>
            <div style="font-size:9px;color:#9aa3b2;text-transform:uppercase;letter-spacing:0.06em;margin-top:2px;">Duration</div>
          </div>
        </td>
        <td width="25%" align="center" style="padding:0 4px;">
          <div style="background:#e6f7f3;border-radius:8px;padding:12px 8px;text-align:center;">
            <div style="font-size:1.4rem;font-weight:300;color:#137a3c;">✓</div>
            <div style="font-size:9px;color:#9aa3b2;text-transform:uppercase;letter-spacing:0.06em;margin-top:2px;">Certified</div>
          </div>
        </td>
      </tr>
    </table>

    <!-- WHAT'S INSIDE -->
    <div style="background:#f4f5f8;border-radius:10px;padding:16px 20px;margin-bottom:24px;">
      <div style="font-size:12px;font-weight:600;color:#0A2540;margin-bottom:10px;">Your report includes:</div>
      <div style="font-size:11px;color:#4b5563;line-height:2;">
        ✓ &nbsp;Executive summary &amp; board verdict<br>
        ✓ &nbsp;Complete financial metrics extraction<br>
        ✓ &nbsp;Management tone &amp; evasion analysis<br>
        ✓ &nbsp;Full Q&amp;A log with AI triage classification<br>
        ✓ &nbsp;Compliance flags with regulatory obligations<br>
        ✓ &nbsp;Complete call transcript (speaker-labelled)<br>
        ✓ &nbsp;SENS/RNS press release draft<br>
        ✓ &nbsp;Social media content pack<br>
        ✓ &nbsp;Board &amp; analyst action items<br>
        ✓ &nbsp;SHA-256 blockchain disclosure certificate
      </div>
    </div>

    <!-- CTA -->
    <div style="text-align:center;margin-bottom:24px;">
      <a href="${reportUrl}" style="display:inline-block;background:${primary};color:#ffffff;text-decoration:none;font-size:14px;font-weight:600;padding:14px 36px;border-radius:9px;letter-spacing:0.01em;">
        📊 &nbsp;View my intelligence report
      </a>
    </div>

    ${complianceFlags > 0 ? `
    <!-- COMPLIANCE ALERT -->
    <div style="background:#fef0ee;border:1px solid rgba(192,41,26,0.2);border-radius:8px;padding:12px 16px;margin-bottom:16px;">
      <div style="font-size:12px;font-weight:600;color:#C0291A;margin-bottom:4px;">
        ⚠ &nbsp;${complianceFlags} compliance flag${complianceFlags > 1 ? "s" : ""} require${complianceFlags === 1 ? "s" : ""} attention
      </div>
      <div style="font-size:11px;color:#6b7280;line-height:1.6;">
        Your report includes compliance flags with regulatory obligations and required actions. 
        Please review these immediately — some may have time-sensitive filing deadlines.
      </div>
    </div>` : ""}

    <!-- SECURITY NOTE -->
    <div style="background:#f4f5f8;border-radius:8px;padding:12px 16px;font-size:11px;color:#9aa3b2;line-height:1.6;">
      🔒 &nbsp;Your report link is personal and expires on ${expiry}. 
      A PDF download is available inside the report. 
      Your access is read-only and tracked for the compliance audit trail.
    </div>
  `;

  return emailWrapper(brand, content);
}
