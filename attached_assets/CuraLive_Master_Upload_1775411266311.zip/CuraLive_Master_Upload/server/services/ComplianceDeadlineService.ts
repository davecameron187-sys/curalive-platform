// ─────────────────────────────────────────────────────────────
// CuraLive — Compliance Deadline Tracker Service
// File: server/services/ComplianceDeadlineService.ts
// Covers: Gap 11.2 (deadline tracking + escalation)
//         Gap 11.3 (compliance-only email on session close)
//
// ADD TO server/_core/index.ts startup:
//   import { startComplianceDeadlineMonitor } from "../services/ComplianceDeadlineService";
//   startComplianceDeadlineMonitor(); // runs every 15 minutes
// ─────────────────────────────────────────────────────────────

import { getDb } from "../db";
import { complianceDeadlines } from "../../drizzle/schema";
import { lt, eq, and, isNull } from "drizzle-orm";
import { Resend } from "resend";
import { buildComplianceAlertEmail } from "../emails/templates";

const resend = new Resend(process.env.RESEND_API_KEY);

// ── CREATE DEADLINE WHEN FLAG IS RAISED ──────────────────────
export async function createComplianceDeadline(opts: {
  sessionId:    number;
  flagId?:      number;
  action:       string;
  deadlineHours: number; // hours from now
  jurisdiction: string;
  assignedTo?:  string;
  priority?:    "critical" | "high" | "medium";
}) {
  const db = await getDb();
  if (!db) return;

  const deadline = new Date();
  deadline.setHours(deadline.getHours() + opts.deadlineHours);

  const [created] = await db
    .insert(complianceDeadlines)
    .values({
      sessionId:    opts.sessionId,
      flagId:       opts.flagId,
      action:       opts.action,
      deadline,
      jurisdiction: opts.jurisdiction,
      priority:     opts.priority ?? "high",
      assignedTo:   opts.assignedTo,
      status:       "open",
    })
    .returning();

  return created;
}

// ── MONITOR: runs every 15 minutes ───────────────────────────
export function startComplianceDeadlineMonitor() {
  const INTERVAL_MS = 15 * 60 * 1000; // 15 minutes

  async function runCheck() {
    const db = await getDb();
    if (!db) return;

    const now = new Date();
    const in2Hours = new Date(now.getTime() + 2 * 60 * 60 * 1000);
    const in24Hours = new Date(now.getTime() + 24 * 60 * 60 * 1000);

    // Get all open deadlines
    const openDeadlines = await db
      .select()
      .from(complianceDeadlines)
      .where(eq(complianceDeadlines.status, "open"));

    for (const d of openDeadlines) {
      const timeToDeadline = d.deadline.getTime() - now.getTime();
      const hoursRemaining = timeToDeadline / (1000 * 60 * 60);

      // OVERDUE → escalate
      if (d.deadline < now && d.status === "open") {
        await db
          .update(complianceDeadlines)
          .set({ status: "escalated", escalatedAt: now })
          .where(eq(complianceDeadlines.id, d.id));

        if (d.assignedTo) {
          await sendDeadlineAlert(d, "overdue", hoursRemaining);
        }
        continue;
      }

      // <2 hours remaining → urgent alert
      if (hoursRemaining < 2 && !d.reminderSentAt) {
        await db
          .update(complianceDeadlines)
          .set({ reminderSentAt: now })
          .where(eq(complianceDeadlines.id, d.id));

        if (d.assignedTo) {
          await sendDeadlineAlert(d, "urgent", hoursRemaining);
        }
        continue;
      }

      // <24 hours → reminder (once only)
      if (hoursRemaining < 24 && !d.reminderSentAt) {
        await db
          .update(complianceDeadlines)
          .set({ reminderSentAt: now })
          .where(eq(complianceDeadlines.id, d.id));

        if (d.assignedTo) {
          await sendDeadlineAlert(d, "reminder", hoursRemaining);
        }
      }
    }
  }

  // Run immediately then on interval
  runCheck().catch(console.error);
  setInterval(() => runCheck().catch(console.error), INTERVAL_MS);

  console.log("[ComplianceDeadlineMonitor] Started — checking every 15 minutes");
}

async function sendDeadlineAlert(
  deadline: any,
  urgency: "reminder" | "urgent" | "overdue",
  hoursRemaining: number
) {
  const subject = {
    reminder: `Compliance action due in ${Math.round(hoursRemaining)} hours — ${deadline.jurisdiction}`,
    urgent:   `⚠ URGENT: Compliance action due in ${Math.round(hoursRemaining)} hours`,
    overdue:  `🚨 OVERDUE: Compliance action deadline missed — immediate action required`,
  }[urgency];

  const color = { reminder: "#BA7517", urgent: "#C0291A", overdue: "#8B0000" }[urgency];

  const html = `
    <!DOCTYPE html><html><body style="font-family:sans-serif;background:#f4f5f8;padding:24px;">
    <div style="max-width:560px;margin:0 auto;background:#fff;border-radius:12px;overflow:hidden;border:1px solid #e2e5ed;">
      <div style="background:#0A2540;padding:20px 24px;">
        <div style="font-size:18px;font-weight:300;color:#fff;">CuraLive · Compliance Alert</div>
      </div>
      <div style="padding:24px;">
        <div style="background:${color}15;border:1px solid ${color}30;border-radius:8px;padding:14px;margin-bottom:16px;">
          <div style="font-size:13px;font-weight:600;color:${color};margin-bottom:4px;">${subject}</div>
        </div>
        <div style="font-size:13px;color:#2c3042;line-height:1.7;margin-bottom:16px;">
          <strong>Action required:</strong><br>${deadline.action}
        </div>
        <div style="font-size:12px;color:#6b7280;">
          Jurisdiction: ${deadline.jurisdiction}<br>
          Deadline: ${deadline.deadline.toLocaleString()}<br>
          Priority: ${deadline.priority?.toUpperCase()}<br>
          Session ID: ${deadline.sessionId}
        </div>
      </div>
    </div>
    </body></html>
  `;

  try {
    await resend.emails.send({
      from:    "CuraLive Compliance <compliance@curalive.com>",
      to:      deadline.assignedTo,
      subject,
      html,
    });
  } catch (err) {
    console.error("[ComplianceDeadline] Email send failed:", err);
  }
}

// ── GAP 11.3 — SEND COMPLIANCE-ONLY EMAIL ON SESSION CLOSE ───
export async function sendComplianceCloseEmail(opts: {
  sessionId:        number;
  companyName:      string;
  eventName:        string;
  flags:            Array<{ title: string; body: string; severity: string }>;
  deadlines:        Array<{ action: string; deadline: Date; jurisdiction: string }>;
  recipients:       Array<{ name: string; email: string }>;
  partnerId?:       number;
}) {
  if (!opts.flags.length || !opts.recipients.length) return;

  // Send to compliance-role recipients only
  for (const recipient of opts.recipients) {
    const html = buildComplianceCloseEmail({
      recipientName: recipient.name,
      companyName:   opts.companyName,
      eventName:     opts.eventName,
      flags:         opts.flags,
      deadlines:     opts.deadlines,
    });

    await resend.emails.send({
      from:    "CuraLive Compliance <compliance@curalive.com>",
      to:      recipient.email,
      subject: `🚨 ${opts.flags.length} compliance flag${opts.flags.length > 1 ? "s" : ""} require action — ${opts.companyName} ${opts.eventName}`,
      html,
    });
  }
}

function buildComplianceCloseEmail(opts: {
  recipientName:  string;
  companyName:    string;
  eventName:      string;
  flags:          Array<{ title: string; body: string; severity: string }>;
  deadlines:      Array<{ action: string; deadline: Date; jurisdiction: string }>;
}): string {
  const flagsHtml = opts.flags.map(f => `
    <div style="background:${f.severity === 'critical' ? '#fef0ee' : '#fef8e8'};border:1px solid ${f.severity === 'critical' ? 'rgba(192,41,26,0.2)' : 'rgba(186,117,23,0.2)'};border-radius:8px;padding:12px 14px;margin-bottom:10px;">
      <div style="font-size:12px;font-weight:600;color:${f.severity === 'critical' ? '#C0291A' : '#BA7517'};margin-bottom:4px;">${f.severity === 'critical' ? '🚨' : '⚠'} ${f.title}</div>
      <div style="font-size:11px;color:#6b7280;line-height:1.6;">${f.body}</div>
    </div>
  `).join("");

  const deadlinesHtml = opts.deadlines.map(d => `
    <div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #f0f0f0;font-size:11px;">
      <span style="color:#2c3042;">${d.action}</span>
      <span style="color:#C0291A;font-weight:600;">${d.deadline.toLocaleDateString()} · ${d.jurisdiction}</span>
    </div>
  `).join("");

  return `<!DOCTYPE html><html><body style="font-family:sans-serif;background:#f4f5f8;padding:24px;">
    <div style="max-width:560px;margin:0 auto;background:#fff;border-radius:12px;overflow:hidden;border:1px solid #e2e5ed;">
      <div style="background:#0A2540;padding:20px 24px;">
        <div style="font-size:18px;font-weight:300;color:#fff;">CuraLive · Compliance Summary</div>
        <div style="font-size:12px;color:rgba(255,255,255,0.4);margin-top:2px;">${opts.companyName} — ${opts.eventName}</div>
      </div>
      <div style="padding:24px;">
        <p style="font-size:13px;color:#2c3042;line-height:1.7;margin-bottom:20px;">Hi ${opts.recipientName},<br><br>
        CuraLive detected <strong>${opts.flags.length} compliance flag${opts.flags.length > 1 ? 's' : ''}</strong> during this session that require your attention.</p>
        ${flagsHtml}
        ${opts.deadlines.length ? `<div style="margin-top:20px;"><div style="font-size:12px;font-weight:600;color:#0A2540;margin-bottom:8px;">Action deadlines</div>${deadlinesHtml}</div>` : ''}
        <div style="margin-top:20px;background:#f4f5f8;border-radius:8px;padding:12px;font-size:11px;color:#6b7280;">Your full intelligence report with complete compliance analysis will follow shortly. This compliance summary is sent immediately on session close to allow timely action.</div>
      </div>
    </div>
  </body></html>`;
}
