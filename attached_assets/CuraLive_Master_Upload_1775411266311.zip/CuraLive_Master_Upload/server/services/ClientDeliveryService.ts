// ─────────────────────────────────────────────────────────────
// CuraLive — Client Delivery Service
// File: server/services/ClientDeliveryService.ts
// Called by: shadowModeRouter.ts on session close
//            webcastRouter.ts on session end
// ─────────────────────────────────────────────────────────────

import { nanoid } from "nanoid";
import { getDb } from "../db";
import { clientTokens, partners, shadow_sessions } from "../../drizzle/schema";
import { eq } from "drizzle-orm";
import { Resend } from "resend";
import { buildLiveEmail, buildReportEmail } from "../emails/templates";

const resend = new Resend(process.env.RESEND_API_KEY);
const APP_URL = process.env.APP_URL ?? "https://app.curalive.com";

export interface DeliveryRecipient {
  name:    string;
  email:   string;
  role?:   string;
}

export interface DeliveryOptions {
  sessionId:   number;
  eventId?:    number;
  partnerId?:  number;
  eventName:   string;
  companyName: string;
  eventDate:   string;
  recipients:  DeliveryRecipient[];
}

// ── SEND LIVE DASHBOARD LINK ──────────────────────────────────
// Call this when a session goes LIVE
// Sends each recipient a token-authenticated link to the live view
export async function sendLiveDashboardLinks(opts: DeliveryOptions) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const brand = opts.partnerId
    ? await getPartnerBrand(opts.partnerId)
    : curaliveDefaults();

  const results = [];

  for (const recipient of opts.recipients) {
    try {
      // Generate token
      const token = nanoid(48);
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + 1); // Live link expires in 24h

      await db.insert(clientTokens).values({
        token,
        sessionId:      opts.sessionId,
        eventId:        opts.eventId,
        partnerId:      opts.partnerId,
        recipientName:  recipient.name,
        recipientEmail: recipient.email,
        recipientRole:  recipient.role,
        accessType:     "live",
        expiresAt,
        emailStatus:    "pending",
      });

      const liveUrl = buildUrl("live", token, brand);

      // Send email
      const emailHtml = buildLiveEmail({
        brand,
        recipientName: recipient.name,
        eventName:     opts.eventName,
        companyName:   opts.companyName,
        eventDate:     opts.eventDate,
        liveUrl,
        expiresAt,
      });

      const { data, error } = await resend.emails.send({
        from:    `${brand.sendingName} <${brand.sendingEmail ?? "noreply@curalive.com"}>`,
        to:      recipient.email,
        subject: `🔴 LIVE NOW — ${opts.companyName} ${opts.eventName}`,
        html:    emailHtml,
      });

      if (error) throw error;

      // Update email status
      await db
        .update(clientTokens)
        .set({ emailSentAt: new Date(), emailStatus: "sent" })
        .where(eq(clientTokens.token, token));

      results.push({ email: recipient.email, status: "sent", messageId: data?.id });
    } catch (err) {
      console.error(`[ClientDelivery] Failed to send live link to ${recipient.email}:`, err);
      results.push({ email: recipient.email, status: "failed", error: String(err) });
    }
  }

  return results;
}

// ── SEND POST-EVENT REPORT LINK ───────────────────────────────
// Call this when session closes + report generation complete
export async function sendReportLinks(
  opts: DeliveryOptions & {
    reportModules: number;
    complianceFlags: number;
    sessionDuration: string;
  }
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const brand = opts.partnerId
    ? await getPartnerBrand(opts.partnerId)
    : curaliveDefaults();

  const results = [];

  for (const recipient of opts.recipients) {
    try {
      const token = nanoid(48);
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + 30); // Report link valid 30 days

      await db.insert(clientTokens).values({
        token,
        sessionId:      opts.sessionId,
        eventId:        opts.eventId,
        partnerId:      opts.partnerId,
        recipientName:  recipient.name,
        recipientEmail: recipient.email,
        recipientRole:  recipient.role,
        accessType:     "report",
        expiresAt,
        emailStatus:    "pending",
      });

      const reportUrl = buildUrl("report", token, brand);

      const emailHtml = buildReportEmail({
        brand,
        recipientName:    recipient.name,
        eventName:        opts.eventName,
        companyName:      opts.companyName,
        eventDate:        opts.eventDate,
        reportUrl,
        reportModules:    opts.reportModules,
        complianceFlags:  opts.complianceFlags,
        sessionDuration:  opts.sessionDuration,
        expiresAt,
      });

      const { data, error } = await resend.emails.send({
        from:    `${brand.sendingName} <${brand.sendingEmail ?? "noreply@curalive.com"}>`,
        to:      recipient.email,
        subject: `📊 Your intelligence report is ready — ${opts.companyName} ${opts.eventName}`,
        html:    emailHtml,
      });

      if (error) throw error;

      await db
        .update(clientTokens)
        .set({ emailSentAt: new Date(), emailStatus: "sent" })
        .where(eq(clientTokens.token, token));

      results.push({ email: recipient.email, status: "sent", messageId: data?.id });
    } catch (err) {
      console.error(`[ClientDelivery] Failed to send report link to ${recipient.email}:`, err);
      results.push({ email: recipient.email, status: "failed", error: String(err) });
    }
  }

  return results;
}

// ── HELPERS ──────────────────────────────────────────────────

function buildUrl(type: "live" | "report", token: string, brand: ReturnType<typeof curaliveDefaults>) {
  const base = brand.customDomain
    ? `https://${brand.customDomain}`
    : APP_URL;
  return `${base}/${type}/${token}`;
}

async function getPartnerBrand(partnerId: number) {
  const db = await getDb();
  if (!db) return curaliveDefaults();
  const [p] = await db
    .select()
    .from(partners)
    .where(eq(partners.id, partnerId))
    .limit(1);
  if (!p) return curaliveDefaults();
  return {
    isWhiteLabel:  true,
    slug:          p.slug,
    name:          p.name,
    displayName:   p.displayName,
    logoUrl:       p.logoUrl,
    primaryColor:  p.primaryColor,
    accentColor:   p.accentColor,
    sendingName:   p.sendingName ?? p.name,
    sendingEmail:  p.sendingEmail ?? "noreply@curalive.com",
    customDomain:  p.customDomain,
  };
}

function curaliveDefaults() {
  return {
    isWhiteLabel:  false,
    slug:          "curalive",
    name:          "CuraLive",
    displayName:   "CuraLive Intelligence",
    logoUrl:       null as string | null,
    primaryColor:  "#1D9E75",
    accentColor:   "#0A2540",
    sendingName:   "CuraLive",
    sendingEmail:  "noreply@curalive.com",
    customDomain:  null as string | null,
  };
}
