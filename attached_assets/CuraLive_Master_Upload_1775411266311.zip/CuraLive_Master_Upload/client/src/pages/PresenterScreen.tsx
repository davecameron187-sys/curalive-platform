// ─────────────────────────────────────────────────────────────
// CuraLive — Presenter Screen
// File: client/src/pages/PresenterScreen.tsx
// Route: /presenter/:token
// Add to App.tsx: <Route path="/presenter/:token" component={PresenterScreen} />
//
// This is the screen the CFO/CEO/presenter has open during the event.
// Shows: next approved question, AI suggested answer, queue count.
// Operator pushes questions here via speakerQueue.sendToSpeaker
// Full-screen, minimal, designed for a second monitor or tablet.
// ─────────────────────────────────────────────────────────────

import { useState, useEffect } from "react";
import { useParams } from "wouter";
import { trpc } from "../lib/trpc";
import { useAbly } from "../contexts/AblyContext";

interface QueueItem {
  id:                number;
  questionText:      string;
  askerName?:        string;
  askerFirm?:        string;
  aiSuggestedAnswer?:string;
  status:            string;
  queuePosition:     number;
}

export default function PresenterScreen() {
  const { token } = useParams<{ token: string }>();
  const ably = useAbly();
  const [activeQuestion, setActiveQuestion] = useState<QueueItem | null>(null);
  const [queue, setQueue]                   = useState<QueueItem[]>([]);
  const [sessionId, setSessionId]           = useState<number | null>(null);
  const [showSuggestion, setShowSuggestion] = useState(false);
  const [connected, setConnected]           = useState(false);

  // Validate presenter token
  const { data: tokenData } = trpc.partners.validateToken.useQuery(
    { token: token ?? "", accessType: "live" as any },
    { enabled: !!token, retry: false }
  );

  useEffect(() => {
    if (tokenData?.valid && tokenData.sessionId) {
      setSessionId(tokenData.sessionId);
      setConnected(true);
    }
  }, [tokenData]);

  // Subscribe to speaker channel
  useEffect(() => {
    if (!ably || !sessionId) return;
    const channel = ably.channels.get(`speaker-${sessionId}`);

    channel.subscribe("question.active", (msg) => {
      setActiveQuestion(msg.data);
      setShowSuggestion(false); // hide suggestion until presenter requests it
    });

    channel.subscribe("question.answered", () => {
      setActiveQuestion(null);
      setShowSuggestion(false);
    });

    channel.subscribe("question.queued", (msg) => {
      setQueue(prev => {
        const updated = [...prev];
        const existing = updated.findIndex(q => q.id === msg.data.id);
        if (existing >= 0) updated[existing] = msg.data;
        else updated.push(msg.data);
        return updated.sort((a, b) => a.queuePosition - b.queuePosition);
      });
    });

    return () => { channel.unsubscribe(); };
  }, [ably, sessionId]);

  if (!tokenData?.valid) {
    return (
      <div style={{ height: "100vh", background: "#05060a", display: "flex", alignItems: "center", justifyContent: "center", color: "rgba(255,255,255,0.3)", fontFamily: "'DM Sans',sans-serif" }}>
        <div style={{ textAlign: "center" }}>
          <div style={{ fontSize: 48, marginBottom: 16 }}>🔒</div>
          <div>Presenter access link invalid or expired.</div>
        </div>
      </div>
    );
  }

  const upNext = queue.filter(q => q.status === "queued").slice(0, 3);

  return (
    <div style={{
      height: "100vh",
      background: "#05060a",
      display: "flex",
      flexDirection: "column",
      fontFamily: "'DM Sans',sans-serif",
      overflow: "hidden",
      position: "relative",
    }}>
      {/* Grid background */}
      <div style={{
        position: "fixed", inset: 0,
        backgroundImage: "linear-gradient(rgba(0,212,255,0.02) 1px,transparent 1px),linear-gradient(90deg,rgba(0,212,255,0.02) 1px,transparent 1px)",
        backgroundSize: "48px 48px",
        pointerEvents: "none",
      }} />

      {/* Header */}
      <div style={{
        padding: "16px 32px",
        borderBottom: "1px solid rgba(255,255,255,0.05)",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        background: "rgba(13,17,32,0.9)",
        backdropFilter: "blur(20px)",
        position: "relative", zIndex: 1,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 28, height: 28, background: "linear-gradient(135deg,#00d4ff,rgba(0,212,255,0.5))", borderRadius: 7, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 700, color: "#05060a" }}>CL</div>
          <span style={{ fontSize: 13, fontWeight: 600, color: "#f0f2f8" }}>Presenter Screen</span>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <div style={{ width: 7, height: 7, borderRadius: "50%", background: connected ? "#00e676" : "#ff3d57", boxShadow: `0 0 8px ${connected ? "#00e676" : "#ff3d57"}` }} />
          <span style={{ fontSize: 10, color: connected ? "#00e676" : "#ff3d57", fontWeight: 600 }}>{connected ? "CONNECTED" : "DISCONNECTED"}</span>
          <span style={{ fontSize: 10, color: "rgba(255,255,255,0.2)", marginLeft: 8 }}>Read-only · Operator controlled</span>
        </div>
      </div>

      <div style={{ flex: 1, display: "grid", gridTemplateRows: activeQuestion ? "1fr auto" : "1fr", overflow: "hidden", position: "relative", zIndex: 1 }}>

        {/* ACTIVE QUESTION */}
        {activeQuestion ? (
          <div style={{ padding: "40px 48px", display: "flex", flexDirection: "column", justifyContent: "center" }}>

            {/* Source */}
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 24 }}>
              <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: ".16em", textTransform: "uppercase", color: "#00d4ff", background: "rgba(0,212,255,0.08)", border: "1px solid rgba(0,212,255,0.2)", borderRadius: 100, padding: "4px 14px" }}>
                Approved question
              </div>
              {activeQuestion.askerFirm && (
                <div style={{ fontSize: 12, color: "rgba(255,255,255,0.4)", fontWeight: 500 }}>
                  {activeQuestion.askerFirm}
                  {activeQuestion.askerName && ` — ${activeQuestion.askerName}`}
                </div>
              )}
            </div>

            {/* Question */}
            <div style={{
              fontSize: "clamp(1.4rem,3vw,2.2rem)",
              fontWeight: 300,
              color: "#f0f2f8",
              lineHeight: 1.4,
              letterSpacing: "-0.02em",
              marginBottom: 32,
              maxWidth: 900,
            }}>
              "{activeQuestion.questionText}"
            </div>

            {/* AI Suggestion toggle */}
            {activeQuestion.aiSuggestedAnswer && (
              <div>
                <button
                  onClick={() => setShowSuggestion(s => !s)}
                  style={{
                    background: showSuggestion ? "rgba(0,212,255,0.12)" : "rgba(255,255,255,0.04)",
                    border: "1px solid rgba(0,212,255,0.25)",
                    borderRadius: 8,
                    color: "#00d4ff",
                    padding: "10px 20px",
                    fontSize: 12,
                    fontWeight: 600,
                    cursor: "pointer",
                    fontFamily: "inherit",
                    letterSpacing: ".04em",
                    marginBottom: showSuggestion ? 16 : 0,
                    transition: "all .2s",
                  }}
                >
                  {showSuggestion ? "▲ Hide" : "▼ Show"} AI suggested talking points
                </button>
                {showSuggestion && (
                  <div style={{
                    background: "rgba(0,212,255,0.05)",
                    border: "1px solid rgba(0,212,255,0.15)",
                    borderRadius: 10,
                    padding: "16px 20px",
                    fontSize: 14,
                    color: "rgba(255,255,255,0.7)",
                    lineHeight: 1.7,
                    maxWidth: 800,
                    fontStyle: "italic",
                    animation: "fadeIn .2s ease",
                  }}>
                    {activeQuestion.aiSuggestedAnswer}
                  </div>
                )}
              </div>
            )}
          </div>
        ) : (
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column", gap: 16 }}>
            <div style={{ width: 80, height: 80, borderRadius: "50%", background: "rgba(0,212,255,0.05)", border: "1px solid rgba(0,212,255,0.1)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 32 }}>⏳</div>
            <div style={{ fontSize: 18, fontWeight: 300, color: "rgba(255,255,255,0.3)", letterSpacing: "-0.02em" }}>
              Waiting for next approved question
            </div>
            <div style={{ fontSize: 12, color: "rgba(255,255,255,0.15)" }}>
              Your operator will send approved questions here
            </div>
          </div>
        )}

        {/* QUEUE PREVIEW */}
        {upNext.length > 0 && (
          <div style={{ borderTop: "1px solid rgba(255,255,255,0.05)", padding: "16px 48px", background: "rgba(8,11,18,0.9)" }}>
            <div style={{ fontSize: 9, fontWeight: 600, letterSpacing: ".16em", textTransform: "uppercase", color: "rgba(255,255,255,0.2)", marginBottom: 10 }}>
              Up next ({upNext.length} queued)
            </div>
            <div style={{ display: "flex", gap: 12 }}>
              {upNext.map((q, i) => (
                <div key={q.id} style={{
                  background: "rgba(255,255,255,0.03)",
                  border: "1px solid rgba(255,255,255,0.06)",
                  borderRadius: 8,
                  padding: "10px 14px",
                  flex: 1,
                  opacity: 1 - (i * 0.25),
                }}>
                  {q.askerFirm && <div style={{ fontSize: 10, fontWeight: 600, color: "rgba(255,171,0,0.7)", marginBottom: 4 }}>{q.askerFirm}</div>}
                  <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)", lineHeight: 1.5 }}>
                    {q.questionText.slice(0, 80)}{q.questionText.length > 80 ? "..." : ""}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      <style>{`@keyframes fadeIn{from{opacity:0;transform:translateY(4px);}to{opacity:1;transform:translateY(0);}}`}</style>
    </div>
  );
}
