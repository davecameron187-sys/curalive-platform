// ─────────────────────────────────────────────────────────────
// CuraLive — Client Report Page
// File: client/src/pages/ClientReport.tsx
// Route: /report/:token
// Add to App.tsx: <Route path="/report/:token" component={ClientReport} />
// ─────────────────────────────────────────────────────────────

import { useState, useEffect } from "react";
import { useParams } from "wouter";
import { trpc } from "../lib/trpc";
import { useBrandConfig, injectBrandCSSVars } from "../hooks/useBrandConfig";

type TabId = "summary" | "financials" | "compliance" | "tone" | "qa" | "transcript" | "actions" | "social" | "sens" | "cert";

export default function ClientReport() {
  const { token } = useParams<{ token: string }>();
  const brand = useBrandConfig();
  const [activeTab, setActiveTab] = useState<TabId>("summary");

  useEffect(() => { injectBrandCSSVars(brand); }, [brand]);

  // Validate token
  const { data: tokenData, isLoading } = trpc.partners.validateToken.useQuery(
    { token: token ?? "", accessType: "report" },
    { enabled: !!token, retry: false }
  );

  // Fetch session report data
  const { data: reportData } = trpc.shadowMode.getSessionReport.useQuery(
    { sessionId: tokenData?.sessionId ?? 0 },
    { enabled: !!tokenData?.valid && !!tokenData?.sessionId }
  );

  if (isLoading) return <LoadingScreen brand={brand} />;
  if (!tokenData?.valid) return <InvalidToken brand={brand} reason={tokenData?.reason} />;
  if (!reportData) return <LoadingScreen brand={brand} message="Loading your intelligence report..." />;

  const report     = reportData.aiReport    ? JSON.parse(reportData.aiReport) : {};
  const transcript = reportData.transcriptJson ? JSON.parse(reportData.transcriptJson) : [];
  const session    = reportData;

  const TABS: { id: TabId; label: string; badge?: number }[] = [
    { id: "summary",    label: "Executive summary" },
    { id: "financials", label: "Financial metrics" },
    { id: "compliance", label: "Compliance", badge: session.complianceFlagCount ?? 0 },
    { id: "tone",       label: "Management tone" },
    { id: "qa",         label: "Q&A log" },
    { id: "transcript", label: "Full transcript" },
    { id: "actions",    label: "Action items" },
    { id: "social",     label: "Social media pack" },
    { id: "sens",       label: "SENS/RNS draft" },
    { id: "cert",       label: "Certificate" },
  ];

  return (
    <div style={{ minHeight: "100vh", background: "#f4f5f8", fontFamily: brand.fontFamily }}>

      {/* ── HEADER ── */}
      <div style={{ position: "sticky", top: 0, zIndex: 100, background: brand.accentColor, height: 52, display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 24px", borderBottom: "1px solid rgba(255,255,255,0.07)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          {brand.logoUrl
            ? <img src={brand.logoUrl} alt={brand.name} style={{ height: 28 }} />
            : <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <div style={{ width: 26, height: 26, background: brand.primaryColor, borderRadius: 6, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 700, color: "#fff" }}>
                  {brand.name.slice(0, 2).toUpperCase()}
                </div>
                <span style={{ fontSize: 13, fontWeight: 600, color: "#fff" }}>{brand.displayName}</span>
              </div>
          }
          <div style={{ width: 1, height: 18, background: "rgba(255,255,255,0.15)" }} />
          <span style={{ fontSize: 11, color: "rgba(255,255,255,0.35)", fontFamily: "monospace" }}>
            {session.id} · Post-event report
          </span>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ fontSize: 10, color: "rgba(29,158,117,0.9)", fontWeight: 600, background: "rgba(29,158,117,0.12)", border: "1px solid rgba(29,158,117,0.25)", borderRadius: 100, padding: "4px 12px" }}>
            ✓ Certificate verified
          </div>
          <button
            onClick={() => window.print()}
            style={{ background: "rgba(255,255,255,0.08)", border: "1px solid rgba(255,255,255,0.12)", color: "#fff", borderRadius: 6, padding: "6px 14px", fontSize: 11, fontWeight: 500, cursor: "pointer" }}
          >
            ⬇ Download PDF
          </button>
        </div>
      </div>

      {/* ── EVENT BANNER ── */}
      <div style={{ background: brand.accentColor === "#0A2540" ? "#0c2d4a" : brand.accentColor, borderBottom: "1px solid rgba(255,255,255,0.06)", padding: "16px 24px" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto", display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: "1rem", flexWrap: "wrap" }}>
          <div>
            <div style={{ fontSize: 10, color: "rgba(255,255,255,0.3)", textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: 4 }}>
              {session.company ?? "Company"} · Post-event intelligence report
            </div>
            <div style={{ fontSize: "1.4rem", fontWeight: 300, color: "#fff", letterSpacing: "-0.02em", marginBottom: 6 }}>
              {session.eventName ?? "Earnings Call"} — <strong style={{ fontWeight: 600 }}>Intelligence Report</strong>
            </div>
            <div style={{ display: "flex", gap: 14, flexWrap: "wrap" }}>
              {[
                session.eventDate && `📅 ${session.eventDate}`,
                session.duration && `⏱ ${session.duration}`,
                "🔒 Blockchain certified",
                `🌍 ${session.jurisdiction ?? "JSE"} jurisdiction`,
              ].filter(Boolean).map((item, i) => (
                <span key={i} style={{ fontSize: 11, color: "rgba(255,255,255,0.4)" }}>{item}</span>
              ))}
            </div>
          </div>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {[
              { val: "20", label: "AI modules" },
              { val: String(session.complianceFlagCount ?? 0), label: "Flags", red: (session.complianceFlagCount ?? 0) > 0 },
              { val: String(session.qaCount ?? 0), label: "Q&A reviewed" },
              { val: `${session.confidenceScore ?? 74}%`, label: "Confidence" },
            ].map(stat => (
              <div key={stat.label} style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 8, padding: "8px 14px", textAlign: "center" }}>
                <div style={{ fontSize: "1.1rem", fontWeight: 300, color: stat.red ? "rgba(192,41,26,0.9)" : "#fff" }}>{stat.val}</div>
                <div style={{ fontSize: 9, color: "rgba(255,255,255,0.3)", textTransform: "uppercase", letterSpacing: "0.07em", marginTop: 2 }}>{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── TABS ── */}
      <div style={{ background: "#fff", borderBottom: "1px solid #e2e5ed", position: "sticky", top: 52, zIndex: 90 }}>
        <div style={{ maxWidth: 1100, margin: "0 auto", display: "flex", padding: "0 24px", overflowX: "auto" }}>
          {TABS.map(tab => (
            <button
              key={tab.id}
              onClick={() => { setActiveTab(tab.id); window.scrollTo({ top: 0 }); }}
              style={{
                padding: "13px 16px", fontSize: 12, fontWeight: activeTab === tab.id ? 600 : 500,
                color: activeTab === tab.id ? "#0A2540" : "#6b7280",
                borderBottom: `2px solid ${activeTab === tab.id ? "#0A2540" : "transparent"}`,
                background: "none", border: "none", borderTop: "none", borderLeft: "none", borderRight: "none",
                cursor: "pointer", whiteSpace: "nowrap", fontFamily: brand.fontFamily,
                display: "flex", alignItems: "center", gap: 6,
              }}
            >
              {tab.label}
              {tab.badge != null && tab.badge > 0 && (
                <span style={{ background: "#C0291A", color: "#fff", fontSize: 9, fontWeight: 700, padding: "1px 5px", borderRadius: 8, minWidth: 16, textAlign: "center" }}>
                  {tab.badge}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* ── CONTENT ── */}
      <div style={{ maxWidth: 1100, margin: "0 auto", padding: "24px 24px 60px" }}>
        <ReportContent
          tab={activeTab}
          report={report}
          session={session}
          transcript={transcript}
          brand={brand}
          primaryColor={brand.primaryColor}
        />
      </div>
    </div>
  );
}

// ── REPORT CONTENT ROUTER ─────────────────────────────────────
function ReportContent({ tab, report, session, transcript, brand, primaryColor }: any) {
  // Each tab renders its module content from the report JSON
  // The report JSON structure matches the 20-module output from aiAnalysis.ts
  // Keys: executiveSummary, financialMetrics, complianceFlags, managementTone, etc.

  const card = (title: string, badge: string, badgeColor: string, children: React.ReactNode) => (
    <div style={{ background: "#fff", border: "1px solid #e2e5ed", borderRadius: 12, marginBottom: 12, overflow: "hidden" }}>
      <div style={{ padding: "12px 18px", borderBottom: "1px solid #e2e5ed", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <span style={{ fontSize: 12, fontWeight: 600, color: "#0A2540" }}>{title}</span>
        <span style={{ fontSize: 10, fontWeight: 600, padding: "3px 9px", borderRadius: 5, background: badgeColor + "20", color: badgeColor }}>{badge}</span>
      </div>
      <div style={{ padding: "16px 18px" }}>{children}</div>
    </div>
  );

  const body = (text: string) => (
    <p style={{ fontSize: 11, color: "#2c3042", lineHeight: 1.75, margin: 0 }}>{text}</p>
  );

  switch (tab) {
    case "summary":
      return (
        <>
          {/* Executive summary card */}
          <div style={{ background: "#0A2540", borderRadius: 14, padding: 24, marginBottom: 16, borderLeft: `4px solid ${primaryColor}` }}>
            <p style={{ fontSize: "0.95rem", fontWeight: 300, color: "rgba(255,255,255,0.9)", lineHeight: 1.75, margin: "0 0 16px" }}>
              {report.executiveSummary?.verdict ?? "Executive summary loading..."}
            </p>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 10 }}>
              {(report.executiveSummary?.metrics ?? []).map((m: any, i: number) => (
                <div key={i} style={{ background: "rgba(255,255,255,0.06)", borderRadius: 8, padding: 12, textAlign: "center" }}>
                  <div style={{ fontSize: "1.2rem", fontWeight: 300, color: "#fff" }}>{m.value}</div>
                  <div style={{ fontSize: 9, color: "rgba(255,255,255,0.35)", textTransform: "uppercase", letterSpacing: "0.07em", marginTop: 2 }}>{m.label}</div>
                </div>
              ))}
            </div>
          </div>
          {card("Critical actions", `${report.criticalActions?.length ?? 0} required`, "#C0291A",
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {(report.criticalActions ?? []).map((a: any, i: number) => (
                <div key={i} style={{ display: "flex", gap: 10, fontSize: 11 }}>
                  <span style={{ color: a.priority === "urgent" ? "#C0291A" : "#BA7517", fontWeight: 700, flexShrink: 0 }}>{String(i + 1).padStart(2, "0")}</span>
                  <div><strong style={{ color: "#0A2540" }}>{a.title}</strong><br /><span style={{ color: "#6b7280" }}>{a.detail}</span></div>
                </div>
              ))}
            </div>
          )}
        </>
      );

    case "compliance":
      return (
        <>
          {(report.complianceFlags ?? []).map((flag: any, i: number) => (
            <div key={i} style={{ display: "flex", gap: 12, padding: "14px 16px", borderRadius: 10, marginBottom: 10, background: flag.severity === "critical" ? "#fef0ee" : flag.severity === "warning" ? "#fef8e8" : "#eff6ff", border: `1px solid ${flag.severity === "critical" ? "rgba(192,41,26,0.2)" : "rgba(186,117,23,0.2)"}` }}>
              <span style={{ fontSize: 18, flexShrink: 0 }}>{flag.severity === "critical" ? "🚨" : "⚠"}</span>
              <div>
                <div style={{ fontSize: 12, fontWeight: 600, color: flag.severity === "critical" ? "#C0291A" : "#BA7517", marginBottom: 3 }}>{flag.title}</div>
                <div style={{ fontSize: 11, color: "#6b7280", lineHeight: 1.6, marginBottom: 5 }}>{flag.description}</div>
                <span style={{ fontSize: 10, fontWeight: 600, padding: "2px 9px", borderRadius: 4, background: flag.severity === "critical" ? "rgba(192,41,26,0.1)" : "rgba(186,117,23,0.1)", color: flag.severity === "critical" ? "#C0291A" : "#BA7517" }}>
                  {flag.action}
                </span>
              </div>
            </div>
          ))}
        </>
      );

    case "transcript":
      return (
        <div style={{ background: "#fff", border: "1px solid #e2e5ed", borderRadius: 12, overflow: "hidden" }}>
          <div style={{ background: "#0A2540", padding: "12px 16px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <span style={{ fontSize: 11, fontWeight: 600, color: "#fff", letterSpacing: "0.04em" }}>COMPLETE TRANSCRIPT — WHISPER STT · SPEAKER-DIARISED</span>
            <span style={{ fontSize: 9, background: "rgba(29,158,117,0.2)", color: "rgba(100,240,150,0.9)", padding: "2px 8px", borderRadius: 4 }}>✓ SHA-256 certified</span>
          </div>
          <div style={{ maxHeight: 600, overflowY: "auto", padding: 14 }}>
            {transcript.map((line: any, i: number) => (
              <div key={i} style={{ display: "flex", gap: 12, marginBottom: 12, paddingBottom: 12, borderBottom: "1px solid #f0f0f0" }}>
                <span style={{ fontSize: 9, fontFamily: "monospace", color: "#9aa3b2", width: 36, flexShrink: 0 }}>{line.timestamp}</span>
                <span style={{ fontSize: 10, fontWeight: 600, color: line.role === "analyst" ? "#BA7517" : "#1246E8", width: 120, flexShrink: 0 }}>{line.speaker}</span>
                <span style={{ fontSize: 11, color: "#2c3042", lineHeight: 1.6 }}>
                  {line.text}
                  {line.flagged && <span style={{ display: "inline-block", marginLeft: 6, fontSize: 9, padding: "1px 6px", borderRadius: 4, background: "#fef0ee", color: "#C0291A", fontWeight: 600 }}>⚠ Flag</span>}
                </span>
              </div>
            ))}
          </div>
        </div>
      );

    case "cert":
      return (
        <div>
          <div style={{ background: "#0A2540", borderRadius: 14, padding: 22, marginBottom: 14 }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: "#fff", marginBottom: 3 }}>CuraLive Disclosure Certificate</div>
            <div style={{ fontSize: 10, color: "rgba(255,255,255,0.35)", marginBottom: 16 }}>SHA-256 hash-chained · Immutable · Blockchain anchored</div>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14, flexWrap: "wrap" }}>
              {["Transcript", "AI Report", "Flags", "Certificate"].map((label, i, arr) => (
                <>
                  <div key={label} style={{ background: "rgba(18,70,232,0.18)", border: "1px solid rgba(18,70,232,0.35)", borderRadius: 7, padding: "8px 14px", textAlign: "center" }}>
                    <div style={{ fontSize: 9, color: "rgba(150,185,255,0.7)", textTransform: "uppercase", letterSpacing: "0.08em", fontWeight: 600 }}>{label}</div>
                    <div style={{ fontSize: 9, fontFamily: "monospace", color: "rgba(150,185,255,0.45)", marginTop: 2 }}>{["a3f8c2e1", "b7d4e9f2", "c1a5b8d3", "f9e2c7a4"][i]}...</div>
                  </div>
                  {i < arr.length - 1 && <span style={{ color: "rgba(77,127,255,0.4)", fontSize: "1.1rem" }}>→</span>}
                </>
              ))}
            </div>
            <div style={{ fontFamily: "monospace", fontSize: 11, color: "rgba(150,185,255,0.65)", background: "rgba(18,70,232,0.1)", border: "1px solid rgba(18,70,232,0.2)", borderRadius: 7, padding: "9px 14px", marginBottom: 10 }}>
              {session.certificateId ?? "CL-2026-XXXX"} · {session.company} · {session.eventDate} · JSE jurisdiction
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 7, fontSize: 11, color: "rgba(29,158,117,0.9)", fontWeight: 600 }}>
              ✓ Blockchain anchor confirmed — immutable record locked
            </div>
          </div>
        </div>
      );

    default:
      // Generic module display for other tabs
      const moduleKey: Record<string, string> = {
        financials: "financialMetrics", tone: "managementTone",
        qa: "qaQuality", actions: "boardActions",
        social: "socialMediaPack", sens: "sensRnsDraft",
      };
      const key = moduleKey[tab];
      const moduleData = key ? report[key] : null;

      return (
        <div style={{ background: "#fff", border: "1px solid #e2e5ed", borderRadius: 12, padding: "16px 18px" }}>
          {moduleData
            ? <p style={{ fontSize: 11, color: "#2c3042", lineHeight: 1.75, whiteSpace: "pre-wrap" }}>
                {typeof moduleData === "string" ? moduleData : JSON.stringify(moduleData, null, 2)}
              </p>
            : <p style={{ fontSize: 11, color: "#9aa3b2" }}>This module is loading or not yet available.</p>
          }
        </div>
      );
  }
}

function LoadingScreen({ brand, message }: { brand: any; message?: string }) {
  return (
    <div style={{ height: "100vh", background: brand.accentColor, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", color: "#fff" }}>
      <div style={{ fontSize: 14, color: "rgba(255,255,255,0.5)", marginTop: 12 }}>{message ?? "Verifying access..."}</div>
    </div>
  );
}

function InvalidToken({ brand, reason }: { brand: any; reason?: string }) {
  return (
    <div style={{ height: "100vh", background: brand.accentColor, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", color: "#fff", textAlign: "center", padding: "2rem" }}>
      <div style={{ fontSize: 48, marginBottom: "1rem" }}>🔒</div>
      <h1 style={{ fontSize: "1.4rem", fontWeight: 300, marginBottom: "0.5rem" }}>Report access invalid</h1>
      <p style={{ fontSize: "0.9rem", color: "rgba(255,255,255,0.4)", maxWidth: 360, lineHeight: 1.6 }}>
        {reason === "Token expired" ? "This report link has expired. Links are valid for 30 days post-event." : "This link could not be verified. Please contact your event organiser."}
      </p>
    </div>
  );
}
