// ─────────────────────────────────────────────────────────────
// CuraLive — Live Client Dashboard
// File: client/src/pages/ClientLive.tsx
// Route: /live/:token
// Add to App.tsx: <Route path="/live/:token" component={ClientLive} />
// ─────────────────────────────────────────────────────────────

import { useState, useEffect, useRef } from "react";
import { useParams } from "wouter";
import { trpc } from "../lib/trpc";
import { useBrandConfig, injectBrandCSSVars } from "../hooks/useBrandConfig";
import { useAbly } from "../contexts/AblyContext";

// ── TYPES ─────────────────────────────────────────────────────
interface TranscriptLine {
  id:        string;
  speaker:   string;
  text:      string;
  timestamp: number;
  flagged?:  boolean;
  flagText?: string;
  flagType?: "critical" | "warning";
}

interface SentimentState {
  confidence:  number;
  positivity:  number;
  hedging:     number;
  riskLevel:   number;
}

interface ComplianceFlag {
  id:       string;
  severity: "critical" | "warning" | "info";
  title:    string;
  body:     string;
  detectedAt: string;
}

interface QAItem {
  id:         string;
  asker:      string;
  question:   string;
  triage:     "approved" | "risk" | "duplicate" | "off_topic";
  receivedAt: string;
}

// ── COMPONENT ─────────────────────────────────────────────────
export default function ClientLive() {
  const { token } = useParams<{ token: string }>();
  const brand = useBrandConfig();
  const ably = useAbly();
  const transcriptRef = useRef<HTMLDivElement>(null);

  // State
  const [transcript, setTranscript]     = useState<TranscriptLine[]>([]);
  const [sentiment, setSentiment]        = useState<SentimentState>({ confidence: 0, positivity: 0, hedging: 0, riskLevel: 0 });
  const [flags, setFlags]                = useState<ComplianceFlag[]>([]);
  const [qaItems, setQaItems]            = useState<QAItem[]>([]);
  const [summary, setSummary]            = useState("Waiting for session to begin...");
  const [sessionActive, setSessionActive] = useState(false);
  const [sessionEnded, setSessionEnded]  = useState(false);
  const [duration, setDuration]          = useState(0);
  const [startTime, setStartTime]        = useState<number | null>(null);
  const [reportUrl, setReportUrl]        = useState<string | null>(null);

  // Validate token
  const { data: tokenData, isLoading, error } = trpc.partners.validateToken.useQuery(
    { token: token ?? "", accessType: "live" },
    { enabled: !!token, retry: false }
  );

  // Inject brand CSS
  useEffect(() => { injectBrandCSSVars(brand); }, [brand]);

  // Duration timer
  useEffect(() => {
    if (!sessionActive || sessionEnded) return;
    const interval = setInterval(() => {
      setDuration(d => d + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [sessionActive, sessionEnded]);

  // Scroll transcript to bottom
  useEffect(() => {
    if (transcriptRef.current) {
      transcriptRef.current.scrollTop = transcriptRef.current.scrollHeight;
    }
  }, [transcript]);

  // Ably subscription — subscribe to session channel
  useEffect(() => {
    if (!tokenData?.valid || !tokenData.sessionId) return;
    const channelName = `session-${tokenData.sessionId}`;
    const channel = ably?.channels.get(channelName);
    if (!channel) return;

    // Transcript segments
    channel.subscribe("transcript.segment", (msg) => {
      const seg = msg.data;
      setTranscript(prev => [...prev, {
        id:        seg.id ?? Date.now().toString(),
        speaker:   seg.speaker ?? "Unknown",
        text:      seg.text ?? "",
        timestamp: seg.timestamp ?? Date.now(),
        flagged:   seg.flagged ?? false,
        flagText:  seg.flagText,
        flagType:  seg.flagType,
      }]);
      if (!sessionActive) {
        setSessionActive(true);
        setStartTime(Date.now());
      }
    });

    // Sentiment updates
    channel.subscribe("sentiment.update", (msg) => {
      setSentiment(msg.data);
    });

    // Compliance flags
    channel.subscribe("compliance.flag", (msg) => {
      setFlags(prev => [...prev, {
        id:          msg.data.id ?? Date.now().toString(),
        severity:    msg.data.severity ?? "warning",
        title:       msg.data.title ?? "",
        body:        msg.data.body ?? "",
        detectedAt:  msg.data.detectedAt ?? new Date().toISOString(),
      }]);
    });

    // Q&A
    channel.subscribe("qa.question", (msg) => {
      setQaItems(prev => [msg.data, ...prev].slice(0, 20));
    });

    // Rolling summary
    channel.subscribe("summary.update", (msg) => {
      setSummary(msg.data.text);
    });

    // Session ended
    channel.subscribe("session.ended", (msg) => {
      setSessionActive(false);
      setSessionEnded(true);
      if (msg.data.reportUrl) setReportUrl(msg.data.reportUrl);
    });

    return () => { channel.unsubscribe(); };
  }, [tokenData, ably]);

  // ── LOADING ────────────────────────────────────────────────
  if (isLoading) return <LoadingScreen brand={brand} />;
  if (!tokenData?.valid) return <InvalidToken brand={brand} reason={tokenData?.reason} />;

  const fmt = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s.toString().padStart(2, "0")}`;
  };

  const triageColour = (t: string) => ({
    approved:  { bg: "#e8f7ef", text: "#137a3c", label: "✓ Approved" },
    risk:      { bg: "#fef0ee", text: "#C0291A", label: "🚫 Risk" },
    duplicate: { bg: "#fef8e8", text: "#BA7517", label: "⚠ Dup" },
    off_topic: { bg: "#f4f5f8", text: "#6b7280", label: "Off-topic" },
  }[t] ?? { bg: "#f4f5f8", text: "#6b7280", label: t });

  // ── RENDER ────────────────────────────────────────────────
  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100vh", background: "#f4f5f8", fontFamily: brand.fontFamily }}>

      {/* ── TOP BAR ── */}
      <div style={{ height: 52, background: brand.accentColor, display: "flex", alignItems: "center", gap: 14, padding: "0 20px", flexShrink: 0, borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
        {brand.logoUrl
          ? <img src={brand.logoUrl} alt={brand.name} style={{ height: 28 }} />
          : <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <div style={{ width: 26, height: 26, background: brand.primaryColor, borderRadius: 6, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 700, color: "#fff" }}>
                {brand.name.slice(0, 2).toUpperCase()}
              </div>
              <span style={{ fontSize: 13, fontWeight: 600, color: "#fff" }}>{brand.displayName}</span>
            </div>
        }
        <div style={{ width: 1, height: 18, background: "rgba(255,255,255,0.15)" }} />
        <span style={{ fontSize: 11, color: "rgba(255,255,255,0.4)" }}>
          {tokenData.recipientName ?? ""} · Read-only access
        </span>
        <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{ fontSize: 11, fontFamily: "monospace", color: "rgba(255,255,255,0.35)" }}>
            {fmt(duration)}
          </span>
          <div style={{ display: "flex", alignItems: "center", gap: 6, background: sessionEnded ? "rgba(19,122,60,0.15)" : "rgba(29,158,117,0.15)", border: `1px solid ${sessionEnded ? "rgba(19,122,60,0.3)" : "rgba(29,158,117,0.3)"}`, borderRadius: 100, padding: "4px 12px" }}>
            <div style={{ width: 6, height: 6, borderRadius: "50%", background: sessionEnded ? "#137a3c" : brand.primaryColor, animation: sessionEnded ? "none" : "pulse 1.5s infinite" }} />
            <span style={{ fontSize: 10, fontWeight: 700, color: sessionEnded ? "#137a3c" : brand.primaryColor, letterSpacing: "0.08em" }}>
              {sessionEnded ? "COMPLETE" : sessionActive ? "LIVE" : "CONNECTING"}
            </span>
          </div>
        </div>
      </div>

      {/* ── SESSION ENDED BANNER ── */}
      {sessionEnded && (
        <div style={{ background: "#137a3c", padding: "10px 20px", display: "flex", alignItems: "center", gap: 12, fontSize: 12, color: "#fff" }}>
          <span>✓ Session complete — your full intelligence report is ready.</span>
          {reportUrl && (
            <a href={reportUrl} style={{ color: "#fff", fontWeight: 700, textDecoration: "underline", marginLeft: "auto" }}>
              View full report →
            </a>
          )}
        </div>
      )}

      {/* ── MAIN GRID ── */}
      <div style={{ flex: 1, display: "grid", gridTemplateColumns: "1fr 300px", overflow: "hidden" }}>

        {/* LEFT — TRANSCRIPT */}
        <div style={{ display: "flex", flexDirection: "column", overflow: "hidden", borderRight: "1px solid #e2e5ed" }}>

          {/* Transcript */}
          <div style={{ flex: 1, background: "#fff", display: "flex", flexDirection: "column", overflow: "hidden" }}>
            <div style={{ padding: "10px 16px", borderBottom: "1px solid #e2e5ed", display: "flex", alignItems: "center", gap: 8, flexShrink: 0 }}>
              <span style={{ fontSize: 11, fontWeight: 600, color: "#0A2540" }}>Live transcript</span>
              <span style={{ fontSize: 10, color: "#9aa3b2" }}>Whisper STT · Speaker-diarised</span>
              <span style={{ marginLeft: "auto", fontSize: 9, fontFamily: "monospace", color: "#9aa3b2" }}>
                {transcript.length} segments
              </span>
            </div>
            <div ref={transcriptRef} style={{ flex: 1, overflowY: "auto", padding: 14 }}>
              {transcript.length === 0 ? (
                <div style={{ color: "#9aa3b2", fontSize: 11, display: "flex", alignItems: "center", gap: 8 }}>
                  <span>⏳</span> Waiting for session to begin...
                </div>
              ) : transcript.map(line => (
                <div key={line.id} style={{ display: "flex", gap: 10, marginBottom: 10 }}>
                  <span style={{ fontSize: 9, fontFamily: "monospace", color: "#9aa3b2", width: 34, flexShrink: 0, paddingTop: 2 }}>
                    {new Date(line.timestamp).toISOString().slice(14, 19)}
                  </span>
                  <span style={{ fontSize: 10, fontWeight: 600, color: line.speaker.toLowerCase().includes("analyst") ? "#BA7517" : "#1246E8", width: 110, flexShrink: 0, paddingTop: 2, lineHeight: 1.3 }}>
                    {line.speaker}
                  </span>
                  <span style={{ fontSize: 11, color: "#2c3042", lineHeight: 1.65, fontFamily: "monospace" }}>
                    {line.text}
                    {line.flagged && (
                      <span style={{ display: "inline-flex", alignItems: "center", gap: 3, background: line.flagType === "warning" ? "#fef8e8" : "#fef0ee", color: line.flagType === "warning" ? "#BA7517" : "#C0291A", border: `1px solid ${line.flagType === "warning" ? "rgba(186,117,23,0.2)" : "rgba(192,41,26,0.2)"}`, borderRadius: 4, padding: "1px 6px", fontSize: 9, fontWeight: 600, marginLeft: 5 }}>
                        ⚠ {line.flagType === "warning" ? "Alert" : "Flag"}
                      </span>
                    )}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Summary strip */}
          <div style={{ background: brand.accentColor, padding: "10px 14px", flexShrink: 0, borderTop: "1px solid rgba(255,255,255,0.06)" }}>
            <div style={{ fontSize: 9, fontWeight: 600, color: "rgba(255,255,255,0.3)", textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: 4 }}>
              🤖 AI rolling summary
            </div>
            <div style={{ fontSize: 11, color: "rgba(255,255,255,0.7)", lineHeight: 1.6 }}>{summary}</div>
          </div>

          {/* Q&A strip */}
          <div style={{ background: "#fff", borderTop: "1px solid #e2e5ed", maxHeight: 180, display: "flex", flexDirection: "column", overflow: "hidden" }}>
            <div style={{ padding: "8px 14px", borderBottom: "1px solid #e2e5ed", fontSize: 11, fontWeight: 600, color: "#0A2540", flexShrink: 0 }}>
              Live Q&A · {qaItems.length} questions
            </div>
            <div style={{ overflowY: "auto", flex: 1, padding: "6px 14px" }}>
              {qaItems.length === 0 ? (
                <div style={{ fontSize: 10, color: "#9aa3b2", padding: "6px 0" }}>Questions will appear here...</div>
              ) : qaItems.map(q => {
                const tc = triageColour(q.triage);
                return (
                  <div key={q.id} style={{ display: "flex", gap: 8, padding: "7px 0", borderBottom: "1px solid #f0f0f0" }}>
                    <span style={{ fontSize: 8, fontWeight: 700, padding: "2px 6px", borderRadius: 4, background: tc.bg, color: tc.text, flexShrink: 0, marginTop: 1 }}>
                      {tc.label}
                    </span>
                    <div>
                      <div style={{ fontSize: 10, fontWeight: 600, color: "#0A2540" }}>{q.asker}</div>
                      <div style={{ fontSize: 10, color: "#6b7280", lineHeight: 1.4 }}>{q.question}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* RIGHT — INTELLIGENCE SIDEBAR */}
        <div style={{ display: "flex", flexDirection: "column", overflow: "hidden", background: "#f4f5f8" }}>

          {/* Sentiment */}
          <div style={{ background: "#fff", borderBottom: "1px solid #e2e5ed", padding: "12px 14px", flexShrink: 0 }}>
            <div style={{ fontSize: 11, fontWeight: 600, color: "#0A2540", marginBottom: 10 }}>Real-time sentiment</div>
            {[
              { label: "Confidence",       val: sentiment.confidence,  color: "#137a3c" },
              { label: "Investor positivity", val: sentiment.positivity, color: "#1246E8" },
              { label: "Hedging language", val: sentiment.hedging,     color: "#BA7517" },
              { label: "Compliance risk",  val: sentiment.riskLevel,   color: "#C0291A" },
            ].map(row => (
              <div key={row.label} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
                <span style={{ fontSize: 10, color: "#6b7280", width: 110, flexShrink: 0, fontWeight: 500 }}>{row.label}</span>
                <div style={{ flex: 1, height: 5, background: "#eaecf2", borderRadius: 3, overflow: "hidden" }}>
                  <div style={{ height: "100%", width: `${row.val}%`, background: row.color, borderRadius: 3, transition: "width 1.2s ease" }} />
                </div>
                <span style={{ fontSize: 10, fontFamily: "monospace", color: "#9aa3b2", width: 32, textAlign: "right" }}>
                  {Math.round(row.val)}%
                </span>
              </div>
            ))}
          </div>

          {/* Compliance flags */}
          <div style={{ background: "#fff", borderBottom: "1px solid #e2e5ed", padding: "12px 14px", flexShrink: 0, maxHeight: 240, overflowY: "auto" }}>
            <div style={{ fontSize: 11, fontWeight: 600, color: "#0A2540", marginBottom: 8, display: "flex", justifyContent: "space-between" }}>
              Compliance alerts
              <span style={{ fontSize: 10, color: "#9aa3b2" }}>{flags.length} detected</span>
            </div>
            {flags.length === 0 ? (
              <div style={{ fontSize: 11, color: "#9aa3b2" }}>No flags detected yet.</div>
            ) : flags.map(flag => (
              <div key={flag.id} style={{ borderRadius: 7, padding: "9px 10px", marginBottom: 7, background: flag.severity === "critical" ? "#fef0ee" : flag.severity === "warning" ? "#fef8e8" : "#eff6ff", border: `1px solid ${flag.severity === "critical" ? "rgba(192,41,26,0.18)" : flag.severity === "warning" ? "rgba(186,117,23,0.18)" : "rgba(18,70,232,0.12)"}` }}>
                <div style={{ fontSize: 10, fontWeight: 600, color: flag.severity === "critical" ? "#C0291A" : flag.severity === "warning" ? "#BA7517" : "#1246E8", marginBottom: 2 }}>
                  {flag.severity === "critical" ? "🚨" : "⚠"} {flag.title}
                </div>
                <div style={{ fontSize: 9, color: "#6b7280", lineHeight: 1.5 }}>{flag.body}</div>
                <div style={{ fontSize: 8, fontFamily: "monospace", color: "#9aa3b2", marginTop: 3 }}>
                  Detected at {flag.detectedAt}
                </div>
              </div>
            ))}
          </div>

          {/* Report status */}
          <div style={{ flex: 1, padding: "12px 14px", display: "flex", flexDirection: "column", gap: 8 }}>
            <div style={{ borderRadius: 9, padding: "11px 13px", background: "#f4f5f8", border: "1px solid #e2e5ed" }}>
              <div style={{ fontSize: 10, fontWeight: 600, color: "#0A2540", marginBottom: 4 }}>📋 Post-event report</div>
              <div style={{ fontSize: 10, color: "#6b7280", lineHeight: 1.55 }}>
                {sessionEnded
                  ? "✓ Session complete. Your full 20-module intelligence report is generating. You will receive a secure link by email within 3 minutes."
                  : "Your full 20-module intelligence report will be generated automatically when the session closes. Delivered to your email within minutes."}
              </div>
              {reportUrl && (
                <a href={reportUrl} style={{ display: "inline-block", marginTop: 8, background: brand.primaryColor, color: "#fff", textDecoration: "none", fontSize: 11, fontWeight: 600, padding: "7px 14px", borderRadius: 6 }}>
                  View report →
                </a>
              )}
            </div>
            <div style={{ borderRadius: 9, padding: "11px 13px", background: "#f4f5f8", border: "1px solid #e2e5ed" }}>
              <div style={{ fontSize: 10, fontWeight: 600, color: "#0A2540", marginBottom: 4 }}>🔒 Disclosure certificate</div>
              <div style={{ fontSize: 10, color: "#6b7280", lineHeight: 1.55 }}>
                SHA-256 blockchain certificate issued on session close — immutable record of this entire call.
              </div>
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 1; box-shadow: 0 0 0 0 rgba(29,158,117,0.5); }
          60% { opacity: 0.8; box-shadow: 0 0 0 8px transparent; }
        }
      `}</style>
    </div>
  );
}

// ── LOADING / ERROR SCREENS ───────────────────────────────────
function LoadingScreen({ brand }: { brand: any }) {
  return (
    <div style={{ height: "100vh", background: brand.accentColor, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", color: "#fff" }}>
      <div style={{ fontSize: 14, color: "rgba(255,255,255,0.5)", marginTop: 12 }}>Verifying your access link...</div>
    </div>
  );
}

function InvalidToken({ brand, reason }: { brand: any; reason?: string }) {
  return (
    <div style={{ height: "100vh", background: brand.accentColor, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", color: "#fff", textAlign: "center", padding: "2rem" }}>
      <div style={{ fontSize: 48, marginBottom: "1rem" }}>🔒</div>
      <h1 style={{ fontSize: "1.4rem", fontWeight: 300, marginBottom: "0.5rem" }}>Access link invalid</h1>
      <p style={{ fontSize: "0.9rem", color: "rgba(255,255,255,0.4)", maxWidth: 360, lineHeight: 1.6 }}>
        {reason === "Token expired"
          ? "This access link has expired. Please contact your event organiser for a new link."
          : reason === "Token not found"
          ? "This access link was not recognised. Please check the link in your email."
          : "This access link could not be verified. Please contact your event organiser."}
      </p>
    </div>
  );
}
