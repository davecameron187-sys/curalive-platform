// ─────────────────────────────────────────────────────────────
// CuraLive — Session Scheduler
// File: client/src/components/SessionScheduler.tsx
// Used in: ShadowMode.tsx — add as a new "Schedule" button/modal
//          or as a standalone tab
// Covers: Gap X.5 — session scheduling
// ─────────────────────────────────────────────────────────────

import { useState } from "react";
import { trpc } from "../lib/trpc";
import { toast } from "sonner";

interface SessionSchedulerProps {
  onScheduled?: (sessionId: number) => void;
  onClose?:     () => void;
}

export function SessionScheduler({ onScheduled, onClose }: SessionSchedulerProps) {
  const [title,       setTitle]       = useState("");
  const [company,     setCompany]     = useState("");
  const [eventType,   setEventType]   = useState("earnings_call");
  const [tier,        setTier]        = useState<"essential"|"intelligence"|"enterprise"|"agm">("intelligence");
  const [partnerId,   setPartnerId]   = useState<number|null>(null);
  const [date,        setDate]        = useState("");
  const [time,        setTime]        = useState("14:00");
  const [timezone,    setTimezone]    = useState("Africa/Johannesburg");
  const [meetingUrl,  setMeetingUrl]  = useState("");
  const [jurisdiction,setJurisdiction]= useState("JSE");
  const [briefMins,   setBriefMins]   = useState(60);
  const [recipients,  setRecipients]  = useState([{ name: "", email: "", role: "IR Manager", sendLive: true, sendReport: true }]);
  const [saving,      setSaving]      = useState(false);

  const { data: partners }       = trpc.partners.listPartners.useQuery();
  const { data: upcoming }       = trpc.sessionConfig.getScheduledSessions.useQuery({});
  const scheduleSession          = trpc.sessionConfig.scheduleSession.useMutation();

  const EVENT_TYPES = [
    { value: "earnings_call",      label: "Earnings Call" },
    { value: "agm",                label: "AGM" },
    { value: "ipo_roadshow",       label: "IPO Roadshow" },
    { value: "investor_day",       label: "Investor Day" },
    { value: "bondholder_meeting", label: "Bondholder Meeting" },
    { value: "activist_meeting",   label: "Activist Meeting" },
    { value: "analyst_briefing",   label: "Analyst Briefing" },
    { value: "results_presentation",label: "Results Presentation" },
  ];

  const TIERS = [
    { id: "essential",    label: "Essential",    color: "#6b7280" },
    { id: "intelligence", label: "Intelligence", color: "#1D9E75" },
    { id: "enterprise",   label: "Enterprise",   color: "#b8860b" },
    { id: "agm",          label: "AGM",          color: "#7c3aed" },
  ];

  const handleSchedule = async () => {
    if (!title || !date) {
      toast.error("Title and date are required");
      return;
    }
    setSaving(true);
    try {
      const scheduledAt = new Date(`${date}T${time}:00`).toISOString();
      const result = await scheduleSession.mutateAsync({
        title,
        company,
        eventType,
        tier,
        partnerId,
        scheduledAt,
        timezone,
        meetingUrl: meetingUrl || undefined,
        jurisdiction,
        preBriefMinutes: briefMins,
        recipients: recipients.filter(r => r.email),
      });
      toast.success(`Session scheduled — pre-event briefing will send ${briefMins} mins before`);
      onScheduled?.(result.id);
    } catch (err: any) {
      toast.error(err.message ?? "Schedule failed");
    } finally {
      setSaving(false);
    }
  };

  const addRecipient = () => setRecipients(p => [...p, { name: "", email: "", role: "IR Manager", sendLive: true, sendReport: true }]);
  const removeRecipient = (i: number) => setRecipients(p => p.filter((_, idx) => idx !== i));
  const updateRecipient = (i: number, k: string, v: any) => setRecipients(p => p.map((r, idx) => idx === i ? { ...r, [k]: v } : r));

  const css = {
    overlay: { position: "fixed" as const, inset: 0, background: "rgba(0,0,0,0.5)", zIndex: 500, display: "flex", alignItems: "center", justifyContent: "center", padding: 24 },
    modal:   { background: "#fff", borderRadius: 16, width: "100%", maxWidth: 720, maxHeight: "90vh", overflow: "hidden", display: "flex", flexDirection: "column" as const, boxShadow: "0 24px 80px rgba(0,0,0,0.2)" },
    header:  { background: "#0A2540", padding: "18px 24px", display: "flex", alignItems: "center", justifyContent: "space-between" },
    body:    { flex: 1, overflowY: "auto" as const, padding: 24 },
    footer:  { padding: "14px 24px", borderTop: "1px solid rgba(0,0,0,0.07)", display: "flex", gap: 10, justifyContent: "flex-end" },
    grid2:   { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 16 },
    label:   { fontSize: 11, fontWeight: 600, color: "#0A2540", marginBottom: 5, textTransform: "uppercase" as const, letterSpacing: ".05em", display: "block" },
    input:   { width: "100%", padding: "8px 10px", borderRadius: 7, border: "1px solid rgba(0,0,0,0.1)", fontSize: 12, fontFamily: "inherit", color: "#0A2540" },
    select:  { width: "100%", padding: "8px 10px", borderRadius: 7, border: "1px solid rgba(0,0,0,0.1)", fontSize: 12, fontFamily: "inherit", background: "#fff", color: "#0A2540" },
    sectionTitle: { fontSize: 11, fontWeight: 700, color: "#0A2540", textTransform: "uppercase" as const, letterSpacing: ".07em", marginBottom: 12, marginTop: 4 },
    btn:     (primary: boolean): React.CSSProperties => ({
      padding: "10px 20px", borderRadius: 7, fontSize: 12, fontWeight: 600, cursor: "pointer", fontFamily: "inherit",
      background: primary ? "#0A2540" : "#f4f5f8",
      color: primary ? "#fff" : "#6b7280",
      border: primary ? "none" : "1px solid rgba(0,0,0,0.1)",
    }),
    recipientCard: { background: "#f7f8fb", border: "1px solid rgba(0,0,0,0.07)", borderRadius: 8, padding: 10, marginBottom: 8 },
  };

  return (
    <div style={css.overlay} onClick={e => e.target === e.currentTarget && onClose?.()}>
      <div style={css.modal}>
        <div style={css.header}>
          <div>
            <div style={{ fontSize: 16, fontWeight: 600, color: "#fff" }}>Schedule session</div>
            <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)", marginTop: 2 }}>Pre-event briefing auto-sends {briefMins} minutes before start</div>
          </div>
          <button onClick={onClose} style={{ background: "none", border: "none", color: "rgba(255,255,255,0.4)", fontSize: 20, cursor: "pointer" }}>×</button>
        </div>

        <div style={css.body}>
          {/* Event details */}
          <div style={css.sectionTitle}>Event details</div>
          <div style={css.grid2}>
            <div>
              <label style={css.label}>Session title *</label>
              <input style={css.input} placeholder="e.g. Q3 2026 Earnings Call" value={title} onChange={e => setTitle(e.target.value)} />
            </div>
            <div>
              <label style={css.label}>Company name</label>
              <input style={css.input} placeholder="e.g. Meridian Holdings" value={company} onChange={e => setCompany(e.target.value)} />
            </div>
          </div>
          <div style={css.grid2}>
            <div>
              <label style={css.label}>Event type</label>
              <select style={css.select} value={eventType} onChange={e => setEventType(e.target.value)}>
                {EVENT_TYPES.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
              </select>
            </div>
            <div>
              <label style={css.label}>Jurisdiction</label>
              <select style={css.select} value={jurisdiction} onChange={e => setJurisdiction(e.target.value)}>
                {["JSE","SEC","FCA","ASIC","SGX","HKEX"].map(j => <option key={j} value={j}>{j}</option>)}
              </select>
            </div>
          </div>
          <div style={css.grid2}>
            <div>
              <label style={css.label}>Date *</label>
              <input style={css.input} type="date" value={date} onChange={e => setDate(e.target.value)} />
            </div>
            <div>
              <label style={css.label}>Time</label>
              <input style={css.input} type="time" value={time} onChange={e => setTime(e.target.value)} />
            </div>
          </div>
          <div style={{ marginBottom: 16 }}>
            <label style={css.label}>Meeting URL (optional)</label>
            <input style={css.input} placeholder="https://zoom.us/j/..." value={meetingUrl} onChange={e => setMeetingUrl(e.target.value)} />
          </div>

          {/* Intelligence tier */}
          <div style={css.sectionTitle}>Intelligence tier</div>
          <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
            {TIERS.map(t => (
              <div key={t.id}
                onClick={() => setTier(t.id as any)}
                style={{ flex: 1, padding: "8px 6px", borderRadius: 8, cursor: "pointer", textAlign: "center", border: tier === t.id ? `1.5px solid ${t.color}` : "1px solid rgba(0,0,0,0.08)", background: tier === t.id ? `${t.color}12` : "#f7f8fb" }}
              >
                <div style={{ fontSize: 11, fontWeight: 700, color: tier === t.id ? t.color : "#6b7280" }}>{t.label}</div>
              </div>
            ))}
          </div>

          {/* Partner */}
          {partners && partners.length > 0 && (
            <div style={{ marginBottom: 16 }}>
              <label style={css.label}>Channel partner (optional)</label>
              <select style={css.select} value={partnerId ?? ""} onChange={e => setPartnerId(e.target.value ? Number(e.target.value) : null)}>
                <option value="">CuraLive direct</option>
                {partners.map((p: any) => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
            </div>
          )}

          {/* Pre-event briefing timing */}
          <div style={{ marginBottom: 16 }}>
            <label style={css.label}>Pre-event briefing delivery</label>
            <div style={{ display: "flex", gap: 8 }}>
              {[30, 60, 90, 120].map(mins => (
                <div key={mins}
                  onClick={() => setBriefMins(mins)}
                  style={{ padding: "6px 14px", borderRadius: 100, fontSize: 11, fontWeight: 600, cursor: "pointer", border: briefMins === mins ? "1px solid #1D9E75" : "1px solid rgba(0,0,0,0.1)", background: briefMins === mins ? "#e6f7f3" : "#f7f8fb", color: briefMins === mins ? "#1D9E75" : "#6b7280" }}
                >
                  {mins} min before
                </div>
              ))}
            </div>
          </div>

          {/* Recipients */}
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
            <div style={css.sectionTitle}>Client recipients</div>
            <button onClick={addRecipient} style={{ fontSize: 11, color: "#1D9E75", background: "none", border: "none", cursor: "pointer", fontWeight: 600 }}>+ Add</button>
          </div>
          {recipients.map((r, i) => (
            <div key={i} style={css.recipientCard}>
              <div style={{ display: "flex", gap: 8, marginBottom: 6 }}>
                <input style={{ ...css.input, flex: 1 }} placeholder="Name" value={r.name} onChange={e => updateRecipient(i, "name", e.target.value)} />
                <input style={{ ...css.input, flex: 1.5 }} placeholder="Email" type="email" value={r.email} onChange={e => updateRecipient(i, "email", e.target.value)} />
                {recipients.length > 1 && <button onClick={() => removeRecipient(i)} style={{ background: "none", border: "none", color: "#C0291A", cursor: "pointer" }}>×</button>}
              </div>
              <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                <select style={{ ...css.select, flex: 1 }} value={r.role} onChange={e => updateRecipient(i, "role", e.target.value)}>
                  {["IR Manager","CFO","CEO","Compliance Officer","Board Chair","Company Secretary","Legal Counsel"].map(role => <option key={role} value={role}>{role}</option>)}
                </select>
                <label style={{ fontSize: 11, color: "#6b7280", display: "flex", alignItems: "center", gap: 4 }}>
                  <input type="checkbox" checked={r.sendLive} onChange={e => updateRecipient(i, "sendLive", e.target.checked)} /> Live
                </label>
                <label style={{ fontSize: 11, color: "#6b7280", display: "flex", alignItems: "center", gap: 4 }}>
                  <input type="checkbox" checked={r.sendReport} onChange={e => updateRecipient(i, "sendReport", e.target.checked)} /> Report
                </label>
              </div>
            </div>
          ))}

          {/* Upcoming sessions */}
          {upcoming && upcoming.length > 0 && (
            <div style={{ marginTop: 20 }}>
              <div style={css.sectionTitle}>Upcoming scheduled sessions</div>
              {upcoming.slice(0, 5).map((s: any) => (
                <div key={s.id} style={{ display: "flex", alignItems: "center", gap: 12, padding: "8px 0", borderBottom: "1px solid rgba(0,0,0,0.05)", fontSize: 11, color: "#6b7280" }}>
                  <span style={{ color: "#0A2540", fontWeight: 600 }}>{s.title}</span>
                  <span>·</span>
                  <span>{new Date(s.scheduledAt).toLocaleDateString()}</span>
                  <span>{new Date(s.scheduledAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>
                  <span style={{ marginLeft: "auto", padding: "2px 8px", borderRadius: 100, fontSize: 9, fontWeight: 700, background: "#e6f7f3", color: "#1D9E75" }}>{s.tier?.toUpperCase()}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        <div style={css.footer}>
          <button style={css.btn(false)} onClick={onClose}>Cancel</button>
          <button style={css.btn(true)} onClick={handleSchedule} disabled={saving}>
            {saving ? "Scheduling..." : "Schedule session"}
          </button>
        </div>
      </div>
    </div>
  );
}
