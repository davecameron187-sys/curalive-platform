// ─────────────────────────────────────────────────────────────
// CuraLive — Session Setup Panel
// File: client/src/components/SessionSetupPanel.tsx
// Used in: ShadowMode.tsx Live Intelligence tab
//
// Adds: tier selection, partner, recipients, readiness check
// Covers Gaps: 1.1, 1.2, 1.3, 1.4
// ─────────────────────────────────────────────────────────────

import { useState } from "react";
import { trpc } from "../lib/trpc";
import { toast } from "sonner";

interface Recipient {
  name:       string;
  email:      string;
  role:       string;
  sendLive:   boolean;
  sendReport: boolean;
}

interface SessionSetupPanelProps {
  sessionId:  number;
  onComplete: () => void;
}

export function SessionSetupPanel({ sessionId, onComplete }: SessionSetupPanelProps) {
  const [tier, setTier]             = useState<"essential"|"intelligence"|"enterprise"|"agm">("essential");
  const [partnerId, setPartnerId]   = useState<number | null>(null);
  const [jurisdiction, setJurisdiction] = useState("JSE");
  const [recipients, setRecipients] = useState<Recipient[]>([
    { name: "", email: "", role: "IR Manager", sendLive: true, sendReport: true }
  ]);
  const [saving, setSaving]         = useState(false);
  const [readiness, setReadiness]   = useState<any>(null);
  const [checking, setChecking]     = useState(false);

  const { data: partners } = trpc.partners.listPartners.useQuery();
  const updateConfig   = trpc.sessionConfig.updateSessionConfig.useMutation();
  const runCheck       = trpc.sessionConfig.runReadinessCheck.useMutation();
  const sendLiveLinks  = trpc.sessionConfig.sendLiveLinks.useMutation();

  const addRecipient = () => {
    setRecipients(prev => [...prev, { name: "", email: "", role: "IR Manager", sendLive: true, sendReport: true }]);
  };

  const removeRecipient = (i: number) => {
    setRecipients(prev => prev.filter((_, idx) => idx !== i));
  };

  const updateRecipient = (i: number, field: keyof Recipient, value: any) => {
    setRecipients(prev => prev.map((r, idx) => idx === i ? { ...r, [field]: value } : r));
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await updateConfig.mutateAsync({
        sessionId,
        tier,
        partnerId,
        jurisdiction,
        recipients: recipients.filter(r => r.email),
      });
      toast.success("Session configured");
      onComplete();
    } catch (err: any) {
      toast.error(err.message ?? "Save failed");
    } finally {
      setSaving(false);
    }
  };

  const handleReadinessCheck = async () => {
    setChecking(true);
    try {
      const result = await runCheck.mutateAsync({ sessionId });
      setReadiness(result);
    } finally {
      setChecking(false);
    }
  };

  const handleSendLiveLinks = async () => {
    try {
      await sendLiveLinks.mutateAsync({ sessionId });
      toast.success("Live dashboard links sent to recipients");
    } catch (err: any) {
      toast.error(err.message ?? "Send failed");
    }
  };

  const TIERS = [
    { id: "essential",    label: "Essential",    desc: "Core intelligence", color: "#6b7280" },
    { id: "intelligence", label: "Intelligence", desc: "Full AI engine",    color: "#1D9E75" },
    { id: "enterprise",   label: "Enterprise",   desc: "Command centre",   color: "#b8860b" },
    { id: "agm",          label: "AGM",          desc: "Annual general meeting intelligence", color: "#7c3aed" },
  ];

  const JURISDICTIONS = ["JSE","SEC","FCA","ASIC","SGX","HKEX"];
  const ROLES = ["IR Manager","CFO","CEO","Compliance Officer","Board Chair","Company Secretary","Legal Counsel","Investor Relations","Communications","Finance Director"];

  const S = {
    wrap: { padding: 20, background: "#fff", borderRadius: 12, border: "1px solid rgba(0,0,0,0.07)" },
    section: { marginBottom: 20 },
    sectionTitle: { fontSize: 11, fontWeight: 600, color: "#0A2540", marginBottom: 10, textTransform: "uppercase" as const, letterSpacing: ".06em" },
    tierRow: { display: "flex", gap: 8 },
    tierCard: (selected: boolean, color: string): React.CSSProperties => ({
      flex: 1, padding: "10px 8px", borderRadius: 8, cursor: "pointer", textAlign: "center" as const,
      border: selected ? `1.5px solid ${color}` : "1px solid rgba(0,0,0,0.08)",
      background: selected ? `${color}12` : "#f7f8fb",
      transition: "all .15s",
    }),
    tierLabel: (selected: boolean, color: string): React.CSSProperties => ({
      fontSize: 11, fontWeight: 700, color: selected ? color : "#6b7280",
    }),
    tierDesc: { fontSize: 9, color: "#9aa3b2", marginTop: 2 },
    select: { width: "100%", padding: "8px 10px", borderRadius: 7, border: "1px solid rgba(0,0,0,0.1)", fontSize: 12, background: "#fff", color: "#0A2540", fontFamily: "inherit" },
    recipientCard: { background: "#f7f8fb", border: "1px solid rgba(0,0,0,0.07)", borderRadius: 8, padding: 12, marginBottom: 8 },
    input: { width: "100%", padding: "7px 10px", borderRadius: 6, border: "1px solid rgba(0,0,0,0.1)", fontSize: 11, background: "#fff", fontFamily: "inherit", marginBottom: 6 },
    row: { display: "flex", gap: 8, marginBottom: 6 },
    checkRow: { display: "flex", alignItems: "center", gap: 6, fontSize: 11, color: "#6b7280" },
    readinessItem: (ok: boolean): React.CSSProperties => ({
      display: "flex", alignItems: "center", gap: 8, padding: "6px 0",
      borderBottom: "1px solid rgba(0,0,0,0.05)", fontSize: 11,
      color: ok ? "#137a3c" : "#C0291A",
    }),
    btn: (primary: boolean): React.CSSProperties => ({
      padding: "9px 18px", borderRadius: 7, fontSize: 12, fontWeight: 600, cursor: "pointer", fontFamily: "inherit",
      background: primary ? "#0A2540" : "transparent",
      color: primary ? "#fff" : "#6b7280",
      border: primary ? "none" : "1px solid rgba(0,0,0,0.1)",
    }),
  };

  return (
    <div style={S.wrap}>

      {/* TIER */}
      <div style={S.section}>
        <div style={S.sectionTitle}>Intelligence tier</div>
        <div style={S.tierRow}>
          {TIERS.map(t => (
            <div key={t.id} style={S.tierCard(tier === t.id, t.color)} onClick={() => setTier(t.id as any)}>
              <div style={S.tierLabel(tier === t.id, t.color)}>{t.label}</div>
              <div style={S.tierDesc}>{t.desc}</div>
            </div>
          ))}
        </div>
      </div>

      {/* PARTNER */}
      {partners && partners.length > 0 && (
        <div style={S.section}>
          <div style={S.sectionTitle}>Channel partner (optional)</div>
          <select style={S.select} value={partnerId ?? ""} onChange={e => setPartnerId(e.target.value ? Number(e.target.value) : null)}>
            <option value="">CuraLive direct (no partner)</option>
            {partners.map((p: any) => <option key={p.id} value={p.id}>{p.name} — {p.model}</option>)}
          </select>
        </div>
      )}

      {/* JURISDICTION */}
      <div style={S.section}>
        <div style={S.sectionTitle}>Compliance jurisdiction</div>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
          {JURISDICTIONS.map(j => (
            <div key={j}
              style={{ padding: "5px 12px", borderRadius: 100, fontSize: 11, fontWeight: 600, cursor: "pointer", border: jurisdiction === j ? "1px solid #1D9E75" : "1px solid rgba(0,0,0,0.1)", background: jurisdiction === j ? "#e6f7f3" : "#f7f8fb", color: jurisdiction === j ? "#1D9E75" : "#6b7280" }}
              onClick={() => setJurisdiction(j)}
            >{j}</div>
          ))}
        </div>
      </div>

      {/* RECIPIENTS */}
      <div style={S.section}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
          <div style={S.sectionTitle}>Client recipients</div>
          <button style={{ fontSize: 11, color: "#1D9E75", background: "none", border: "none", cursor: "pointer", fontWeight: 600 }} onClick={addRecipient}>+ Add recipient</button>
        </div>
        {recipients.map((r, i) => (
          <div key={i} style={S.recipientCard}>
            <div style={S.row}>
              <input style={{ ...S.input, marginBottom: 0, flex: 1 }} placeholder="Full name" value={r.name} onChange={e => updateRecipient(i, "name", e.target.value)} />
              <input style={{ ...S.input, marginBottom: 0, flex: 1.5 }} placeholder="Email address" type="email" value={r.email} onChange={e => updateRecipient(i, "email", e.target.value)} />
            </div>
            <div style={S.row}>
              <select style={{ ...S.select, flex: 1 }} value={r.role} onChange={e => updateRecipient(i, "role", e.target.value)}>
                {ROLES.map(role => <option key={role} value={role}>{role}</option>)}
              </select>
              <div style={{ display: "flex", gap: 12, alignItems: "center", flex: 1 }}>
                <label style={S.checkRow}>
                  <input type="checkbox" checked={r.sendLive} onChange={e => updateRecipient(i, "sendLive", e.target.checked)} />
                  Live link
                </label>
                <label style={S.checkRow}>
                  <input type="checkbox" checked={r.sendReport} onChange={e => updateRecipient(i, "sendReport", e.target.checked)} />
                  Report
                </label>
              </div>
              {recipients.length > 1 && (
                <button onClick={() => removeRecipient(i)} style={{ background: "none", border: "none", color: "#C0291A", cursor: "pointer", fontSize: 16 }}>×</button>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* READINESS CHECK */}
      {readiness && (
        <div style={{ ...S.section, background: readiness.overallReady ? "#e8f7ef" : "#fef0ee", border: `1px solid ${readiness.overallReady ? "rgba(19,122,60,0.2)" : "rgba(192,41,26,0.2)"}`, borderRadius: 8, padding: 12 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: readiness.overallReady ? "#137a3c" : "#C0291A", marginBottom: 8 }}>
            {readiness.overallReady ? "✓ Session ready to go live" : "⚠ Issues detected — review before going live"}
          </div>
          {Object.entries(readiness.checks).map(([key, ok]: [string, any]) => (
            <div key={key} style={S.readinessItem(ok)}>
              <span>{ok ? "✓" : "✗"}</span>
              <span>{{
                botDeployed:      "CuraLive Intelligence Agent deployed",
                recipientsSet:    "Client recipients configured",
                tierConfirmed:    "Intelligence tier selected",
                jurisdictionSet:  "Compliance jurisdiction set",
                recordingEnabled: "Session recording enabled",
                clientLinksSent:  "Live dashboard links sent to clients",
              }[key] ?? key}</span>
            </div>
          ))}
        </div>
      )}

      {/* ACTIONS */}
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        <button style={S.btn(true)} onClick={handleSave} disabled={saving}>
          {saving ? "Saving..." : "Save configuration"}
        </button>
        <button style={S.btn(false)} onClick={handleReadinessCheck} disabled={checking}>
          {checking ? "Checking..." : "Run readiness check"}
        </button>
        <button style={{ ...S.btn(false), color: "#1D9E75", borderColor: "rgba(29,158,117,0.3)" }} onClick={handleSendLiveLinks}>
          📡 Send live links now
        </button>
      </div>
    </div>
  );
}
