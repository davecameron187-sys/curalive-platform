// ─────────────────────────────────────────────────────────────
// CuraLive — Client Message Panel
// File: client/src/components/ClientMessagePanel.tsx
// Used in: curalive-command-centre (client dashboard)
//          Also add to ClientLive.tsx
//
// This gives the IR team a direct line to the operator.
// Appears as a floating panel on the client dashboard.
// Messages sent via tRPC sessionMessages.sendFromClient
// Replies received via Ably session-{id}-client channel
// ─────────────────────────────────────────────────────────────

import { useState, useEffect, useRef } from "react";
import { trpc } from "../lib/trpc";
import { useAbly } from "../contexts/AblyContext";

interface Message {
  id:          number;
  fromRole:    "operator" | "client";
  fromName:    string;
  message:     string;
  messageType: string;
  createdAt:   string;
}

interface ClientMessagePanelProps {
  token:        string;
  sessionId:    number;
  recipientName: string;
}

export function ClientMessagePanel({ token, sessionId, recipientName }: ClientMessagePanelProps) {
  const [open, setOpen]         = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput]       = useState("");
  const [sending, setSending]   = useState(false);
  const [unread, setUnread]     = useState(0);
  const messagesEndRef           = useRef<HTMLDivElement>(null);
  const ably                     = useAbly();

  // Load existing messages
  const { data: existingMessages } = trpc.sessionMessages.getClientMessages.useQuery(
    { token },
    { enabled: !!token, refetchInterval: 10000 }
  );

  useEffect(() => {
    if (existingMessages) setMessages(existingMessages as Message[]);
  }, [existingMessages]);

  // Subscribe to new operator messages via Ably
  useEffect(() => {
    if (!ably) return;
    const channel = ably.channels.get(`session-${sessionId}-client`);

    channel.subscribe("operator.message", (msg) => {
      const newMsg: Message = {
        id:          msg.data.id,
        fromRole:    "operator",
        fromName:    msg.data.fromName ?? "Operator",
        message:     msg.data.message,
        messageType: msg.data.messageType,
        createdAt:   msg.data.createdAt,
      };
      setMessages(prev => [...prev, newMsg]);
      if (!open) setUnread(u => u + 1);
    });

    return () => { channel.unsubscribe(); };
  }, [ably, sessionId, open]);

  // Scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, open]);

  const sendMessage = trpc.sessionMessages.sendFromClient.useMutation();

  const handleSend = async () => {
    if (!input.trim() || sending) return;
    setSending(true);
    try {
      await sendMessage.mutateAsync({
        token,
        message:     input.trim(),
        messageType: "chat",
      });
      const optimistic: Message = {
        id:          Date.now(),
        fromRole:    "client",
        fromName:    recipientName,
        message:     input.trim(),
        messageType: "chat",
        createdAt:   new Date().toISOString(),
      };
      setMessages(prev => [...prev, optimistic]);
      setInput("");
    } finally {
      setSending(false);
    }
  };

  const handleOpen = () => {
    setOpen(true);
    setUnread(0);
  };

  // Styles matching the dark command centre aesthetic
  const S = {
    // Floating toggle button
    toggle: {
      position: "fixed" as const,
      bottom: 70,
      right: 20,
      width: 48,
      height: 48,
      borderRadius: "50%",
      background: "linear-gradient(135deg,rgba(0,212,255,0.2),rgba(0,212,255,0.1))",
      border: "1px solid rgba(0,212,255,0.35)",
      color: "#00d4ff",
      fontSize: 18,
      cursor: "pointer",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      zIndex: 200,
      boxShadow: open ? "0 0 30px rgba(0,212,255,0.2)" : "none",
      transition: "all .2s",
    } as React.CSSProperties,

    badge: {
      position: "absolute" as const,
      top: -4, right: -4,
      width: 18, height: 18,
      borderRadius: "50%",
      background: "#ff3d57",
      color: "#fff",
      fontSize: 10,
      fontWeight: 700,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
    } as React.CSSProperties,

    panel: {
      position: "fixed" as const,
      bottom: 126,
      right: 20,
      width: 340,
      maxHeight: 460,
      background: "#0d1120",
      border: "1px solid rgba(0,212,255,0.2)",
      borderRadius: 14,
      display: "flex",
      flexDirection: "column" as const,
      overflow: "hidden",
      zIndex: 200,
      boxShadow: "0 20px 60px rgba(0,0,0,0.5), 0 0 0 1px rgba(0,212,255,0.1)",
      animation: "slideUp 0.25s cubic-bezier(0.16,1,0.3,1)",
    } as React.CSSProperties,

    panelHeader: {
      background: "linear-gradient(135deg,rgba(0,212,255,0.08),rgba(0,212,255,0.04))",
      borderBottom: "1px solid rgba(0,212,255,0.1)",
      padding: "12px 16px",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
    } as React.CSSProperties,

    headerTitle: {
      fontSize: 12,
      fontWeight: 600,
      color: "#00d4ff",
      letterSpacing: ".04em",
    } as React.CSSProperties,

    headerSub: {
      fontSize: 10,
      color: "rgba(255,255,255,0.3)",
      marginTop: 2,
    } as React.CSSProperties,

    closeBtn: {
      background: "none",
      border: "none",
      color: "rgba(255,255,255,0.3)",
      fontSize: 16,
      cursor: "pointer",
      padding: 4,
    } as React.CSSProperties,

    messages: {
      flex: 1,
      overflowY: "auto" as const,
      padding: "12px 14px",
      display: "flex",
      flexDirection: "column" as const,
      gap: 8,
      maxHeight: 320,
    } as React.CSSProperties,

    emptyState: {
      textAlign: "center" as const,
      padding: "24px 16px",
      color: "rgba(255,255,255,0.2)",
      fontSize: 11,
      lineHeight: 1.6,
    } as React.CSSProperties,

    inputRow: {
      padding: "10px 12px",
      borderTop: "1px solid rgba(255,255,255,0.06)",
      display: "flex",
      gap: 8,
      alignItems: "flex-end",
    } as React.CSSProperties,

    input: {
      flex: 1,
      background: "rgba(255,255,255,0.05)",
      border: "1px solid rgba(255,255,255,0.1)",
      borderRadius: 8,
      padding: "8px 10px",
      color: "#f0f2f8",
      fontSize: 11,
      fontFamily: "'DM Sans', sans-serif",
      resize: "none" as const,
      outline: "none",
      maxHeight: 80,
    } as React.CSSProperties,

    sendBtn: {
      background: "linear-gradient(135deg,rgba(0,212,255,0.2),rgba(0,212,255,0.1))",
      border: "1px solid rgba(0,212,255,0.3)",
      borderRadius: 7,
      color: "#00d4ff",
      fontSize: 12,
      fontWeight: 600,
      padding: "8px 14px",
      cursor: "pointer",
      fontFamily: "'DM Sans', sans-serif",
      transition: "all .15s",
      opacity: sending ? 0.5 : 1,
    } as React.CSSProperties,
  };

  const msgStyle = (fromRole: string): React.CSSProperties => ({
    maxWidth: "85%",
    padding: "8px 10px",
    borderRadius: fromRole === "client" ? "10px 10px 2px 10px" : "10px 10px 10px 2px",
    background: fromRole === "client"
      ? "rgba(0,212,255,0.1)"
      : "rgba(255,255,255,0.06)",
    border: fromRole === "client"
      ? "1px solid rgba(0,212,255,0.2)"
      : "1px solid rgba(255,255,255,0.08)",
    alignSelf: fromRole === "client" ? "flex-end" : "flex-start",
    fontSize: 11,
    color: "#f0f2f8",
    lineHeight: 1.5,
  });

  return (
    <>
      {/* Floating button */}
      <div style={S.toggle} onClick={handleOpen} title="Message your operator">
        💬
        {unread > 0 && (
          <div style={S.badge}>{unread > 9 ? "9+" : unread}</div>
        )}
      </div>

      {/* Panel */}
      {open && (
        <div style={S.panel}>
          <style>{`@keyframes slideUp{from{opacity:0;transform:translateY(10px);}to{opacity:1;transform:translateY(0);}}`}</style>

          <div style={S.panelHeader}>
            <div>
              <div style={S.headerTitle}>Message your operator</div>
              <div style={S.headerSub}>Secure · Session encrypted · Read by your dedicated operator</div>
            </div>
            <button style={S.closeBtn} onClick={() => setOpen(false)}>×</button>
          </div>

          <div style={S.messages}>
            {messages.length === 0 ? (
              <div style={S.emptyState}>
                <div style={{ fontSize: 24, marginBottom: 8 }}>💬</div>
                Send a message to your operator.<br />
                Use this to request question approvals,<br />flag concerns, or ask for guidance.
              </div>
            ) : (
              messages.map(msg => (
                <div key={msg.id} style={{ display: "flex", flexDirection: "column", gap: 2 }}>
                  <div style={{ fontSize: 9, color: "rgba(255,255,255,0.25)", textAlign: msg.fromRole === "client" ? "right" : "left", marginBottom: 2 }}>
                    {msg.fromRole === "operator" ? "Operator" : "You"}
                  </div>
                  <div style={msgStyle(msg.fromRole)}>
                    {msg.message}
                  </div>
                </div>
              ))
            )}
            <div ref={messagesEndRef} />
          </div>

          <div style={S.inputRow}>
            <textarea
              style={S.input}
              placeholder="Type a message to your operator..."
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleSend(); }}}
              rows={2}
            />
            <button style={S.sendBtn} onClick={handleSend} disabled={sending || !input.trim()}>
              {sending ? "..." : "Send"}
            </button>
          </div>
        </div>
      )}
    </>
  );
}

// ── OPERATOR MESSAGE PANEL (for operator console) ─────────────
// Shows incoming client messages + reply interface

interface OperatorMessagePanelProps {
  sessionId: number;
}

export function OperatorMessagePanel({ sessionId }: OperatorMessagePanelProps) {
  const [open, setOpen]         = useState(false);
  const [replyText, setReplyText] = useState("");
  const [replyingTo, setReplyingTo] = useState<number | null>(null);
  const [unread, setUnread]     = useState(0);
  const ably                     = useAbly();

  const { data: messages, refetch } = trpc.sessionMessages.getSessionMessages.useQuery(
    { sessionId },
    { refetchInterval: 5000 }
  );

  const sendReply    = trpc.sessionMessages.sendFromOperator.useMutation({ onSuccess: () => refetch() });
  const resolveMsg   = trpc.sessionMessages.resolveMessage.useMutation({ onSuccess: () => refetch() });

  // Ably subscription for new client messages
  useEffect(() => {
    if (!ably) return;
    const channel = ably.channels.get(`operator-${sessionId}`);
    channel.subscribe("client.message", () => {
      refetch();
      if (!open) setUnread(u => u + 1);
    });
    return () => { channel.unsubscribe(); };
  }, [ably, sessionId, open]);

  const unresolved = (messages ?? []).filter((m: any) => m.fromRole === "client" && !m.resolved).length;

  return (
    <div style={{ position: "relative" }}>
      {/* Badge on Q&A tab or dedicated icon */}
      {unresolved > 0 && (
        <span style={{ background: "#ff3d57", color: "#fff", fontSize: 9, fontWeight: 700, padding: "2px 6px", borderRadius: 8, marginLeft: 6 }}>
          {unresolved} msg
        </span>
      )}
    </div>
  );
}
