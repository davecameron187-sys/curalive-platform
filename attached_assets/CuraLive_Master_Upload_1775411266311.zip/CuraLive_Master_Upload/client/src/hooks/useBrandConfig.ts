// ─────────────────────────────────────────────────────────────
// CuraLive — useBrandConfig Hook
// File: client/src/hooks/useBrandConfig.ts
// Usage: const brand = useBrandConfig()
//        Inject into any component that needs brand-aware colours/logo
// ─────────────────────────────────────────────────────────────

import { useQuery } from "@tanstack/react-query";
import { trpc } from "../lib/trpc";

export interface BrandConfig {
  isWhiteLabel:  boolean;
  slug:          string;
  name:          string;
  displayName:   string;
  logoUrl:       string | null;
  primaryColor:  string;
  accentColor:   string;
  fontFamily:    string;
  sendingName:   string;
  customDomain:  string | null;
}

const CURALIVE_DEFAULTS: BrandConfig = {
  isWhiteLabel:  false,
  slug:          "curalive",
  name:          "CuraLive",
  displayName:   "CuraLive Intelligence",
  logoUrl:       null,
  primaryColor:  "#1D9E75",
  accentColor:   "#0A2540",
  fontFamily:    "Sora, sans-serif",
  sendingName:   "CuraLive",
  customDomain:  null,
};

export function useBrandConfig(): BrandConfig {
  const domain = typeof window !== "undefined"
    ? window.location.hostname
    : "app.curalive.com";

  const { data } = trpc.partners.getBrandByDomain.useQuery(
    { domain },
    {
      staleTime:    5 * 60 * 1000,  // 5 minutes
      cacheTime:    10 * 60 * 1000, // 10 minutes
      refetchOnWindowFocus: false,
      retry: 1,
    }
  );

  return data ?? CURALIVE_DEFAULTS;
}

// ── CSS VARIABLES INJECTOR ────────────────────────────────────
// Call this once at app root to inject brand colours as CSS vars
// Usage: injectBrandCSSVars(brand) in App.tsx
export function injectBrandCSSVars(brand: BrandConfig) {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  root.style.setProperty("--brand-primary",    brand.primaryColor);
  root.style.setProperty("--brand-accent",     brand.accentColor);
  root.style.setProperty("--brand-font",       brand.fontFamily);
  root.style.setProperty("--brand-name",       `"${brand.displayName}"`);

  // Update favicon if partner has one
  if (brand.faviconUrl) {
    const favicon = document.querySelector<HTMLLinkElement>('link[rel="icon"]');
    if (favicon) favicon.href = brand.faviconUrl;
  }

  // Update page title
  document.title = brand.displayName;
}
