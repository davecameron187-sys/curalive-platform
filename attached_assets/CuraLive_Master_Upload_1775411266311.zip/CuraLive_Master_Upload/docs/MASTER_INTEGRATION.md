# ═══════════════════════════════════════════════════════════════════════════
# CuraLive — Master Upload Package
# Complete Replit Integration Instructions
# April 2026
# ═══════════════════════════════════════════════════════════════════════════
#
# This package contains 24 files. Every file has an exact destination path
# in the Replit codebase. Do not rename any file. Do not move any file to
# a different path than listed below.
#
# After copying all files, there are 6 wiring steps and 1 SQL block to run.
# That is all Replit needs to do. The code is complete and production-ready.
#
# ═══════════════════════════════════════════════════════════════════════════
# PART 1 — FILE DESTINATIONS (copy each file to this exact path in Replit)
# ═══════════════════════════════════════════════════════════════════════════
#
# SERVER ROUTERS (7 files) — copy to server/routers/
# ─────────────────────────────────────────────────
# server/routers/agmIntelligenceRouter.ts     → server/routers/agmIntelligenceRouter.ts
# server/routers/operationsRouter.ts          → server/routers/operationsRouter.ts
# server/routers/partnerRouter.ts             → server/routers/partnerRouter.ts
# server/routers/sessionConfigRouter.ts       → server/routers/sessionConfigRouter.ts
# server/routers/sessionMessagesRouter.ts     → server/routers/sessionMessagesRouter.ts
# server/routers/speakerQueueRouter.ts        → server/routers/speakerQueueRouter.ts
# server/routers/qaAnalyticsRouter.ts         → server/routers/qaAnalyticsRouter.ts
#
# SERVER SERVICES (5 files) — copy to server/services/
# ──────────────────────────────────────────────────────
# server/services/ComplianceDeadlineService.ts  → server/services/ComplianceDeadlineService.ts
# server/services/PreEventBriefingService.ts    → server/services/PreEventBriefingService.ts
# server/services/ClientDeliveryService.ts      → server/services/ClientDeliveryService.ts
# server/services/BoardIntelligenceService.ts   → server/services/BoardIntelligenceService.ts
# server/services/SessionClosePipeline.ts       → server/services/SessionClosePipeline.ts
#
# SERVER MIDDLEWARE (1 file) — copy to server/middleware/
# ────────────────────────────────────────────────────────
# server/middleware/brandConfig.ts              → server/middleware/brandConfig.ts
#
# SERVER EMAILS (1 file) — copy to server/emails/
# ────────────────────────────────────────────────
# server/emails/templates.ts                    → server/emails/templates.ts
#
# CLIENT COMPONENTS (4 files) — copy to client/src/components/
# ──────────────────────────────────────────────────────────────
# client/src/components/ClientMessagePanel.tsx  → client/src/components/ClientMessagePanel.tsx
# client/src/components/SessionScheduler.tsx    → client/src/components/SessionScheduler.tsx
# client/src/components/SessionSetupPanel.tsx   → client/src/components/SessionSetupPanel.tsx
# client/src/components/QAPatternPanel.tsx      → client/src/components/QAPatternPanel.tsx
#
# CLIENT PAGES (3 files) — copy to client/src/pages/
# ────────────────────────────────────────────────────
# client/src/pages/ClientLive.tsx               → client/src/pages/ClientLive.tsx
# client/src/pages/ClientReport.tsx             → client/src/pages/ClientReport.tsx
# client/src/pages/PresenterScreen.tsx          → client/src/pages/PresenterScreen.tsx
#
# CLIENT HOOKS (1 file) — copy to client/src/hooks/
# ───────────────────────────────────────────────────
# client/src/hooks/useBrandConfig.ts            → client/src/hooks/useBrandConfig.ts
#
# SCHEMA (2 files) — APPEND to drizzle/schema.ts (do NOT overwrite)
# ──────────────────────────────────────────────────────────────────
# schema/gaps.schema.ts     → APPEND contents to bottom of drizzle/schema.ts
# schema/partners.schema.ts → APPEND contents to bottom of drizzle/schema.ts
#
# ═══════════════════════════════════════════════════════════════════════════
# PART 2 — WIRING (6 steps — do these after copying all files)
# ═══════════════════════════════════════════════════════════════════════════

# ───────────────────────────────────────────────────────────────────────────
# STEP 1 — Register all 7 new routers in BOTH router files
# ───────────────────────────────────────────────────────────────────────────
# Open server/routers.eager.ts AND server/routers.ts
# Add these imports at the top of BOTH files:

import { agmIntelligenceRouter }   from "./routers/agmIntelligenceRouter";
import { operationsRouter }         from "./routers/operationsRouter";
import { partnerRouter }            from "./routers/partnerRouter";
import { sessionConfigRouter }      from "./routers/sessionConfigRouter";
import { sessionMessagesRouter }    from "./routers/sessionMessagesRouter";
import { speakerQueueRouter }       from "./routers/speakerQueueRouter";
import { qaAnalyticsRouter }        from "./routers/qaAnalyticsRouter";

# Add these entries inside the router object in BOTH files:

  agmIntelligence:   agmIntelligenceRouter,
  operations:        operationsRouter,
  partners:          partnerRouter,
  sessionConfig:     sessionConfigRouter,
  sessionMessages:   sessionMessagesRouter,
  speakerQueue:      speakerQueueRouter,
  qaAnalytics:       qaAnalyticsRouter,

# CRITICAL: Must be in BOTH routers.eager.ts AND routers.ts or they will
# silently fail at runtime with no error message.

# ───────────────────────────────────────────────────────────────────────────
# STEP 2 — Register brandConfig middleware in server/_core/index.ts
# ───────────────────────────────────────────────────────────────────────────
# Open server/_core/index.ts
# Add this import near the top:

import { brandConfigMiddleware } from "../middleware/brandConfig";

# Add this line BEFORE the tRPC middleware (before app.use('/api/trpc', ...)):

app.use(brandConfigMiddleware);

# ───────────────────────────────────────────────────────────────────────────
# STEP 3 — Register background services in server/_core/index.ts
# ───────────────────────────────────────────────────────────────────────────
# In the same server/_core/index.ts, add these imports:

import { startComplianceDeadlineMonitor } from "../services/ComplianceDeadlineService";
import { startBriefingScheduler }         from "../services/PreEventBriefingService";

# Add these calls in the server startup block (after DB connection confirmed):

startComplianceDeadlineMonitor(); // runs every 15 minutes
startBriefingScheduler();         // runs every 5 minutes

# ───────────────────────────────────────────────────────────────────────────
# STEP 4 — Wire SessionClosePipeline into shadowModeRouter.ts
# ───────────────────────────────────────────────────────────────────────────
# Open server/routers/shadowModeRouter.ts
# Add this import:

import { runSessionClosePipeline } from "../services/SessionClosePipeline";

# Find the closeSession mutation (the one that sets status = 'completed').
# After the database update that marks the session completed, add:

  // Fire the intelligence pipeline — non-blocking
  runSessionClosePipeline(input.sessionId).catch(console.error);

# This single line triggers:
#   - Compliance email to recipients within 2 minutes
#   - AI report generation (all 20 modules)
#   - Report link delivery to all recipients
#   - Board Intelligence auto-populate (Gap B) — non-blocking
#   - Briefing accuracy scoring — non-blocking
#   - Q&A intelligence summary — non-blocking

# ───────────────────────────────────────────────────────────────────────────
# STEP 5 — Add client routes to App.tsx
# ───────────────────────────────────────────────────────────────────────────
# Open client/src/App.tsx
# Add these imports:

import ClientLive      from "./pages/ClientLive";
import ClientReport    from "./pages/ClientReport";
import PresenterScreen from "./pages/PresenterScreen";

# Add these routes inside the router:

  <Route path="/live/:token"      component={ClientLive} />
  <Route path="/report/:token"    component={ClientReport} />
  <Route path="/presenter/:token" component={PresenterScreen} />

# ───────────────────────────────────────────────────────────────────────────
# STEP 6 — Add QAPatternPanel to Live Q&A tab in ShadowMode.tsx
# ───────────────────────────────────────────────────────────────────────────
# Open client/src/pages/ShadowMode.tsx (or wherever the Live Q&A tab is)
# Add this import:

import { QAPatternPanel } from "../components/QAPatternPanel";

# Inside the Live Q&A tab content, ABOVE the existing question queue list, add:

  {activeSession && (
    <QAPatternPanel
      sessionId={activeSession.id}
      isLive={activeSession.status === 'live'}
    />
  )}

# Also — wherever a question is approved or classified, add this call
# (fire and forget, do NOT await):

  trpc.qaAnalytics.checkCoordinatedQuestioning.mutate({
    sessionId: question.sessionId,
    askerFirm: question.askerFirm,
  }).catch(console.error);

# ═══════════════════════════════════════════════════════════════════════════
# PART 3 — SQL (run once in the Replit database console)
# ═══════════════════════════════════════════════════════════════════════════

-- Run this SQL block in the Replit PostgreSQL console:

-- 1. Governance score table for Board Intelligence
CREATE TABLE IF NOT EXISTS agm_governance_scores (
  id             SERIAL PRIMARY KEY,
  session_id     INTEGER,
  company        VARCHAR(200),
  overall_score  INTEGER DEFAULT 0,
  calculated_at  TIMESTAMP DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_governance_company
  ON agm_governance_scores (company);

-- 2. Seed partner records (Lumi and Bastion)
INSERT INTO partners (slug, name, display_name, primary_color, accent_color, model, revenue_share_pct, active)
VALUES
  ('lumi',    'Lumi Global',   'Lumi Intelligence',    '#1D9E75', '#0A2540', 'white_label',  20, true),
  ('bastion', 'Bastion Group', 'Bastion Intelligence', '#2563EB', '#1e3a5f', 'revenue_share', 20, true)
ON CONFLICT (slug) DO NOTHING;

-- 3. Demo tokens — insert against the most recently completed session
-- Replace SESSION_ID_HERE with the actual ID of your best completed test session
INSERT INTO client_tokens (token, session_id, recipient_name, recipient_email, access_type, expires_at, email_status)
VALUES
  ('demo-live-001',      SESSION_ID_HERE, 'Demo User', 'demo@curalive.com', 'live',   NOW() + INTERVAL '30 days', 'sent'),
  ('demo-report-001',    SESSION_ID_HERE, 'Demo User', 'demo@curalive.com', 'report', NOW() + INTERVAL '30 days', 'sent'),
  ('demo-presenter-001', SESSION_ID_HERE, 'Demo User', 'demo@curalive.com', 'presenter', NOW() + INTERVAL '30 days', 'sent')
ON CONFLICT DO NOTHING;

-- ═══════════════════════════════════════════════════════════════════════════
# PART 4 — SCHEMA MIGRATION
# ═══════════════════════════════════════════════════════════════════════════

# After appending schema/gaps.schema.ts and schema/partners.schema.ts to
# drizzle/schema.ts, run:

drizzle-kit push --force

# Then rebuild:

npm run build   # or whatever the Replit esbuild command is

# Then publish from the Replit UI.

# ═══════════════════════════════════════════════════════════════════════════
# PART 5 — VERIFICATION TESTS (run after deploy)
# ═══════════════════════════════════════════════════════════════════════════

# TEST V1 — Session close pipeline (run this first, most critical):
# 1. Create a test session. Add your own email as recipient.
# 2. Start the session. Paste this transcript:
#    "We expect margins to be in the range of 22 to 24 percent for the full year."
# 3. Close the session.
# MUST PASS ALL:
#   □ Compliance email arrives within 2 minutes with JSE rule reference + deadline
#   □ compliance_deadlines row in DB: SELECT * FROM compliance_deadlines WHERE session_id = [id]
#   □ Report link email arrives within 5 minutes
#   □ /report/[token] opens — all 10 tabs load with real content, no empty states

# TEST V2 — Pre-event briefing:
# 1. Schedule a session 65 minutes from now.
# 2. Wait. Do not trigger manually.
# MUST PASS:
#   □ Briefing email arrives between T-55 and T-65 minutes
#   □ Email contains readiness score + 5 predicted Q&A topics + 3 compliance hotspots
#   □ Content is specific to the company — not generic filler

# TEST GAP A — Q&A coordinated questioning detection:
# 1. Start a live session.
# 2. Submit 4 questions with askerFirm = "Goldman Sachs" within 10 minutes.
# MUST PASS:
#   □ Alert appears in QAPatternPanel: "Coordinated questioning — Goldman Sachs"
#   □ Alert simultaneously appears in CollapsibleBottomTray Flags tab
#   □ No manual operator action required to see either alert

# TEST GAP B — Board Intelligence auto-populate:
# 1. Ensure at least 1 open commitment exists in historical_commitments for a company.
# 2. Run and close a session for that company.
# MUST PASS (within 90 seconds of session close):
#   □ New commitments: SELECT * FROM historical_commitments WHERE company = '[co]' ORDER BY imported_at DESC LIMIT 5
#   □ Board Compass tab shows updated data on next load without manual refresh

# TEST V3 — White label:
# 1. Tag a session as Lumi partner.
# 2. Open /live/[token] in a browser.
# MUST PASS:
#   □ No CuraLive branding visible anywhere
#   □ Partner colours and logo applied throughout

# TEST V4 — Recall.ai bot:
# 1. Create a session with a real Zoom meeting URL.
# 2. Start the session.
# MUST PASS:
#   □ Bot joins within 60 seconds as "CuraLive Intelligence Agent"
#   □ Transcript streams within 90 seconds with speaker labels

# ═══════════════════════════════════════════════════════════════════════════
# CODING RULES — apply to every change made to this codebase
# ═══════════════════════════════════════════════════════════════════════════
#
# 1. tRPC routers MUST be registered in BOTH routers.eager.ts AND routers.ts
# 2. Always import tRPC from "../_core/trpc" — no other path
# 3. Only sonner for toasts
# 4. rawSql() auto-appends RETURNING id — do not add it manually
# 5. rawSql() translates ? to $1/$2 — do not use ? in raw SQL
# 6. Double-quote camelCase columns in raw SQL: "createdAt" not createdAt
# 7. Schema migrations: drizzle-kit push --force — never pnpm run db:push
# 8. Recall.ai webhook middleware MUST be before express.json()
# 9. Wrap PostgreSQL NUMERIC from rawSql() in Number() before arithmetic
# 10. Rebuild dist/ with esbuild before every publish
# 11. NEVER display on /live/:token, /report/:token, /presenter/:token:
#     Whisper, Recall.ai, GPT-4o, OpenAI, Gemini, Ably, Twilio, Mux, Resend
#     Use only: "CuraLive Intelligence Agent" / "AI transcription" / "CuraLive AI"
# 12. Session close pipeline steps 4-6 are non-blocking — never delay
#     the client-facing compliance email or report link delivery
#
# ═══════════════════════════════════════════════════════════════════════════
# Questions → Dave Cameron before proceeding. Do not interpret ambiguity.
# ═══════════════════════════════════════════════════════════════════════════
