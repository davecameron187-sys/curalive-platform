// ─────────────────────────────────────────────────────────────────────────────
// CuraLive — Board Intelligence Auto-Populate Service
// File: server/services/BoardIntelligenceService.ts
// Sprint 1 — Gap B
//
// CALLED FROM: shadowModeRouter.ts session close handler (non-blocking)
//   import { runBoardIntelligenceUpdate } from "../services/BoardIntelligenceService";
//   // After report generation completes:
//   runBoardIntelligenceUpdate({ sessionId, company, reportModules }).catch(console.error);
//
// WHAT THIS DOES:
//   1. Extracts new commitments from Module 08 report output
//   2. Verifies prior open commitments against what was said in this session
//   3. Logs board member activity (tone, compliance flags, segment count)
//   4. Updates governance score for this company
//
// INTELLIGENCE VALUE:
//   After 3 events: commitment delivery rate is measurable.
//   After 10 events: governance trajectory is projectable.
//   After 20 events: the Board Compass is the most valuable governance
//   intelligence dataset in the market for JSE-listed companies.
// ─────────────────────────────────────────────────────────────────────────────

import { getDb, rawSql } from "../db";
import { historicalCommitments, boardMembers } from "../../drizzle/schema";
import { eq, and } from "drizzle-orm";
import { invokeLLM } from "../_core/llm";

interface BoardIntelligenceUpdateOpts {
  sessionId:     number;
  company:       string;
  eventType?:    string;
  // Report module outputs — passed from the AI report pipeline
  reportModules?: {
    module08?: string; // Guidance Changes & Tracking — raw text/JSON output
    module07?: string; // Management Tone Analysis
    module05?: string; // Compliance Flags & Deadlines
    module19?: string; // Board Governance Review
  };
  // Transcript summary — used for prior commitment verification
  transcriptText?: string;
}

export async function runBoardIntelligenceUpdate(
  opts: BoardIntelligenceUpdateOpts
): Promise<void> {
  const startTime = Date.now();
  const db = await getDb();
  if (!db) return;

  console.log(`[BoardIntelligence] Starting update for session ${opts.sessionId} — ${opts.company}`);

  try {
    // Run all three operations in parallel — non-blocking
    await Promise.allSettled([
      extractAndSaveNewCommitments(opts),
      verifyPriorCommitments(opts),
      logBoardMemberActivity(opts),
    ]);

    // Update governance score last (depends on above)
    await updateGovernanceScore(opts);

    const elapsed = Date.now() - startTime;
    console.log(`[BoardIntelligence] Completed for session ${opts.sessionId} in ${elapsed}ms`);

  } catch (err) {
    // NEVER let Board Intelligence errors bubble up to the session close pipeline
    console.error(`[BoardIntelligence] Error for session ${opts.sessionId}:`, err);
  }
}

// ── 1. EXTRACT NEW COMMITMENTS FROM MODULE 08 ─────────────────────────────
async function extractAndSaveNewCommitments(
  opts: BoardIntelligenceUpdateOpts
): Promise<void> {
  const db = await getDb();
  if (!db || !opts.reportModules?.module08) return;

  try {
    // Parse Module 08 output — may be JSON string or structured text
    let module08Data: any;
    try {
      module08Data = typeof opts.reportModules.module08 === 'string'
        ? JSON.parse(opts.reportModules.module08)
        : opts.reportModules.module08;
    } catch {
      // Not JSON — treat as raw text and extract with LLM
      const extractPrompt = `Extract all forward guidance statements, capital commitments, and management promises from this text.

TEXT:
${opts.reportModules.module08}

Return a JSON array. Each item must have:
- commitment (string): the exact commitment or guidance statement
- committedBy (string): speaker name/role if identifiable, otherwise "Management"
- deadline (string|null): specific date or timeframe if mentioned, null if not
- type (string): "guidance" | "commitment" | "promise"

Return ONLY the JSON array, no other text.`;

      const response = await invokeLLM({ messages: [{ role: "user", content: extractPrompt }] });
      try {
        module08Data = { commitments: JSON.parse(response) };
      } catch {
        return; // If we can't parse, skip silently
      }
    }

    const commitments: any[] = Array.isArray(module08Data)
      ? module08Data
      : (module08Data?.commitments ?? module08Data?.guidanceChanges ?? []);

    if (!commitments.length) return;

    // Save each commitment to historical_commitments
    let saved = 0;
    for (const c of commitments) {
      if (!c.commitment || c.commitment.trim().length < 10) continue;

      // Calculate deadline if timeframe mentioned
      let deadlineDate: Date | undefined;
      if (c.deadline) {
        const parsed = parseFuzzyDeadline(c.deadline);
        if (parsed) deadlineDate = parsed;
      }

      try {
        await db.insert(historicalCommitments).values({
          company:     opts.company,
          eventType:   opts.eventType ?? 'earnings_call',
          eventDate:   new Date(),
          commitment:  c.commitment.trim(),
          committedBy: c.committedBy ?? 'Management',
          deadline:    deadlineDate,
          status:      'open',
          verifiedInSessionId: opts.sessionId,
        });
        saved++;
      } catch {
        // Skip duplicates or constraint errors
      }
    }

    console.log(`[BoardIntelligence] Saved ${saved} new commitments for ${opts.company}`);

  } catch (err) {
    console.error('[BoardIntelligence] extractAndSaveNewCommitments error:', err);
  }
}

// ── 2. VERIFY PRIOR OPEN COMMITMENTS ──────────────────────────────────────
async function verifyPriorCommitments(
  opts: BoardIntelligenceUpdateOpts
): Promise<void> {
  const db = await getDb();
  if (!db) return;

  try {
    // Get all open commitments for this company
    const [openCommitments] = await rawSql(
      `SELECT id, commitment, "committedBy", deadline, status
       FROM historical_commitments
       WHERE company = $1 AND status = 'open'
       ORDER BY "eventDate" DESC
       LIMIT 20`,
      [opts.company]
    );

    if (!openCommitments.length) return;

    const transcriptContext = opts.transcriptText ?? opts.reportModules?.module08 ?? '';
    if (!transcriptContext || transcriptContext.length < 100) return;

    // Use LLM to check which prior commitments were addressed
    const verifyPrompt = `You are an IR analyst reviewing whether prior management commitments were addressed in a recent event.

PRIOR OPEN COMMITMENTS:
${openCommitments.map((c: any, i: number) =>
  `${i + 1}. [ID:${c.id}] "${c.commitment}" (by ${c.committedBy || 'Management'})`
).join('\n')}

CURRENT EVENT TRANSCRIPT/REPORT:
${transcriptContext.slice(0, 3000)}

For each commitment, determine if it was:
- "met": explicitly addressed and confirmed or delivered
- "partial": mentioned but only partially addressed
- "at_risk": was expected and not mentioned at all
- "open": not relevant to this event yet

Return a JSON array with objects: { id: number, status: "met"|"partial"|"at_risk"|"open", evidence: string }
Return ONLY the JSON array.`;

    const response = await invokeLLM({ messages: [{ role: "user", content: verifyPrompt }] });

    let verifications: Array<{ id: number; status: string; evidence: string }>;
    try {
      verifications = JSON.parse(response);
    } catch {
      return;
    }

    // Update statuses — only change if evidence is meaningful
    for (const v of verifications) {
      if (!v.id || !v.status || v.status === 'open') continue;

      const validStatuses = ['met', 'partial', 'at_risk'];
      if (!validStatuses.includes(v.status)) continue;

      await rawSql(
        `UPDATE historical_commitments
         SET status = $1, "verifiedInSessionId" = $2
         WHERE id = $3 AND company = $4`,
        [v.status, opts.sessionId, v.id, opts.company]
      );
    }

    const updated = verifications.filter(v => v.status !== 'open').length;
    console.log(`[BoardIntelligence] Verified ${updated} prior commitments for ${opts.company}`);

  } catch (err) {
    console.error('[BoardIntelligence] verifyPriorCommitments error:', err);
  }
}

// ── 3. LOG BOARD MEMBER ACTIVITY ──────────────────────────────────────────
async function logBoardMemberActivity(
  opts: BoardIntelligenceUpdateOpts
): Promise<void> {
  const db = await getDb();
  if (!db) return;

  try {
    // Get board members for this company
    const members = await db
      .select()
      .from(boardMembers)
      .where(and(
        eq(boardMembers.company, opts.company),
        eq(boardMembers.active, true)
      ));

    if (!members.length) return;

    const transcript = opts.transcriptText ?? '';
    if (!transcript) return;

    // Get compliance flags attributed to each speaker in this session
    const [flagRows] = await rawSql(
      `SELECT speaker, COUNT(*)::int as flag_count, flag_type
       FROM regulatory_flags
       WHERE monitor_id = $1
       GROUP BY speaker, "flagType"`,
      [opts.sessionId]
    );

    // Get transcript segment counts per speaker
    const [segmentRows] = await rawSql(
      `SELECT speaker, COUNT(*)::int as segments
       FROM transcript_segments
       WHERE "sessionId" = $1
       GROUP BY speaker`,
      [opts.sessionId]
    );

    // For each active board member, check if they spoke
    for (const member of members) {
      const memberName = member.name.toLowerCase();

      // Match by name in transcript speakers
      const speakerSegments = segmentRows.find((r: any) =>
        r.speaker?.toLowerCase().includes(memberName.split(' ')[0]) ||
        r.speaker?.toLowerCase().includes(memberName.split(' ').slice(-1)[0])
      );

      if (!speakerSegments) continue;

      // Get their compliance flags
      const memberFlags = flagRows.filter((r: any) =>
        r.speaker?.toLowerCase().includes(memberName.split(' ')[0])
      );
      const totalFlags = memberFlags.reduce((s: number, r: any) => s + Number(r.flag_count), 0);

      // Log activity against board member record
      await rawSql(
        `UPDATE board_members
         SET notes = COALESCE(notes, '') || $1
         WHERE id = $2`,
        [
          `\n[Session ${opts.sessionId} — ${new Date().toISOString().slice(0, 10)}] Spoke: ${speakerSegments.segments} segments. Compliance flags: ${totalFlags}.`,
          member.id,
        ]
      );
    }

  } catch (err) {
    console.error('[BoardIntelligence] logBoardMemberActivity error:', err);
  }
}

// ── 4. UPDATE GOVERNANCE SCORE ────────────────────────────────────────────
async function updateGovernanceScore(
  opts: BoardIntelligenceUpdateOpts
): Promise<void> {
  try {
    const db = await getDb();
    if (!db) return;

    // Get commitment delivery stats for this company
    const [stats] = await rawSql(
      `SELECT
         COUNT(*) FILTER (WHERE status = 'open')::int    as open_count,
         COUNT(*) FILTER (WHERE status = 'met')::int     as met_count,
         COUNT(*) FILTER (WHERE status = 'missed')::int  as missed_count,
         COUNT(*) FILTER (WHERE status = 'partial')::int as partial_count,
         COUNT(*) FILTER (WHERE status = 'at_risk')::int as at_risk_count,
         COUNT(*)::int                                   as total_count
       FROM historical_commitments
       WHERE company = $1`,
      [opts.company]
    );

    const s = stats[0];
    if (!s || Number(s.total_count) === 0) return;

    const total   = Number(s.total_count);
    const met     = Number(s.met_count);
    const partial = Number(s.partial_count);
    const missed  = Number(s.missed_count);
    const atRisk  = Number(s.at_risk_count);

    // Score = (met * 100 + partial * 60 - missed * 100 - atRisk * 40) / total
    // Clamped 0–100
    const rawScore = ((met * 100) + (partial * 60) - (missed * 100) - (atRisk * 40)) / total;
    const score    = Math.max(0, Math.min(100, Math.round(rawScore)));

    // Get recent compliance flag count for this company
    const [flagStats] = await rawSql(
      `SELECT COUNT(*)::int as flag_count
       FROM regulatory_flags rf
       JOIN shadow_sessions s ON s.id = rf."sessionId"
       WHERE s.company = $1
         AND rf."createdAt" > NOW() - INTERVAL '90 days'`,
      [opts.company]
    );
    const recentFlags = Number(flagStats[0]?.flag_count ?? 0);

    // Deduct up to 20 points for recent compliance flags
    const compliancePenalty = Math.min(20, recentFlags * 2);
    const finalScore = Math.max(0, score - compliancePenalty);

    // Upsert governance score into agm_governance_scores
    await rawSql(
      `INSERT INTO agm_governance_scores ("sessionId", "company", "overallScore", "calculatedAt")
       VALUES ($1, $2, $3, NOW())
       ON CONFLICT ("company") DO UPDATE
       SET "overallScore" = $3, "calculatedAt" = NOW()`,
      [opts.sessionId, opts.company, finalScore]
    );

    console.log(`[BoardIntelligence] Governance score for ${opts.company}: ${finalScore}/100`);

  } catch (err) {
    // agm_governance_scores may not have a company unique index — that's fine
    console.error('[BoardIntelligence] updateGovernanceScore error:', err);
  }
}

// ── HELPERS ───────────────────────────────────────────────────────────────
function parseFuzzyDeadline(str: string): Date | undefined {
  if (!str) return undefined;
  const s = str.toLowerCase();
  const now = new Date();

  if (s.includes('q1')) return new Date(now.getFullYear(), 2, 31);
  if (s.includes('q2')) return new Date(now.getFullYear(), 5, 30);
  if (s.includes('q3')) return new Date(now.getFullYear(), 8, 30);
  if (s.includes('q4')) return new Date(now.getFullYear(), 11, 31);
  if (s.includes('full year') || s.includes('year end')) return new Date(now.getFullYear(), 11, 31);
  if (s.includes('half year') || s.includes('h1')) return new Date(now.getFullYear(), 5, 30);
  if (s.includes('h2')) return new Date(now.getFullYear(), 11, 31);

  // Try direct date parsing
  const parsed = new Date(str);
  if (!isNaN(parsed.getTime())) return parsed;

  return undefined;
}
