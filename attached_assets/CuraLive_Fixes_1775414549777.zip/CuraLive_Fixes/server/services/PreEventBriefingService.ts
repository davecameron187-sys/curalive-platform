// ─────────────────────────────────────────────────────────────
// CuraLive — Pre-Event Briefing Service
// File: server/services/PreEventBriefingService.ts
// Covers: Gap 10.1 (auto-trigger 60 mins before session)
//         Gap 10.2 (deliver briefing to client recipients)
//         Gap 10.3 (accuracy scoring post-session)
//
// ADD to server/_core/index.ts:
//   import { startBriefingScheduler } from "../services/PreEventBriefingService";
//   startBriefingScheduler(); // checks every 5 minutes
// ─────────────────────────────────────────────────────────────

import { getDb, rawSql } from "../db";
import { briefingAccuracyScores, scheduledSessions } from "../../drizzle/schema";
import { eq } from "drizzle-orm";
import { Resend } from "resend";
import { invokeLLM } from "../_core/llm";

const resend = new Resend(process.env.RESEND_API_KEY);
const APP_URL = process.env.APP_URL ?? "https://app.curalive.com";

// ── GAP 10.1 — AUTO-TRIGGER BRIEFING 60 MINUTES BEFORE ───────
export function startBriefingScheduler() {
  const INTERVAL_MS = 5 * 60 * 1000; // check every 5 minutes

  async function checkAndSendBriefings() {
    const db = await getDb();
    if (!db) return;

    const now = new Date();
    const in65Mins = new Date(now.getTime() + 65 * 60 * 1000);
    const in55Mins = new Date(now.getTime() + 55 * 60 * 1000);

    // Find scheduled sessions where briefing window is now
    const sessions = await db
      .select()
      .from(scheduledSessions)
      .where(eq(scheduledSessions.status, "scheduled"));

    for (const session of sessions) {
      if (!session.scheduledAt) continue;

      const sessionTime = session.scheduledAt.getTime();
      const inWindow =
        sessionTime >= in55Mins.getTime() &&
        sessionTime <= in65Mins.getTime() &&
        !session.preBriefSentAt;

      if (!inWindow) continue;

      try {
        // Generate and send pre-event briefing
        await generateAndSendPreBriefing({
          scheduledSessionId: session.id,
          company:            session.company ?? "Company",
          eventName:          session.title,
          eventType:          session.eventType ?? "earnings_call",
          scheduledAt:        session.scheduledAt,
          jurisdiction:       session.jurisdiction ?? "JSE",
          recipients:         (session.recipients as any[]) ?? [],
          partnerId:          session.partnerId ?? undefined,
        });

        // Mark briefing sent
        await db
          .update(scheduledSessions)
          .set({ preBriefSentAt: new Date() })
          .where(eq(scheduledSessions.id, session.id));

        console.log(`[BriefingScheduler] Pre-event briefing sent for session ${session.id}`);
      } catch (err) {
        console.error(`[BriefingScheduler] Failed for session ${session.id}:`, err);
      }
    }
  }

  checkAndSendBriefings().catch(console.error);
  setInterval(() => checkAndSendBriefings().catch(console.error), INTERVAL_MS);
  console.log("[BriefingScheduler] Started — checking every 5 minutes");
}

// ── GAP 10.2 — GENERATE AND DELIVER PRE-EVENT BRIEFING ───────
export async function generateAndSendPreBriefing(opts: {
  scheduledSessionId: number;
  company:            string;
  eventName:          string;
  eventType:          string;
  scheduledAt:        Date;
  jurisdiction:       string;
  recipients:         Array<{ name: string; email: string; role?: string; sendLive?: boolean }>;
  partnerId?:         number;
}) {
  if (!opts.recipients.length) return;

  // Generate briefing content via LLM
  const prompt = `You are a senior investor relations intelligence analyst. Generate a pre-event intelligence briefing for:

Company: ${opts.company}
Event: ${opts.eventName}
Type: ${opts.eventType}
Scheduled: ${opts.scheduledAt.toLocaleString()}
Jurisdiction: ${opts.jurisdiction}

Generate a structured pre-event briefing covering:
1. Analyst consensus expectations (revenue, EPS, margins — use realistic estimates)
2. Predicted Q&A themes (5-7 likely questions based on event type and sector)
3. Compliance hotspots to watch (jurisdiction-specific rules likely to be triggered)
4. Management preparation areas (where hedging language is likely needed)
5. Market sentiment indicators
6. Readiness score (0-100)

Respond as JSON with keys: consensusExpectations, predictedQA, complianceHotspots, preparationAreas, marketSentiment, readinessScore, readinessSummary.`;

  let briefingContent: any;
  try {
    const llmResponse = await invokeLLM({ messages: [{ role: "user", content: prompt }] });
    briefingContent = JSON.parse(typeof llmResponse === "string" ? llmResponse : JSON.stringify(llmResponse));
  } catch {
    briefingContent = {
      readinessSummary: "Pre-event briefing generated.",
      readinessScore: 80,
      predictedQA: [],
      complianceHotspots: [],
      consensusExpectations: {},
    };
  }

  // Send to each recipient
  for (const recipient of opts.recipients) {
    const html = buildPreBriefEmail({
      recipientName: recipient.name,
      company:       opts.company,
      eventName:     opts.eventName,
      scheduledAt:   opts.scheduledAt,
      briefing:      briefingContent,
    });

    await resend.emails.send({
      from:    "CuraLive Intelligence <noreply@curalive.com>",
      to:      recipient.email,
      subject: `📋 Pre-event briefing — ${opts.company} ${opts.eventName} (60 min)`,
      html,
    });
  }

  return briefingContent;
}

// ── GAP 10.3 — CALCULATE BRIEFING ACCURACY POST-SESSION ──────
export async function calculateBriefingAccuracy(opts: {
  briefingId:             number;
  sessionId:              number;
  predictedTopics:        string[];
  actualTopicsDiscussed:  string[];
  predictedQACount:       number;
  actualQACount:          number;
  predictedComplianceHotspots: string[];
  actualComplianceFlags:  string[];
}) {
  const db = await getDb();
  if (!db) return;

  // Simple topic matching (in production: use embedding similarity)
  const topicMatches = opts.predictedTopics.filter(topic =>
    opts.actualTopicsDiscussed.some(actual =>
      actual.toLowerCase().includes(topic.toLowerCase().slice(0, 6))
    )
  ).length;

  const hotspotMatches = opts.predictedComplianceHotspots.filter(hs =>
    opts.actualComplianceFlags.some(flag =>
      flag.toLowerCase().includes(hs.toLowerCase().slice(0, 8))
    )
  ).length;

  // Calculate accuracy
  const topicAccuracy   = opts.predictedTopics.length > 0 ? Math.round((topicMatches / opts.predictedTopics.length) * 100) : 100;
  const hotspotAccuracy = opts.predictedComplianceHotspots.length > 0 ? Math.round((hotspotMatches / opts.predictedComplianceHotspots.length) * 100) : 100;
  const qaAccuracy      = opts.predictedQACount > 0 ? Math.min(100, Math.round((opts.actualQACount / opts.predictedQACount) * 100)) : 100;
  const overallAccuracy = Math.round((topicAccuracy + hotspotAccuracy + qaAccuracy) / 3);

  await db.insert(briefingAccuracyScores).values({
    briefingId:               opts.briefingId,
    sessionId:                opts.sessionId,
    predictedQaCount:         opts.predictedQACount,
    actualQaCount:            opts.actualQACount,
    topicsCorrect:            topicMatches,
    topicsTotal:              opts.predictedTopics.length,
    complianceHotspotsHit:    hotspotMatches,
    complianceHotspotsTotal:  opts.predictedComplianceHotspots.length,
    overallAccuracyPct:       overallAccuracy,
  });

  return overallAccuracy;
}

// ── EMAIL TEMPLATE ────────────────────────────────────────────
function buildPreBriefEmail(opts: {
  recipientName: string;
  company:       string;
  eventName:     string;
  scheduledAt:   Date;
  briefing:      any;
}): string {
  const { briefing } = opts;
  const qaHtml = (briefing.predictedQA ?? []).slice(0, 5).map((q: string, i: number) =>
    `<div style="padding:8px 0;border-bottom:1px solid #f0f0f0;font-size:11px;color:#2c3042;"><strong>${i+1}.</strong> ${q}</div>`
  ).join("");

  const hotspotHtml = (briefing.complianceHotspots ?? []).slice(0, 4).map((h: string) =>
    `<div style="padding:6px 0;font-size:11px;color:#BA7517;">⚠ ${h}</div>`
  ).join("");

  return `<!DOCTYPE html><html><body style="font-family:sans-serif;background:#f4f5f8;padding:24px;">
    <div style="max-width:600px;margin:0 auto;background:#fff;border-radius:12px;overflow:hidden;border:1px solid #e2e5ed;">
      <div style="background:#0A2540;padding:20px 24px;">
        <div style="font-size:18px;font-weight:300;color:#fff;">Pre-Event Intelligence Briefing</div>
        <div style="font-size:12px;color:rgba(255,255,255,0.4);margin-top:2px;">${opts.company} — ${opts.eventName}</div>
        <div style="font-size:11px;color:rgba(255,255,255,0.25);margin-top:2px;">Starting ${opts.scheduledAt.toLocaleString()} · 60 minutes to go</div>
      </div>
      <div style="padding:24px;">
        <p style="font-size:13px;color:#2c3042;line-height:1.7;margin-bottom:20px;">Hi ${opts.recipientName},<br><br>
        Your CuraLive pre-event intelligence briefing is ready. Review before the session begins.</p>

        <div style="background:#e8f7ef;border-radius:8px;padding:12px 16px;margin-bottom:16px;text-align:center;">
          <div style="font-size:2rem;font-weight:200;color:#137a3c;">${briefing.readinessScore ?? 80}</div>
          <div style="font-size:11px;color:#137a3c;font-weight:600;">Readiness score</div>
          <div style="font-size:11px;color:#6b7280;margin-top:3px;">${briefing.readinessSummary ?? ""}</div>
        </div>

        ${qaHtml ? `<div style="margin-bottom:16px;"><div style="font-size:12px;font-weight:600;color:#0A2540;margin-bottom:8px;">Predicted Q&A themes</div>${qaHtml}</div>` : ""}
        ${hotspotHtml ? `<div style="margin-bottom:16px;background:#fef8e8;border-radius:8px;padding:12px 14px;"><div style="font-size:12px;font-weight:600;color:#BA7517;margin-bottom:6px;">Compliance hotspots to monitor</div>${hotspotHtml}</div>` : ""}

        <div style="background:#f4f5f8;border-radius:8px;padding:12px;font-size:11px;color:#6b7280;">
          CuraLive Intelligence Agent will be active throughout the session. Your live dashboard link will be sent when the session goes live.
        </div>
      </div>
    </div>
  </body></html>`;
}
