# CuraLive — Code Fixes Upload
# April 2026
# ═══════════════════════════════════════════════════════════
#
# This package contains 5 corrected files.
# Overwrite the existing files in Replit with these versions.
# No new wiring needed — these are drop-in replacements.
#
# ═══════════════════════════════════════════════════════════
# FILE DESTINATIONS — overwrite exactly these paths:
# ═══════════════════════════════════════════════════════════
#
#   server/routers/qaAnalyticsRouter.ts
#   server/services/BoardIntelligenceService.ts
#   server/services/SessionClosePipeline.ts
#   server/services/PreEventBriefingService.ts
#   client/src/components/QAPatternPanel.tsx
#
# ═══════════════════════════════════════════════════════════
# WHAT WAS FIXED IN EACH FILE:
# ═══════════════════════════════════════════════════════════
#
# qaAnalyticsRouter.ts
#   - rawSql() tuple destructuring: const [rows] = await rawSql()
#   - approved_questions_queue column names corrected to snake_case
#     (asker_firm, session_id, created_at, ai_suggested_answer)
#
# BoardIntelligenceService.ts
#   - LLM calls fixed: invokeLLM({ messages: [...] }) replaces llm.complete()
#   - rawSql() tuple destructuring applied throughout
#   - regulatory_flags column names fixed: monitor_id, statement, rule_basis
#   - transcript segments table fixed: occ_transcription_segments,
#     conference_id, content
#
# SessionClosePipeline.ts
#   - sendReportLinks imported correctly (was sendPostEventReport which
#     does not exist — now aliased from ClientDeliveryService)
#   - trpc-caller import removed (does not exist in this codebase)
#   - regulatory_flags query uses monitor_id not session_id
#   - rawSql() tuple destructuring applied throughout
#   - flag column mapping corrected to use statement/rule_basis
#
# PreEventBriefingService.ts
#   - LLM call fixed: invokeLLM({ messages: [...] }) replaces llm.complete()
#   - rawSql() tuple destructuring applied throughout
#
# QAPatternPanel.tsx
#   - Broken useAbly() integration removed entirely
#     (useAbly returns AblyContextValue, not an Ably client — calling
#     ably.channels.get() on it throws at runtime)
#   - Switched to polling-only at 15-second refresh interval
#   - Coordination alerts still surface via the server-side Ably publish
#     on the next poll cycle
#
# ═══════════════════════════════════════════════════════════
# AFTER UPLOADING — set these two environment variables:
# ═══════════════════════════════════════════════════════════
#
#   In Replit Secrets:
#   APP_URL = https://curalive-platform.replit.app
#
#   Confirm RESEND_API_KEY is already set.
#   Without APP_URL, all tokenised links in emails point to the wrong domain.
#
# ═══════════════════════════════════════════════════════════
# AFTER UPLOADING — rebuild and publish:
# ═══════════════════════════════════════════════════════════
#
#   drizzle-kit push --force
#   npm run build
#   Publish from Replit UI
#
# ═══════════════════════════════════════════════════════════
# VERIFICATION TEST — run this after publishing:
# ═══════════════════════════════════════════════════════════
#
# 1. Create a test session. Add your own email as recipient.
# 2. Paste this as the transcript:
#    "We expect margins to be in the range of 22 to 24 percent for the full year."
# 3. Close the session.
#
# PASS criteria (all must be true):
#   □ Compliance email arrives in inbox within 2 minutes
#   □ Email contains a JSE rule reference and 48-hour deadline
#   □ Row in compliance_deadlines:
#     SELECT * FROM compliance_deadlines WHERE session_id = [id]
#   □ Report link email arrives within 5 minutes
#   □ /report/[token] opens — all 10 tabs load with content, no empty states
#
# If any step fails, check server logs for [SessionClose] error lines.
