# CuraLive — Code Fixes (v2)
# April 2026 — Updated after architecture brief review
# ═══════════════════════════════════════════════════════════
#
# This package contains 5 corrected files.
# Overwrite the existing files in Replit with these versions.
# No new wiring needed — drop-in replacements only.
#
# ═══════════════════════════════════════════════════════════
# FILE DESTINATIONS — overwrite exactly these paths:
# ═══════════════════════════════════════════════════════════
#
#   server/routers/qaAnalyticsRouter.ts
#   server/services/BoardIntelligenceService.ts
#   server/services/SessionClosePipeline.ts
#   server/services/PreEventBriefingService.ts
#   client/src/components/QAPatternPanel.tsx
#
# ═══════════════════════════════════════════════════════════
# WHAT WAS FIXED (v2 — all bugs from architecture brief):
# ═══════════════════════════════════════════════════════════
#
# qaAnalyticsRouter.ts
#   - rawSql() tuple destructuring: const [rows] = await rawSql()
#   - approved_questions_queue columns corrected to snake_case
#     (asker_firm, session_id, created_at, ai_suggested_answer)
#
# BoardIntelligenceService.ts
#   - invokeLLM() response extraction fixed:
#     result.choices?.[0]?.message?.content (not result.content)
#   - JSON.parse now applied to extracted text string, not InvokeResult
#   - rawSql() tuple destructuring applied throughout
#   - regulatory_flags columns fixed: monitor_id, statement, rule_basis
#
# SessionClosePipeline.ts
#   - sendComplianceCloseEmail deadlines: hours: number (not deadline: Date)
#   - compliance_deadlines INSERT uses deadline_at (not deadline)
#   - calculateBriefingAccuracy called with sessionId: number only
#   - sendReportLinks imported correctly (aliased as sendPostEventReport)
#   - trpc-caller import removed (does not exist)
#   - rawSql() tuple destructuring applied throughout
#
# PreEventBriefingService.ts
#   - invokeLLM() response extraction fixed:
#     result.choices?.[0]?.message?.content (not result.content)
#   - rawSql() tuple destructuring applied throughout
#
# QAPatternPanel.tsx
#   - Broken useAbly() integration removed entirely
#   - Polling-only at 15s refresh interval
#
# ═══════════════════════════════════════════════════════════
# REQUIRED ENVIRONMENT VARIABLES — set in Replit Secrets:
# ═══════════════════════════════════════════════════════════
#
#   RESEND_API_KEY — email delivery (currently disabled — must set this
#                    before any email test can pass)
#   APP_URL = https://curalive-platform.replit.app
#             (already set per architecture brief — confirm it is present)
#
# ═══════════════════════════════════════════════════════════
# KNOWN LIMITATION — generateAIReport() is a placeholder:
# ═══════════════════════════════════════════════════════════
#
# Per the architecture brief, the 20-module AI report pipeline is not yet
# wired in SessionClosePipeline.ts. The generateAIReport() function sets
# status to 'processing' then immediately 'completed' and returns {}.
# The report link email will fire correctly but the report will have no
# AI-generated content until the actual pipeline is wired.
# This is a separate sprint item — it does not block the pipeline test.
#
# ═══════════════════════════════════════════════════════════
# AFTER UPLOADING:
# ═══════════════════════════════════════════════════════════
#
#   drizzle-kit push --force
#   npm run build
#   Publish from Replit UI
#
# ═══════════════════════════════════════════════════════════
# VERIFICATION TEST:
# ═══════════════════════════════════════════════════════════
#
# 1. Confirm RESEND_API_KEY is set in Replit Secrets
# 2. Create a test session. Add your own email as recipient.
# 3. Add transcript: "We expect margins of 22 to 24 percent for the full year."
# 4. Close the session.
#
# PASS criteria:
#   □ [SessionClose] log lines appear in server console
#   □ compliance_deadlines row created:
#     SELECT * FROM compliance_deadlines ORDER BY created_at DESC LIMIT 3
#   □ Compliance email arrives in inbox within 2 minutes
#   □ Report link email arrives within 5 minutes
#   □ /report/[token] opens (content will be empty until AI pipeline wired)
#
# If no log lines appear: confirm runSessionClosePipeline(sessionId) is
# called from the closeSession mutation in shadowModeRouter.ts
