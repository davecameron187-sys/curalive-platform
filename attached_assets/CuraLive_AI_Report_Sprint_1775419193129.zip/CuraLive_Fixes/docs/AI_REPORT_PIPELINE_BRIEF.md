# CuraLive — AI Report Pipeline Sprint
# Replit Build Brief
# April 2026
# ═══════════════════════════════════════════════════════════════════════════
#
# OBJECTIVE
# Wire the 20-module AI report pipeline so that every customer receives a
# substantive intelligence report within 5 minutes of their event closing.
# This is the single most important remaining build item before launch.
#
# CONTEXT
# The session close pipeline (SessionClosePipeline.ts) runs correctly.
# The compliance email fires. The database writes are correct.
# The report link email fires. The token is generated.
# But when the customer opens /report/:token, all 10 tabs are empty because
# generateAIReport() was a placeholder that returned {}.
#
# This sprint fixes that.
#
# ═══════════════════════════════════════════════════════════════════════════
# FILES IN THIS PACKAGE (3 files — all are drop-in replacements)
# ═══════════════════════════════════════════════════════════════════════════
#
# NEW FILE:
#   server/services/AIReportPipeline.ts
#   → Drop into server/services/
#   → No router registration needed — it's a service, not a router
#
# UPDATED FILE:
#   server/services/SessionClosePipeline.ts
#   → Overwrite existing file
#   → Now imports generateAIReport from AIReportPipeline
#   → Placeholder function removed
#
# UPDATED FILE:
#   server/services/PreEventBriefingService.ts
#   → Overwrite existing file
#   → BriefingScheduler bug fixed (was querying columns that don't exist
#     on scheduled_sessions: status, title, jurisdiction)
#   → Scheduler now filters by pre_brief_sent_at IS NULL instead
#
# ═══════════════════════════════════════════════════════════════════════════
# STEP 1 — ONE CRITICAL CHECK BEFORE ANYTHING ELSE
# ═══════════════════════════════════════════════════════════════════════════
#
# The report page (ClientReport.tsx) reads: reportData.aiReport
# This means getSessionReport must return an aiReport field.
#
# Where does getSessionReport read aiReport from?
# Check shadowModeRouter.ts — find the getSessionReport procedure.
#
# It will be one of:
#   Option A: SELECT result FROM agentic_analyses WHERE session_id = $1
#             AND analysis_type = 'full_report'
#   Option B: SELECT tagged_metrics_generated FROM shadow_sessions WHERE id = $1
#   Option C: A different column or table
#
# In AIReportPipeline.ts, the saveReport() function tries Option A first,
# then falls back to Option B.
#
# After deploying, run this SQL to confirm which table holds the report:
#   SELECT table_name FROM information_schema.tables
#   WHERE table_name IN ('agentic_analyses', 'shadow_sessions')
#   AND table_schema = 'public';
#
#   SELECT column_name FROM information_schema.columns
#   WHERE table_name = 'agentic_analyses';
#
# If agentic_analyses has different columns than expected, update saveReport()
# in AIReportPipeline.ts to match. The key output is the JSON blob that
# getSessionReport returns as aiReport.
#
# ═══════════════════════════════════════════════════════════════════════════
# STEP 2 — DROP IN THE FILES
# ═══════════════════════════════════════════════════════════════════════════
#
# 1. Copy AIReportPipeline.ts → server/services/AIReportPipeline.ts (NEW)
# 2. Overwrite SessionClosePipeline.ts → server/services/SessionClosePipeline.ts
# 3. Overwrite PreEventBriefingService.ts → server/services/PreEventBriefingService.ts
#
# ═══════════════════════════════════════════════════════════════════════════
# STEP 3 — CONFIRM GETSERVERREPORT RETURNS AIREPORT
# ═══════════════════════════════════════════════════════════════════════════
#
# Open server/routers/shadowModeRouter.ts
# Find the getSessionReport procedure
# Confirm it returns aiReport: <the JSON blob from wherever it's stored>
#
# If it currently returns tagged_metrics_generated as aiReport:
#   → Update saveReport() Option B in AIReportPipeline.ts to write there
#
# If it reads from agentic_analyses:
#   → The default Option A in saveReport() should work — just confirm the
#     column names match (session_id, analysis_type, result)
#
# ═══════════════════════════════════════════════════════════════════════════
# STEP 4 — REBUILD AND DEPLOY
# ═══════════════════════════════════════════════════════════════════════════
#
#   npm run build
#   Publish from Replit UI
#
# ═══════════════════════════════════════════════════════════════════════════
# STEP 5 — VERIFICATION TEST
# ═══════════════════════════════════════════════════════════════════════════
#
# 1. Create a test session with a real transcript (at least 5 minutes long)
# 2. Close the session
# 3. Watch server logs for:
#    [AIReport] Starting report generation...
#    [AIReport] Report generated in Xms
# 4. Open /report/[token]
#
# PASS criteria — every tab must have content:
#   □ Executive Summary: a specific verdict paragraph + 4 metric cards
#   □ Compliance: flags listed OR confirmation of clean compliance
#   □ Financial metrics: paragraph analysis (not empty)
#   □ Management tone: paragraph analysis (not empty)
#   □ Q&A log: analysis of questions (not empty)
#   □ Board actions: action register (not empty)
#   □ Social media pack: LinkedIn post + SENS social + key messages
#   □ SENS/RNS Draft: formatted JSE SENS announcement
#   □ Certificate: certificate card with session details
#
# If any tab shows "This module is loading or not yet available":
#   Check server logs for [AIReport] module failed errors
#   The most likely cause: transcript is empty (check occ_transcription_segments
#   has rows for this session's conference_id)
#
# ═══════════════════════════════════════════════════════════════════════════
# WHAT THE PIPELINE DOES (for reference)
# ═══════════════════════════════════════════════════════════════════════════
#
# generateAIReport() in AIReportPipeline.ts:
#
# 1. Loads transcript from occ_transcription_segments WHERE conference_id = sessionId
#    Fallback: shadow_sessions.local_transcript_json
#
# 2. Loads compliance flags from regulatory_flags WHERE monitor_id = sessionId
#
# 3. Loads Q&A from approved_questions_queue WHERE session_id = sessionId
#
# 4. Runs 3 core modules in parallel (invokeLLM for each):
#    - executiveSummary  → JSON: { verdict, metrics[] }
#    - complianceFlags   → JSON: [{ title, description, action, severity, ruleRef, deadline }]
#    - managementTone    → string (formatted paragraphs)
#
# 5. Runs 7 remaining modules in parallel:
#    - financialMetrics  → string
#    - qaQuality         → string
#    - boardActions      → string
#    - socialMediaPack   → string
#    - sensRnsDraft      → string (JSE SENS format)
#    - boardIntelligence → JSON: { governanceScore, scoreSummary, commitments[], riskAreas[] }
#    - criticalActions   → JSON: [{ title, detail, priority }]
#
# 6. Saves assembled report JSON to database
#
# 7. Returns module keys for BoardIntelligenceService to use
#
# Total LLM calls: 10 (run in 2 parallel batches)
# Expected runtime: 15-45 seconds depending on transcript length
#
# ═══════════════════════════════════════════════════════════════════════════
# KNOWN ISSUE — TRANSCRIPT AVAILABILITY
# ═══════════════════════════════════════════════════════════════════════════
#
# The pipeline reads transcript from occ_transcription_segments.conference_id
# This assumes the session's Recall.ai bot joined and transcript was captured.
#
# For sessions where:
#   - The bot didn't join (manual sessions)
#   - Transcript was pasted manually
#   - conference_id doesn't link correctly to sessionId
#
# The pipeline falls back to shadow_sessions.local_transcript_json
# If both are empty, the AI modules will still run but outputs will reflect
# no transcript data — they will produce minimal, generic responses.
#
# For the verification test: use a session that has real transcript data.
# Run: SELECT COUNT(*) FROM occ_transcription_segments WHERE conference_id = [sessionId]
# Should return > 0 rows.
#
# ═══════════════════════════════════════════════════════════════════════════
# QUESTIONS TO DAVE CAMERON before making assumptions.
# ═══════════════════════════════════════════════════════════════════════════
