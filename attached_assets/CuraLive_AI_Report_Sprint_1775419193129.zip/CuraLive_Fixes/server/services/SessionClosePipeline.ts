// ─────────────────────────────────────────────────────────────────────────────
// CuraLive — Session Close Pipeline
// File: server/services/SessionClosePipeline.ts
// Sprint 1 — V1 verification + Gap B wiring
//
// REPLACES / SUPPLEMENTS the closeSession handler in shadowModeRouter.ts
//
// USAGE — call this from shadowModeRouter.ts closeSession mutation:
//   import { runSessionClosePipeline } from "../services/SessionClosePipeline";
//
//   closeSession: operatorProcedure
//     .input(z.object({ sessionId: z.number().int() }))
//     .mutation(async ({ input }) => {
//       // 1. Mark session as completed in DB (existing code)
//       await rawSql(
//         `UPDATE shadow_sessions SET status = 'completed', ended_at = NOW() WHERE id = $1`,
//         [input.sessionId]
//       );
//
//       // 2. Fire the intelligence pipeline (non-blocking)
//       runSessionClosePipeline(input.sessionId).catch(console.error);
//
//       return { success: true };
//     }),
//
// PIPELINE SEQUENCE (all steps are non-blocking after step 1 and 2):
//   Step 1: Compliance email (BLOCKING — must fire before returning)
//   Step 2: AI report generation (BLOCKING — client waits for this)
//   Step 3: Report link delivery (fires after step 2)
//   Step 4: Board Intelligence update (non-blocking — never delays client)
//   Step 5: Briefing accuracy scoring (non-blocking — never delays client)
//   Step 6: Q&A intelligence summary (non-blocking)
// ─────────────────────────────────────────────────────────────────────────────

import { getDb, rawSql } from "../db";
import { sendComplianceCloseEmail } from "./ComplianceDeadlineService";
import { sendReportLinks as sendPostEventReport } from "./ClientDeliveryService";
import { runBoardIntelligenceUpdate } from "./BoardIntelligenceService";
import { generateAIReport }          from "./AIReportPipeline";
import { calculateBriefingAccuracy }  from "./PreEventBriefingService";
// Note: pipeline runs server-side only

const LOG = (msg: string) => console.log(`[SessionClose] ${msg}`);
const ERR = (msg: string, e: any) => console.error(`[SessionClose] ${msg}`, e);

export async function runSessionClosePipeline(sessionId: number): Promise<void> {
  const pipelineStart = Date.now();
  LOG(`Starting pipeline for session ${sessionId}`);

  const db = await getDb();
  if (!db) { ERR('No database connection', null); return; }

  // ── Load session data ────────────────────────────────────────────────────
  const [sessionRows] = await rawSql(
    `SELECT s.*,
            p.sending_name, p.sending_email, p.logo_url, p.primary_color
     FROM shadow_sessions s
     LEFT JOIN partners p ON p.id = s.partner_id
     WHERE s.id = $1`,
    [sessionId]
  );
  if (!sessionRows.length) { ERR(`Session ${sessionId} not found`, null); return; }
  const session = sessionRows[0];

  const recipients: Array<{name:string;email:string;role?:string;sendLive?:boolean;sendReport?:boolean}> =
    typeof session.recipients === 'string'
      ? JSON.parse(session.recipients)
      : (session.recipients ?? []);

  // ── Load compliance flags ────────────────────────────────────────────────
  const [flagRows] = await rawSql(
    `SELECT id, flag_type, statement as title, rule_basis as rule_reference, severity, deadline_hours
     FROM regulatory_flags
     WHERE monitor_id = $1
     ORDER BY severity DESC, created_at ASC`,
    [sessionId]
  );

  // ── STEP 1: Compliance email (fires immediately, <2 min target) ──────────
  const complianceRecipients = recipients.filter(r =>
    r.role?.toLowerCase().includes('compliance') || r.sendReport !== false
  );

  if (flagRows.length > 0 && complianceRecipients.length > 0) {
    try {
      // Create compliance deadlines in DB
      for (const flag of flagRows) {
        const deadlineHours = Number(flag.deadline_hours ?? 48);
        await rawSql(
          `INSERT INTO compliance_deadlines
             (session_id, flag_id, action, deadline_at, jurisdiction, priority, status, assigned_to)
           VALUES ($1, $2, $3, NOW() + ($4 || ' hours')::interval, $5, $6, 'open', $7)`,
          [
            sessionId,
            flag.id,
            flag.title ?? flag.flag_type,
            deadlineHours,
            session.jurisdiction ?? 'JSE',
            flag.severity === 'critical' ? 'critical' : 'high',
            complianceRecipients[0]?.email ?? null,
          ]
        );
      }

      await sendComplianceCloseEmail({
        sessionId,
        companyName:  session.company ?? 'Company',
        eventName:    session.event_name ?? 'Event',
        flags:        flagRows.map((f: any) => ({
          title:    f.title ?? f.flag_type,
          body:     f.title ?? '',
          severity: f.severity ?? 'high',
        })),
        deadlines: flagRows.map((f: any) => ({
          action:      f.title ?? f.flag_type,
          hours:       Number(f.deadline_hours ?? 48),
          jurisdiction: session.jurisdiction ?? 'JSE',
        })),
        recipients: complianceRecipients.map(r => ({ name: r.name, email: r.email })),
        partnerId:  session.partner_id ?? undefined,
      });

      LOG(`Compliance email sent to ${complianceRecipients.length} recipients (${Date.now()-pipelineStart}ms)`);
    } catch (e) {
      ERR('Compliance email failed', e);
      // Continue — do not block report delivery
    }
  }

  // ── STEP 2: AI report generation ─────────────────────────────────────────
  let reportModules: Record<string, string> = {};
  try {
    reportModules = await generateAIReport(sessionId, session);
    LOG(`AI report generated (${Date.now()-pipelineStart}ms)`);
  } catch (e) {
    ERR('AI report generation failed', e);
    // Still deliver what we have
  }

  // ── STEP 3: Report link delivery ─────────────────────────────────────────
  const reportRecipients = recipients.filter(r => r.sendReport !== false);
  if (reportRecipients.length > 0) {
    try {
      await sendPostEventReport({
        sessionId,
        eventName:    session.event_name ?? 'Event',
        companyName:  session.company ?? 'Company',
        eventDate:    new Date(session.created_at).toLocaleDateString(),
        reportModules: Object.keys(reportModules).length,
        complianceFlags: flagRows.length,
        sessionDuration: calculateDuration(session),
        recipients:   reportRecipients.map(r => ({ name: r.name, email: r.email })),
        partnerId:    session.partner_id ?? undefined,
      });
      LOG(`Report links sent to ${reportRecipients.length} recipients (${Date.now()-pipelineStart}ms)`);
    } catch (e) {
      ERR('Report delivery failed', e);
    }
  }

  // ── STEPS 4–6: Non-blocking intelligence updates ─────────────────────────
  // These run asynchronously and MUST NOT block the client from receiving their report.
  // Any failure here is logged but never surfaced to the client.

  // Step 4: Board Intelligence auto-populate (Gap B)
  runBoardIntelligenceUpdate({
    sessionId,
    company:        session.company ?? '',
    eventType:      session.event_type,
    reportModules:  {
      module08: reportModules['module_08'] ?? reportModules['guidance'],
      module07: reportModules['module_07'] ?? reportModules['tone'],
      module05: reportModules['module_05'] ?? reportModules['compliance'],
      module19: reportModules['module_19'] ?? reportModules['governance'],
    },
    transcriptText: await getTranscriptText(sessionId),
  }).catch(e => ERR('Board Intelligence update failed', e));

  // Step 5: Briefing accuracy scoring
  scoreBriefingAccuracy(sessionId, session, flagRows).catch(e =>
    ERR('Briefing accuracy scoring failed', e)
  );

  // Step 6: Q&A intelligence summary (fire and forget)
  rawSql(
    `UPDATE shadow_sessions SET report_links_sent_at = NOW() WHERE id = $1`,
    [sessionId]
  ).catch(() => {});

  LOG(`Pipeline complete for session ${sessionId} in ${Date.now()-pipelineStart}ms`);
}

// ── AI REPORT GENERATION ──────────────────────────────────────────────────
// generateAIReport imported from ./AIReportPipeline

// ── HELPERS ───────────────────────────────────────────────────────────────
async function getTranscriptText(sessionId: number): Promise<string> {
  try {
    const [rows] = await rawSql(
      `SELECT text FROM transcript_segments
       WHERE session_id = $1
       ORDER BY created_at ASC
       LIMIT 500`,
      [sessionId]
    );
    return rows.map((r: any) => r.text).join(' ');
  } catch {
    return '';
  }
}

async function scoreBriefingAccuracy(
  sessionId: number,
  session: any,
  flagRows: any[]
): Promise<void> {
  try {
    const db = await getDb();
    if (!db) return;

    // Find the scheduled session + its briefing
    const [briefingRows] = await rawSql(
      `SELECT id, predicted_qa, compliance_hotspots
       FROM pre_event_intelligence_briefings
       WHERE session_id = $1
       ORDER BY created_at DESC
       LIMIT 1`,
      [sessionId]
    );
    if (!briefingRows.length) return;

    const briefing = briefingRows[0];
    let predictedQA: string[] = [];
    let predictedHotspots: string[] = [];

    try { predictedQA = JSON.parse(briefing.predicted_qa ?? '[]'); } catch {}
    try { predictedHotspots = JSON.parse(briefing.compliance_hotspots ?? '[]'); } catch {}

    // Get actual Q&A count
    const [qaRows] = await rawSql(
      `SELECT COUNT(*)::int as count FROM approved_questions_queue WHERE "sessionId" = $1`,
      [sessionId]
    );
    const actualQACount = Number(qaRows[0]?.count ?? 0);

    // Get transcript topics (simplified — top keywords)
    const [topicRows] = await rawSql(
      `SELECT DISTINCT unnest(string_to_array(lower(text), ' ')) as word
       FROM transcript_segments
       WHERE session_id = $1
       LIMIT 200`,
      [sessionId]
    );
    const transcriptWords = new Set(topicRows.map((r: any) => r.word));

    await calculateBriefingAccuracy(sessionId);
  } catch (err) {
    // Non-fatal
    console.error('[SessionClose] Briefing accuracy scoring error:', err);
  }
}

function calculateDuration(session: any): string {
  if (!session.created_at) return '—';
  try {
    const start  = new Date(session.created_at);
    const end    = new Date();
    const mins   = Math.round((end.getTime() - start.getTime()) / 60_000);
    if (mins < 60) return `${mins} min`;
    return `${Math.floor(mins / 60)}h ${mins % 60}m`;
  } catch {
    return '—';
  }
}
